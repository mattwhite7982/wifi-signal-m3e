package com.antigravity.wifisignalm3e;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

import { Capacitor } from '@capacitor/core'
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics'

export type HapticKind = 'tap' | 'start' | 'tick' | 'complete'

export interface HapticConfig {
  enabled: boolean
  /** 10 (ultra-soft) to 100 (firm) */
  strength: number
}

export function getHapticsStrengthLabel(
  strength: number,
): 'Soft' | 'Balanced' | 'Firm' {
  if (strength <= 35) return 'Soft'
  if (strength <= 70) return 'Balanced'
  return 'Firm'
}

export function isHapticsSupported(): boolean {
  if (Capacitor.isNativePlatform()) return true
  return (
    typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function'
  )
}

function impactStyleForStrength(strength: number): ImpactStyle {
  if (strength <= 35) return ImpactStyle.Light
  if (strength <= 70) return ImpactStyle.Medium
  return ImpactStyle.Heavy
}

function scaledMs(baseMs: number, strength: number): number {
  const clamped = Math.max(10, Math.min(100, strength))
  // Scale smoothly from 0.45x (Soft) up to 1.65x (Firm)
  const factor = 0.45 + ((clamped - 10) / 90) * 1.2
  return Math.max(6, Math.round(baseMs * factor))
}

/**
 * Triggers tactile vibration using Capacitor Haptics on native Android/iOS
 * with automatic fallback to navigator.vibrate() on mobile web browsers.
 */
export async function triggerHaptic(
  kind: HapticKind,
  config: HapticConfig,
): Promise<void> {
  if (!config.enabled) return

  const strength = Math.max(10, Math.min(100, config.strength))
  const isNative = Capacitor.isNativePlatform()

  try {
    if (isNative) {
      const style = impactStyleForStrength(strength)
      if (kind === 'tap') {
        await Haptics.impact({ style })
        return
      }
      if (kind === 'tick') {
        if (strength <= 40) {
          await Haptics.selectionChanged()
        } else {
          await Haptics.impact({ style: ImpactStyle.Light })
        }
        return
      }
      if (kind === 'start') {
        await Haptics.impact({ style })
        if (strength >= 55) {
          await Haptics.vibrate({ duration: scaledMs(18, strength) })
        }
        return
      }
      if (kind === 'complete') {
        await Haptics.notification({ type: NotificationType.Success })
        if (strength >= 65) {
          await Haptics.vibrate({ duration: scaledMs(24, strength) })
        }
        return
      }
    }

    // Browser / WebView fallback via Vibration API
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      if (kind === 'tap') {
        navigator.vibrate(scaledMs(12, strength))
      } else if (kind === 'tick') {
        navigator.vibrate(scaledMs(8, strength))
      } else if (kind === 'start') {
        navigator.vibrate([scaledMs(16, strength), 32, scaledMs(22, strength)])
      } else if (kind === 'complete') {
        navigator.vibrate([scaledMs(18, strength), 46, scaledMs(28, strength)])
      }
    }
  } catch {
    // Gracefully ignore when device/browser restricts vibration
  }
}

import { Capacitor } from '@capacitor/core'
import { Network, type ConnectionStatus } from '@capacitor/network'
import { useEffect, useState } from 'react'

export type DetectedTransport = 'wifi' | 'cellular' | 'offline' | 'unknown'
export type ConnectionOverride = 'auto' | 'wifi' | 'cellular'

export interface LiveConnectionInfo {
  transport: DetectedTransport
  connected: boolean
  label: string
  detail: string
  source: 'Capacitor Network' | 'Browser Network API' | 'Preview Mode'
  cellularGen: '5G' | '4G LTE' | '3G' | null
}

interface NavigatorConnection extends EventTarget {
  type?: string
  effectiveType?: string
  downlink?: number
  rtt?: number
}

function getBrowserConnection(): NavigatorConnection | undefined {
  if (typeof navigator === 'undefined') return undefined
  const nav = navigator as Navigator & {
    connection?: NavigatorConnection
    mozConnection?: NavigatorConnection
    webkitConnection?: NavigatorConnection
  }
  return nav.connection ?? nav.mozConnection ?? nav.webkitConnection
}

function inferCellularGen(conn?: NavigatorConnection): '5G' | '4G LTE' | '3G' {
  if (!conn) return '5G'
  if (conn.effectiveType === '3g' || conn.effectiveType === '2g') return '3G'
  if (typeof conn.downlink === 'number' && conn.downlink >= 25) return '5G'
  return '4G LTE'
}

function normalizeStatus(
  capStatus: ConnectionStatus | null,
): Omit<LiveConnectionInfo, 'source'> & {
  source: 'Capacitor Network' | 'Browser Network API'
} {
  const browserConn = getBrowserConnection()
  const isNative = Capacitor.isNativePlatform()
  const source = isNative ? 'Capacitor Network' : 'Browser Network API'

  const connected =
    capStatus !== null
      ? capStatus.connected
      : typeof navigator !== 'undefined'
        ? navigator.onLine
        : true

  if (!connected || capStatus?.connectionType === 'none') {
    return {
      transport: 'offline',
      connected: false,
      label: 'Offline',
      detail: 'No Wi-Fi or mobile data connection detected',
      source,
      cellularGen: null,
    }
  }

  const capType = capStatus?.connectionType
  const browserType = browserConn?.type

  if (capType === 'cellular' || browserType === 'cellular') {
    const gen = inferCellularGen(browserConn)
    return {
      transport: 'cellular',
      connected: true,
      label: `Mobile Data (${gen})`,
      detail: `Connected via cellular data (${gen}) — switch to Wi-Fi to test router speeds`,
      source,
      cellularGen: gen,
    }
  }

  if (
    capType === 'wifi' ||
    browserType === 'wifi' ||
    browserType === 'ethernet'
  ) {
    return {
      transport: 'wifi',
      connected: true,
      label: 'Wi-Fi',
      detail: isNative
        ? 'Connected to Wi-Fi via Android Network Manager'
        : 'Connected to Wi-Fi network',
      source,
      cellularGen: null,
    }
  }

  // On desktop browsers where navigator.connection.type is omitted, default to Wi-Fi when online
  return {
    transport: 'wifi',
    connected: true,
    label: 'Wi-Fi',
    detail: 'Online (Wi-Fi / local network)',
    source,
    cellularGen: null,
  }
}

export function useConnectionStatus(
  override: ConnectionOverride = 'auto',
): LiveConnectionInfo {
  const [live, setLive] = useState<LiveConnectionInfo>(() =>
    normalizeStatus(null),
  )

  useEffect(() => {
    let active = true
    let removeCapListener: (() => Promise<void>) | null = null

    const syncFromCap = async () => {
      try {
        const status = await Network.getStatus()
        if (active) setLive(normalizeStatus(status))
      } catch {
        if (active) setLive(normalizeStatus(null))
      }
    }

    void syncFromCap()

    Network.addListener('networkStatusChange', (status) => {
      if (active) setLive(normalizeStatus(status))
    })
      .then((handle) => {
        removeCapListener = () => handle.remove()
      })
      .catch(() => {
        // Fallback to browser events below
      })

    const onBrowserChange = () => {
      void syncFromCap()
    }
    window.addEventListener('online', onBrowserChange)
    window.addEventListener('offline', onBrowserChange)
    const conn = getBrowserConnection()
    conn?.addEventListener?.('change', onBrowserChange)

    return () => {
      active = false
      if (removeCapListener) void removeCapListener()
      window.removeEventListener('online', onBrowserChange)
      window.removeEventListener('offline', onBrowserChange)
      conn?.removeEventListener?.('change', onBrowserChange)
    }
  }, [])

  if (override === 'cellular') {
    return {
      transport: 'cellular',
      connected: true,
      label: 'Mobile Data (5G)',
      detail: 'Previewing Mobile Data mode — switch to Auto on your phone for live detection',
      source: 'Preview Mode',
      cellularGen: '5G',
    }
  }

  if (override === 'wifi') {
    return {
      transport: 'wifi',
      connected: true,
      label: 'Wi-Fi',
      detail: 'Previewing Wi-Fi mode — switch to Auto on your phone for live detection',
      source: 'Preview Mode',
      cellularGen: null,
    }
  }

  return live
}

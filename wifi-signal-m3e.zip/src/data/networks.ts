export type TestStatus = 'idle' | 'scanning' | 'complete'

export type SpeedTestMode = 'download' | 'upload' | 'both'

export type NavTab = 'download' | 'upload' | 'both' | 'map' | 'settings'

export type ToneMode = 'neutral' | 'scanning' | 'uploading' | 'emerald' | 'amber'

export type SpeedUnit = 'Mbps' | 'MB/s' | 'Gbps'

export type FontStyle = 'pixel-display' | 'pixel-retro'

export type ColorPalette =
  | 'emerald'
  | 'ocean'
  | 'coral'
  | 'amber'
  | 'sage'
  | 'berry'

export interface PaletteOption {
  id: ColorPalette
  label: string
  swatch: string
  containerSwatch: string
}

export const COLOR_PALETTES: PaletteOption[] = [
  { id: 'emerald', label: 'Emerald', swatch: '#00a862', containerSwatch: '#a7f8cb' },
  { id: 'ocean', label: 'Ocean', swatch: '#0a7ae6', containerSwatch: '#b8dfff' },
  { id: 'coral', label: 'Coral', swatch: '#d9534f', containerSwatch: '#ffd4cf' },
  { id: 'amber', label: 'Amber', swatch: '#c47c00', containerSwatch: '#ffe1a1' },
  { id: 'sage', label: 'Sage', swatch: '#4a6b53', containerSwatch: '#cfe5d4' },
  { id: 'berry', label: 'Berry', swatch: '#9c3d7a', containerSwatch: '#f7c8e6' },
]

export interface AppSettings {
  unit: SpeedUnit
  durationSec: 3 | 5
  server: string
  dynamicTone: boolean
  autoReportToMap: boolean
  fontStyle: FontStyle
  colorPalette: ColorPalette
  matchDeviceColors: boolean
  hapticsEnabled: boolean
  /** 10 (soft) to 100 (firm) */
  hapticsStrength: number
  connectionOverride: 'auto' | 'wifi' | 'cellular'
}

export function checkDeviceColorCompatibility(): {
  supported: boolean
  detail: string
} {
  if (typeof window === 'undefined' || typeof CSS === 'undefined') {
    return {
      supported: false,
      detail: 'Unavailable in this environment',
    }
  }
  const supportsAccent =
    typeof CSS.supports === 'function' &&
    CSS.supports('color', 'AccentColor') &&
    CSS.supports('color', 'color-mix(in srgb, AccentColor 50%, white)')

  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : ''
  const isAndroid = /Android/i.test(ua)

  if (supportsAccent) {
    return {
      supported: true,
      detail: isAndroid
        ? 'Compatible · Syncs with Android Material You colors'
        : 'Compatible · Syncs with your device system accent color',
    }
  }

  return {
    supported: false,
    detail: 'Not supported by this browser or OS version',
  }
}

export const TEST_SERVERS = [
  { id: 'sf-auto', name: 'Auto (San Francisco)', latencyBase: 0 },
  { id: 'sea-edge', name: 'Seattle Edge', latencyBase: 5 },
  { id: 'nyc-core', name: 'New York Core', latencyBase: 14 },
  { id: 'tyo-ix', name: 'Tokyo IX', latencyBase: 28 },
] as const

export interface WifiNetwork {
  id: string
  ssid: string
  band: '6 GHz' | '5 GHz' | '2.4 GHz'
  standard: string
  channelWidth: string
  channel: number
  targetDbm: number
  targetDownloadMbps: number
  targetUploadMbps: number
  targetPing: number
  targetJitter: number
}

export interface TelemetrySnapshot {
  mode: SpeedTestMode
  /** Active sub-stage during a test */
  activeStage: 'download' | 'upload'
  /** Overall progress 0..1 */
  progress: number
  /** Signal strength in dBm */
  dbm: number
  /** Normalized 0..1 gauge fill fraction */
  gaugeFraction: number
  /** Primary Mbps value shown inside the Hero Starburst */
  heroMbps: number
  /** Measured Download Mbps */
  downloadMbps: number
  /** Measured Upload Mbps */
  uploadMbps: number
  /** Latency in ms */
  ping: number
  /** Jitter in ms */
  jitter: number
  /** Connection stability 0..1 */
  stability: number
  /** Live stage caption */
  phaseLabel: string
  /** Rating label */
  quality: 'Ready' | 'Downloading' | 'Uploading' | 'Excellent' | 'Good' | 'Fair'
}

export interface VideoTestTelemetry {
  progress: number
  currentRes: '480p' | '720p' | '1080p' | '1440p' | '4K UHD'
  maxRes: '720p' | '1080p' | '1440p' | '4K UHD'
  fps: 30 | 60
  bitrateMbps: number
  loadTimeMs: number
  bufferHealthPct: number
  droppedFrames: number
  stability: number
  phaseLabel: string
}

export interface MapReport {
  id: string
  /** Normalized map coordinates (0..100) */
  x: number
  y: number
  locationName: string
  ssid: string
  band: '6 GHz' | '5 GHz' | '2.4 GHz'
  downloadMbps: number
  uploadMbps: number
  dbm: number
  ping: number
  reportedAt: string
  note?: string
  isUserReport?: boolean
}

export const WIFI_NETWORKS: WifiNetwork[] = [
  {
    id: 'pixelfiber-6e',
    ssid: 'PixelFiber_6E',
    band: '6 GHz',
    standard: 'Wi-Fi 6E',
    channelWidth: '160 MHz',
    channel: 37,
    targetDbm: -48,
    targetDownloadMbps: 864,
    targetUploadMbps: 428,
    targetPing: 11,
    targetJitter: 1.8,
  },
  {
    id: 'studiomesh-5g',
    ssid: 'StudioMesh_5G',
    band: '5 GHz',
    standard: 'Wi-Fi 6',
    channelWidth: '80 MHz',
    channel: 149,
    targetDbm: -53,
    targetDownloadMbps: 612,
    targetUploadMbps: 294,
    targetPing: 14,
    targetJitter: 2.6,
  },
  {
    id: 'loftguest-24',
    ssid: 'LoftGuest_24',
    band: '2.4 GHz',
    standard: 'Wi-Fi 5',
    channelWidth: '40 MHz',
    channel: 6,
    targetDbm: -66,
    targetDownloadMbps: 148,
    targetUploadMbps: 68,
    targetPing: 26,
    targetJitter: 6.2,
  },
]

export const INITIAL_MAP_REPORTS: MapReport[] = [
  {
    id: 'rep-1',
    x: 24,
    y: 30,
    locationName: 'Civic Plaza West',
    ssid: 'PixelFiber_6E',
    band: '6 GHz',
    downloadMbps: 892,
    uploadMbps: 446,
    dbm: -46,
    ping: 9,
    reportedAt: '8m ago',
    note: 'Direct line of sight to rooftop mesh AP',
  },
  {
    id: 'rep-2',
    x: 68,
    y: 26,
    locationName: 'Tech Commons Atrium',
    ssid: 'Commons_6E',
    band: '6 GHz',
    downloadMbps: 780,
    uploadMbps: 390,
    dbm: -50,
    ping: 12,
    reportedAt: '24m ago',
    note: 'Rock solid for 4K video calls',
  },
  {
    id: 'rep-3',
    x: 52,
    y: 54,
    locationName: 'Harbor Library Reading Room',
    ssid: 'LibraryMesh_5G',
    band: '5 GHz',
    downloadMbps: 435,
    uploadMbps: 210,
    dbm: -57,
    ping: 15,
    reportedAt: '41m ago',
    note: 'Fast near north windows',
  },
  {
    id: 'rep-4',
    x: 79,
    y: 68,
    locationName: 'Cedar Roastery Patio',
    ssid: 'CedarGuest_5G',
    band: '5 GHz',
    downloadMbps: 268,
    uploadMbps: 112,
    dbm: -63,
    ping: 19,
    reportedAt: '1h ago',
    note: 'Slight drop outdoors by courtyard',
  },
  {
    id: 'rep-5',
    x: 31,
    y: 74,
    locationName: 'Station Concourse B',
    ssid: 'TransitFree_24',
    band: '2.4 GHz',
    downloadMbps: 94,
    uploadMbps: 38,
    dbm: -71,
    ping: 31,
    reportedAt: '2h ago',
    note: 'Congested during rush hour',
  },
]

export function formatSpeed(
  mbps: number,
  unit: SpeedUnit,
): { value: string; unitLabel: string } {
  if (unit === 'MB/s') {
    const mbs = mbps / 8
    return {
      value: mbs >= 100 ? Math.round(mbs).toString() : mbs.toFixed(1),
      unitLabel: 'MB/s',
    }
  }
  if (unit === 'Gbps') {
    return {
      value: (mbps / 1000).toFixed(2),
      unitLabel: 'Gbps',
    }
  }
  return {
    value: Math.round(mbps).toString(),
    unitLabel: 'Mbps',
  }
}

/** Converts Mbps into a normalized 0..1 gauge fill fraction (0 .. 1000 Mbps expressive curve) */
export function mbpsToGaugeFraction(mbps: number): number {
  const clamped = Math.max(0, Math.min(1000, mbps))
  // Slightly nonlinear curve so 150 Mbps still looks meaningful and 860+ Mbps fills ~88%
  return Math.max(0.04, Math.min(0.98, Math.pow(clamped / 1000, 0.72)))
}

export function getQualityFromSpeed(
  mbps: number,
  mode: SpeedTestMode,
): 'Excellent' | 'Good' | 'Fair' {
  const excellentThreshold = mode === 'upload' ? 220 : 450
  const goodThreshold = mode === 'upload' ? 75 : 140
  if (mbps >= excellentThreshold) return 'Excellent'
  if (mbps >= goodThreshold) return 'Good'
  return 'Fair'
}

export function getSignalBarsFromDbm(dbm: number): number {
  if (dbm >= -52) return 4
  if (dbm >= -62) return 3
  if (dbm >= -72) return 2
  return 1
}

export function getIdleTelemetry(mode: SpeedTestMode): TelemetrySnapshot {
  return {
    mode,
    activeStage: mode === 'upload' ? 'upload' : 'download',
    progress: 0,
    dbm: -88,
    gaugeFraction: 0,
    heroMbps: 0,
    downloadMbps: 0,
    uploadMbps: 0,
    ping: 0,
    jitter: 0,
    stability: 1,
    phaseLabel: 'Ready to measure channel & throughput',
    quality: 'Ready',
  }
}

/**
 * Computes realistic 60fps RF & throughput telemetry for Download, Upload, or Both (dual-stage).
 */
export function computeSweepTelemetry(
  elapsedMs: number,
  durationMs: number,
  mode: SpeedTestMode,
  network: WifiNetwork,
  runSeed: number,
  serverLatencyOffset = 0,
): TelemetrySnapshot {
  const totalDuration = mode === 'both' ? durationMs * 1.45 : durationMs
  const t = Math.max(0, Math.min(1, elapsedMs / totalDuration))

  const finalOffset = Math.round(Math.sin(runSeed * 3.1) * 0.8)
  const settledDbm = network.targetDbm + finalOffset
  const finalDownload = Math.round(
    network.targetDownloadMbps + Math.sin(runSeed * 2.3) * 16,
  )
  const finalUpload = Math.round(
    network.targetUploadMbps + Math.cos(runSeed * 1.9) * 11,
  )
  const targetPing = network.targetPing + serverLatencyOffset

  // Shared RF signal stabilization curve
  const acquireEase = 1 - Math.pow(1 - Math.min(1, t / 0.5), 3)
  const damping = Math.pow(1 - t, 1.3)
  const rfWave =
    Math.sin(t * 23 + runSeed) * 4.5 +
    Math.sin(t * 41 + runSeed * 1.7) * 2.2 +
    Math.cos(t * 11 + runSeed * 0.6) * 1.8
  const rawDbm = -78 + (settledDbm + 78) * acquireEase + rfWave * damping
  const dbm =
    t >= 1 ? settledDbm : Math.round(Math.min(-34, Math.max(-86, rawDbm)))

  // Ping & jitter convergence
  const pingSpike = (1 - Math.min(1, t / 0.72)) * (targetPing * 0.85)
  const pingNoise = Math.abs(Math.sin(t * 31 + runSeed)) * 4.2 * damping
  const ping =
    t >= 1
      ? targetPing
      : Math.max(5, Math.round(targetPing + pingSpike + pingNoise))

  const jitterBurst =
    (1 - Math.min(1, t / 0.85)) * (network.targetJitter * 2.6) +
    Math.abs(Math.sin(t * 19 + runSeed * 1.4)) * 3.0 * damping
  const jitter =
    t >= 1
      ? network.targetJitter
      : Number((network.targetJitter + jitterBurst).toFixed(1))

  const instability = Math.min(1, jitter / 14)
  const stability =
    t >= 1
      ? Math.max(0.74, Math.min(0.99, 1 - network.targetJitter / 24))
      : Math.max(0.2, Math.min(0.98, 0.32 + t * 0.66 - instability * 0.25))

  // Stage-specific Mbps ramp helper
  const calcStageMbps = (stageT: number, target: number, seedShift: number) => {
    const s = Math.max(0, Math.min(1, stageT))
    const ramp =
      s < 0.14
        ? (s / 0.14) * 0.2
        : 0.2 + 0.8 * (1 - Math.pow(1 - Math.min(1, (s - 0.14) / 0.74), 2.5))
    const stageDamp = Math.pow(1 - s, 1.35)
    const noise =
      (Math.sin(s * 28 + runSeed + seedShift) * 38 +
        Math.cos(s * 17 + runSeed * 1.3) * 24) *
      stageDamp *
      (target / 800)
    return s >= 1 ? target : Math.max(10, Math.round(target * ramp + noise))
  }

  let activeStage: 'download' | 'upload' =
    mode === 'upload' ? 'upload' : 'download'
  let downloadMbps = 0
  let uploadMbps = 0
  let heroMbps = 0
  let phaseLabel = ''

  if (mode === 'download') {
    activeStage = 'download'
    downloadMbps = calcStageMbps(t, finalDownload, 0)
    heroMbps = downloadMbps
    if (t < 0.22) phaseLabel = `Locking ${network.band} downstream streams…`
    else if (t < 0.65) phaseLabel = `Ramping ${network.channelWidth} download throughput…`
    else if (t < 1) phaseLabel = 'Verifying sustained peak download…'
    else
      phaseLabel = `Download complete • ${network.standard} (${network.channelWidth})`
  } else if (mode === 'upload') {
    activeStage = 'upload'
    uploadMbps = calcStageMbps(t, finalUpload, 2.4)
    heroMbps = uploadMbps
    if (t < 0.22) phaseLabel = `Allocating ${network.band} upstream buffers…`
    else if (t < 0.65) phaseLabel = `Pushing multi-stream upload payload…`
    else if (t < 1) phaseLabel = 'Measuring uplink stability & latency…'
    else
      phaseLabel = `Upload complete • ${network.standard} (${network.channelWidth})`
  } else {
    // Dual-stage: 0..0.52 Download, 0.52..1.0 Upload
    const split = 0.52
    if (t < split) {
      activeStage = 'download'
      const stageT = t / split
      downloadMbps = calcStageMbps(stageT, finalDownload, 0)
      uploadMbps = 0
      heroMbps = downloadMbps
      phaseLabel =
        stageT < 0.3
          ? `Stage 1/2 • Acquiring ${network.band} download…`
          : `Stage 1/2 • Measuring peak download speed…`
    } else {
      activeStage = 'upload'
      const stageT = (t - split) / (1 - split)
      downloadMbps = finalDownload
      uploadMbps = calcStageMbps(stageT, finalUpload, 3.1)
      // At completion, keep hero displaying peak download (with both cards visible)
      heroMbps = t >= 1 ? finalDownload : uploadMbps
      if (t >= 1) {
        phaseLabel = `Dual sweep complete • ${finalDownload}↓ / ${finalUpload}↑ Mbps`
      } else {
        phaseLabel =
          stageT < 0.35
            ? 'Stage 2/2 • Switching to upstream ramp…'
            : 'Stage 2/2 • Testing upload throughput & jitter…'
      }
    }
  }

  const quality: TelemetrySnapshot['quality'] =
    t >= 1
      ? getQualityFromSpeed(
          mode === 'upload' ? uploadMbps : downloadMbps,
          mode,
        )
      : activeStage === 'upload'
        ? 'Uploading'
        : 'Downloading'

  return {
    mode,
    activeStage,
    progress: t,
    dbm,
    gaugeFraction: mbpsToGaugeFraction(heroMbps),
    heroMbps,
    downloadMbps,
    uploadMbps,
    ping,
    jitter,
    stability,
    phaseLabel,
    quality,
  }
}

/**
 * Adaptive-bitrate Video Streaming Test simulation (480p -> 720p -> 1080p -> 1440p -> 4K UHD).
 */
export function computeVideoTelemetry(
  elapsedMs: number,
  durationMs: number,
  network: WifiNetwork,
  runSeed: number,
): VideoTestTelemetry {
  const t = Math.max(0, Math.min(1, elapsedMs / durationMs))

  const supports4K = network.targetDownloadMbps >= 350
  const supports1440 = network.targetDownloadMbps >= 140
  const maxRes: VideoTestTelemetry['maxRes'] = supports4K
    ? '4K UHD'
    : supports1440
      ? '1440p'
      : '1080p'

  const maxBitrate = supports4K ? 48.6 : supports1440 ? 24.4 : 11.8
  const baseLoadMs = Math.round(210 + network.targetPing * 11 + Math.sin(runSeed) * 28)

  // Step adaptive resolution up smoothly over the sweep
  let currentRes: VideoTestTelemetry['currentRes'] = '480p'
  if (t > 0.16) currentRes = '720p'
  if (t > 0.36) currentRes = '1080p'
  if (t > 0.58 && (supports1440 || supports4K)) currentRes = '1440p'
  if (t > 0.76 && supports4K) currentRes = '4K UHD'

  const ramp = 1 - Math.pow(1 - t, 2.2)
  const noise = Math.sin(t * 25 + runSeed) * 2.4 * (1 - t)
  const bitrateMbps = Number(
    Math.max(2.4, Math.min(maxBitrate + 3, maxBitrate * ramp + noise)).toFixed(1),
  )

  const bufferHealthPct = Math.round(
    Math.min(100, 42 + t * 58 - (network.targetJitter / 20) * (1 - t) * 18),
  )
  const droppedFrames = network.targetDownloadMbps >= 400 ? 0 : Math.floor(t * 2)
  const stability = Math.max(0.35, Math.min(0.99, 0.45 + t * 0.53))

  let phaseLabel = 'Negotiating adaptive HLS manifest…'
  if (t >= 0.2 && t < 0.55) phaseLabel = `Stepping up to ${currentRes} adaptive stream…`
  else if (t >= 0.55 && t < 1) phaseLabel = `Stress-testing ${currentRes} 60fps HDR buffer…`
  else if (t >= 1) phaseLabel = `Smooth ${maxRes} 60fps streaming verified`

  return {
    progress: t,
    currentRes: t >= 1 ? maxRes : currentRes,
    maxRes,
    fps: network.targetDownloadMbps >= 200 ? 60 : 30,
    bitrateMbps: t >= 1 ? maxBitrate : bitrateMbps,
    loadTimeMs: baseLoadMs,
    bufferHealthPct: t >= 1 ? 100 : bufferHealthPct,
    droppedFrames,
    stability,
    phaseLabel,
  }
}

export interface AiWifiContext {
  network: WifiNetwork
  downloadMbps: number
  uploadMbps: number
  dbm: number
  ping: number
  jitter: number
  hasTested: boolean
  connectionTransport?: 'wifi' | 'cellular' | 'offline' | 'unknown'
}

export function isWifiPoor(ctx: AiWifiContext): boolean {
  if (!ctx.hasTested) return ctx.network.band === '2.4 GHz'
  return (
    ctx.dbm <= -62 ||
    (ctx.downloadMbps > 0 && ctx.downloadMbps < 200) ||
    (ctx.uploadMbps > 0 && ctx.uploadMbps < 80) ||
    ctx.ping >= 24
  )
}

/**
 * Generates concise, actionable Wi-Fi optimization advice grounded in the user's
 * live network band, dBm, download/upload throughput, and ping/jitter.
 */
export function generateAiWifiReply(
  prompt: string,
  ctx: AiWifiContext,
): string {
  const q = prompt.toLowerCase()
  const { network, downloadMbps, uploadMbps, dbm, ping, jitter, hasTested, connectionTransport } = ctx
  const effectiveDbm = hasTested ? dbm : network.targetDbm
  const effectiveDl = downloadMbps > 0 ? downloadMbps : network.targetDownloadMbps
  const effectiveUl = uploadMbps > 0 ? uploadMbps : network.targetUploadMbps
  const effectivePing = hasTested ? ping : network.targetPing

  if (q.includes('diagnose') || q.includes('analyze') || q.includes('check') || q.includes('poor') || q.includes('better result')) {
    if (connectionTransport === 'offline') {
      return `Your device currently appears **Offline** (no Wi-Fi or mobile data). Reconnect to your Wi-Fi network or toggle Airplane Mode off before running a speed test.`
    }
    const issues: string[] = []
    if (connectionTransport === 'cellular') {
      issues.push(
        `Your device is currently on **Mobile Data (Cellular)** rather than Wi-Fi. Switch Wi-Fi back on to test your home router and avoid using cellular data allowance.`,
      )
    }
    if (network.band === '2.4 GHz') {
      issues.push(
        `You're on **2.4 GHz (Ch ${network.channel})**, which caps throughput and suffers heavy neighbor interference. Switching to **5 GHz or 6 GHz** typically doubles or triples real-world speed.`,
      )
    }
    if (effectiveDbm <= -62) {
      issues.push(
        `Your signal is **${effectiveDbm} dBm** (weak-to-moderate). Move closer to the router, elevate it off the floor, and clear thick walls or metal appliances between your device and the access point.`,
      )
    }
    if (effectivePing >= 20 || jitter >= 4) {
      issues.push(
        `Latency is **${effectivePing} ms** (±${jitter.toFixed(1)} ms jitter). Enabling **SQM / Smart QoS** on your router prevents background uploads from causing lag spikes.`,
      )
    }
    if (issues.length === 0) {
      return `Your **${network.ssid}** link looks strong (**${effectiveDl} Mbps down**, **${effectiveUl} Mbps up**, **${effectiveDbm} dBm**, **${effectivePing} ms ping** on ${network.band}). To squeeze even more consistency: keep your router on an open shelf, use **160 MHz** only when congestion is low, and prefer wired Ethernet for heavy uploads.`
    }
    return `Here is what's holding back **${network.ssid}** (${effectiveDl}↓ / ${effectiveUl}↑ Mbps, ${effectiveDbm} dBm):\n\n• ${issues.join('\n• ')}`
  }

  if (q.includes('upload') || q.includes('stream') || q.includes('zoom') || q.includes('call')) {
    return `Your upstream on **${network.ssid}** is **${effectiveUl} Mbps** (${effectiveDbm} dBm). To boost upload speed:\n\n• Pause cloud backups (Google Photos, iCloud, Drive) during calls or uploads.\n• Move within clear range of your **${network.band}** router — weak RSSI hurts upload much faster than download because phones transmit at lower power than routers.\n• Enable **OFDMA & MU-MIMO** in router settings if available.`
  }

  if (q.includes('ping') || q.includes('lag') || q.includes('game') || q.includes('gaming') || q.includes('jitter')) {
    return `Current latency is **${effectivePing} ms** (±${jitter.toFixed(1)} ms jitter). To drop ping & stop lag spikes:\n\n• Switch off **2.4 GHz** onto **5 GHz / 6 GHz** to avoid microwave & Bluetooth interference.\n• Turn on **SQM (CAKE / fq_codel)** or Gaming QoS in your router to eliminate bufferbloat.\n• Pick the closest edge server in Settings, or use Ethernet for competitive gaming.`
  }

  if (q.includes('channel') || q.includes('band') || q.includes('5 ghz') || q.includes('6 ghz') || q.includes('2.4')) {
    return `You're connected to **${network.band}** on **Ch ${network.channel}** (${network.channelWidth}).\n\n• **6 GHz** is fastest and cleanest in the same room.\n• **5 GHz (80 MHz)** is the best balance through 1–2 drywall walls (use DFS channels if neighbors crowd Ch 36–48).\n• **2.4 GHz** should only use non-overlapping channels **1, 6, or 11** at **20 MHz** width.`
  }

  if (q.includes('router') || q.includes('placement') || q.includes('wall') || q.includes('mesh') || q.includes('extender') || q.includes('dead')) {
    return `At **${effectiveDbm} dBm**, physical placement makes the biggest jump:\n\n• Place your router centrally at chest height — avoid cabinets, TVs, mirrors, and concrete corners.\n• If a room drops below **-68 dBm**, add a **tri-band Mesh node** (with wired Ethernet or 6 GHz backhaul) rather than a cheap single-band repeater.`
  }

  if (q.includes('4k') || q.includes('video') || q.includes('buffer') || q.includes('netflix') || q.includes('youtube')) {
    const verdict =
      effectiveDl >= 50
        ? `At **${effectiveDl} Mbps**, you easily exceed the ~25–45 Mbps needed for crisp **4K UHD HDR** streaming.`
        : `At **${effectiveDl} Mbps**, 4K HDR may buffer when other devices are active.`
    return `${verdict} If video still stutters, check the **Video Test** tab for load-time spikes, try switching DNS to **1.1.1.1** or **8.8.8.8**, and make sure your TV/phone stays on **5 GHz / 6 GHz**.`
  }

  if (q.includes('slow') || q.includes('speed') || q.includes('improve') || q.includes('fix') || q.includes('boost')) {
    return `Quick wins for **${network.ssid}** (**${effectiveDl} Mbps**, **${effectiveDbm} dBm**):\n\n1. **Use 5 GHz or 6 GHz** when near the router instead of crowded 2.4 GHz.\n2. **Restart modem & router** if speeds suddenly halved or ping climbed.\n3. **Check channel width** (80 MHz on 5 GHz, 160 MHz on 6 GHz) and update router firmware.\n4. **Run the Full Sweep (Both)** tab to verify whether download or upload is the bottleneck.`
  }

  return `Looking at **${network.ssid}** (**${network.band}**, **${effectiveDl}↓ / ${effectiveUl}↑ Mbps**, **${effectiveDbm} dBm**, **${effectivePing} ms**): ask me about **slow speeds**, **upload bottlenecks**, **high ping/gaming lag**, **5 GHz vs 6 GHz channels**, or **router placement** and I'll give you tailored steps.`
}


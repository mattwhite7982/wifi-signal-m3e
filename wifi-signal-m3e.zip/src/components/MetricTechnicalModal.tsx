import { AnimatePresence, motion } from 'framer-motion'
import { Activity, ArrowDown, ArrowUp, Info, X } from 'lucide-react'
import {
  formatSpeed,
  type SpeedUnit,
  type WifiNetwork,
} from '../data/networks'

export type TechnicalMetricTab = 'download' | 'upload' | 'ping'

interface MetricTechnicalModalProps {
  openTab: TechnicalMetricTab | null
  onSelectTab: (tab: TechnicalMetricTab) => void
  onClose: () => void
  network: WifiNetwork
  downloadMbps: number
  uploadMbps: number
  dbm: number
  ping: number
  jitter: number
  unit: SpeedUnit
  serverName: string
  hasTested: boolean
}

interface SpecRow {
  label: string
  value: string
  hint?: string
}

export function MetricTechnicalModal({
  openTab,
  onSelectTab,
  onClose,
  network,
  downloadMbps,
  uploadMbps,
  dbm,
  ping,
  jitter,
  unit,
  serverName,
  hasTested,
}: MetricTechnicalModalProps) {
  if (!openTab) return null

  const effDl = downloadMbps > 0 ? downloadMbps : network.targetDownloadMbps
  const effUl = uploadMbps > 0 ? uploadMbps : network.targetUploadMbps
  const effDbm = hasTested ? dbm : network.targetDbm
  const effPing = hasTested ? ping : network.targetPing
  const effJitter = hasTested ? jitter : network.targetJitter

  const dlFmt = formatSpeed(effDl, unit)
  const dlAvgFmt = formatSpeed(Math.round(effDl * 0.93), unit)
  const ulFmt = formatSpeed(effUl, unit)
  const ulAvgFmt = formatSpeed(Math.round(effUl * 0.91), unit)

  const noiseFloor = network.band === '6 GHz' ? -95 : network.band === '5 GHz' ? -93 : -89
  const snr = Math.max(8, effDbm - noiseFloor)
  const phyRate =
    network.band === '6 GHz'
      ? 2402
      : network.band === '5 GHz'
        ? 1201
        : 286
  const mcsLabel =
    network.band === '6 GHz'
      ? 'MCS 11 · 1024-QAM (2×2 MIMO)'
      : network.band === '5 GHz'
        ? 'MCS 10 · 1024-QAM (2×2 MIMO)'
        : 'MCS 7 · 256-QAM (2×2 MIMO)'

  const dlLoadedDelta = effPing <= 14 ? 4 : effPing <= 20 ? 9 : 18
  const ulLoadedDelta = effPing <= 14 ? 6 : effPing <= 20 ? 12 : 24
  const bufferbloatGrade = dlLoadedDelta <= 6 ? 'A+' : dlLoadedDelta <= 12 ? 'A' : 'B'

  const minPing = Math.max(4, Math.round(effPing - effJitter * 0.9))
  const maxPing = Math.round(effPing + effJitter * 2.1)
  const p99Ping = Math.round(effPing + effJitter * 2.8)
  const packetLoss = effDbm <= -68 ? '0.4%' : '0.0%'

  const tabs: Array<{
    id: TechnicalMetricTab
    label: string
    icon: typeof ArrowDown
  }> = [
    { id: 'download', label: 'Download', icon: ArrowDown },
    { id: 'upload', label: 'Upload', icon: ArrowUp },
    { id: 'ping', label: 'Ping', icon: Activity },
  ]

  const specsByTab: Record<
    TechnicalMetricTab,
    {
      headline: string
      unitText: string
      subtitle: string
      rows: SpecRow[]
    }
  > = {
    download: {
      headline: dlFmt.value,
      unitText: dlFmt.unitLabel,
      subtitle: hasTested
        ? 'Measured downstream telemetry'
        : 'Estimated link profile (run a test for live capture)',
      rows: [
        { label: 'Sustained Average', value: `${dlAvgFmt.value} ${dlAvgFmt.unitLabel}` },
        { label: 'PHY Link Rate', value: `${phyRate} Mbps`, hint: network.standard },
        { label: 'Modulation & Spatial', value: mcsLabel },
        {
          label: 'Radio Channel',
          value: `${network.band} · Ch ${network.channel} (${network.channelWidth})`,
        },
        { label: 'Parallel TCP Streams', value: '8 streams · BBRv2 · MTU 1500 B' },
        {
          label: 'Loaded Latency (Bufferbloat)',
          value: `+${dlLoadedDelta} ms · Grade ${bufferbloatGrade}`,
        },
        {
          label: 'TCP Retransmissions',
          value: effDbm <= -65 ? '0.32%' : '0.04%',
        },
      ],
    },
    upload: {
      headline: ulFmt.value,
      unitText: ulFmt.unitLabel,
      subtitle: hasTested
        ? 'Measured upstream telemetry'
        : 'Estimated uplink profile (run Upload or Both for live capture)',
      rows: [
        { label: 'Sustained Average', value: `${ulAvgFmt.value} ${ulAvgFmt.unitLabel}` },
        { label: 'Client TX Power', value: network.band === '6 GHz' ? '15 dBm (LPI)' : '18 dBm' },
        { label: 'Uplink Modulation', value: `${mcsLabel.split(' · ')[0]} · UL-OFDMA` },
        { label: 'Guard Interval', value: '0.8 µs · Short GI active' },
        { label: 'Parallel Uplink Streams', value: '6 streams · TCP Window 4 MB' },
        {
          label: 'Loaded Upload Latency',
          value: `+${ulLoadedDelta} ms under load`,
        },
        { label: 'Uplink Frame Drop', value: effDbm <= -65 ? '0.25%' : '0.00%' },
      ],
    },
    ping: {
      headline: String(effPing),
      unitText: 'ms',
      subtitle: `ICMP / WebSocket RTT to ${serverName}`,
      rows: [
        {
          label: 'Min / Median / Max RTT',
          value: `${minPing} ms / ${effPing} ms / ${maxPing} ms`,
        },
        {
          label: 'Jitter (RFC 3550)',
          value: `±${effJitter.toFixed(1)} ms`,
          hint: `p99 ${p99Ping} ms`,
        },
        { label: 'Packet Loss', value: `${packetLoss} (40 probes)` },
        { label: 'Signal RSSI', value: `${effDbm} dBm` },
        { label: 'Noise Floor & SNR', value: `${noiseFloor} dBm · ${snr} dB SNR` },
        { label: 'DNS Resolution', value: `${Math.max(3, Math.round(effPing * 0.45))} ms · DoH` },
        { label: 'Transport Route', value: `IPv6 Dual-Stack · ${serverName}` },
      ],
    },
  }

  const activeData = specsByTab[openTab]

  return (
    <AnimatePresence>
      <motion.div
        id="technical-details-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 sm:p-6"
        style={{
          backgroundColor: 'rgba(11, 20, 15, 0.52)',
          backdropFilter: 'blur(10px)',
        }}
      >
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={`${openTab} technical information`}
          initial={{ opacity: 0, y: 28, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.96 }}
          transition={{ type: 'spring', stiffness: 420, damping: 28 }}
          onClick={(e) => e.stopPropagation()}
          className="m3-tone-surface relative w-full max-w-[490px] max-h-[88vh] overflow-y-auto rounded-[34px] p-5 sm:p-6 shadow-2xl"
          style={{
            backgroundColor: 'var(--md-surface)',
            color: 'var(--md-on-surface)',
            border: '1px solid var(--md-outline-variant)',
          }}
        >
          {/* Header Row */}
          <div className="flex items-center justify-between gap-3">
            <div>
              <span
                className="text-[11px] font-extrabold uppercase tracking-[0.08em]"
                style={{ color: 'var(--md-primary)' }}
              >
                Technical Telemetry
              </span>
              <h2 className="font-display text-2xl font-black tracking-[-0.035em] capitalize">
                {openTab} Details
              </h2>
            </div>

            <button
              id="close-tech-modal-btn"
              type="button"
              onClick={onClose}
              aria-label="Close technical details"
              className="m3-tone-surface flex h-10 w-10 items-center justify-center rounded-full cursor-pointer"
              style={{
                backgroundColor: 'var(--md-surface-container-high)',
                color: 'var(--md-on-surface-variant)',
              }}
            >
              <X className="h-5 w-5 stroke-[2.4]" />
            </button>
          </div>

          {/* Switchable Tabs inside Sheet: Download | Upload | Ping */}
          <div
            className="mt-4 grid grid-cols-3 gap-1 rounded-full p-1"
            style={{ backgroundColor: 'var(--md-surface-container-high)' }}
          >
            {tabs.map((tab) => {
              const Icon = tab.icon
              const isSelected = openTab === tab.id
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => onSelectTab(tab.id)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-full py-2 font-display text-xs font-extrabold cursor-pointer transition-colors"
                  style={{
                    backgroundColor: isSelected
                      ? 'var(--md-primary)'
                      : 'transparent',
                    color: isSelected
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  <Icon className="h-3.5 w-3.5 stroke-[2.5]" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>

          {/* Highlight Summary Pill */}
          <div
            className="mt-4 flex items-center justify-between gap-3 rounded-[24px] px-5 py-4"
            style={{
              backgroundColor:
                openTab === 'download'
                  ? 'var(--md-tile-dl-bg)'
                  : openTab === 'upload'
                    ? 'var(--md-tile-ul-bg)'
                    : 'var(--md-tile-ping-bg)',
              color:
                openTab === 'download'
                  ? 'var(--md-tile-dl-fg)'
                  : openTab === 'upload'
                    ? 'var(--md-tile-ul-fg)'
                    : 'var(--md-tile-ping-fg)',
            }}
          >
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="font-display text-[42px] font-black leading-none tracking-[-0.05em] tabular-nums">
                  {activeData.headline}
                </span>
                <span className="font-display text-sm font-extrabold opacity-80">
                  {activeData.unitText}
                </span>
              </div>
              <p className="mt-1 text-xs font-semibold opacity-80">
                {activeData.subtitle}
              </p>
            </div>
            <span
              className="shrink-0 rounded-full px-3 py-1 font-display text-[11px] font-extrabold"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.22)',
              }}
            >
              {network.ssid}
            </span>
          </div>

          {/* Technical Key-Value Specs Table */}
          <div
            className="mt-4 divide-y rounded-[24px] px-4 py-1"
            style={{
              backgroundColor: 'var(--md-surface-container)',
              borderColor: 'var(--md-outline-variant)',
            }}
          >
            {activeData.rows.map((row) => (
              <div
                key={row.label}
                className="flex items-center justify-between gap-3 py-2.5 text-xs"
                style={{ borderColor: 'var(--md-outline-variant)' }}
              >
                <span
                  className="font-semibold"
                  style={{ color: 'var(--md-on-surface-variant)' }}
                >
                  {row.label}
                </span>
                <div className="text-right font-display font-bold tabular-nums">
                  <span>{row.value}</span>
                  {row.hint && (
                    <span
                      className="ml-1.5 text-[11px] font-semibold opacity-70"
                      style={{ color: 'var(--md-on-surface-variant)' }}
                    >
                      ({row.hint})
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Friendly Footnote for Everyday Users */}
          <div
            className="mt-4 flex items-start gap-2.5 rounded-[20px] px-4 py-3 text-xs leading-relaxed"
            style={{
              backgroundColor: 'var(--md-surface-container-low)',
              color: 'var(--md-on-surface-variant)',
            }}
          >
            <Info className="mt-0.5 h-4 w-4 shrink-0 opacity-80" />
            <p className="m-0">
              <strong className="font-bold">Note:</strong> This is technical
              information and isn&apos;t meant for the average user. You only
              need the main home screen showing your{' '}
              <strong className="font-bold">Download</strong>,{' '}
              <strong className="font-bold">Upload</strong>, and{' '}
              <strong className="font-bold">Ping</strong>.
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

import { AnimatePresence, LayoutGroup, motion } from 'framer-motion'
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  MapPin,
  RotateCcw,
} from 'lucide-react'
import {
  formatSpeed,
  type SpeedTestMode,
  type SpeedUnit,
  type TelemetrySnapshot,
  type TestStatus,
  type WifiNetwork,
} from '../data/networks'
import { CircularWavySpinner } from './CircularWavySpinner'
import { MorphingStarburst } from './MorphingStarburst'

interface HeroSignalGaugeProps {
  mode: SpeedTestMode
  status: TestStatus
  telemetry: TelemetrySnapshot
  network: WifiNetwork
  unit: SpeedUnit
  durationSec: 3 | 5
  onStartTest: () => void
  onReset: () => void
  onReportToMap: () => void
}

const HERO_SPRING = {
  type: 'spring' as const,
  stiffness: 280,
  damping: 25,
  mass: 0.92,
}

export function HeroSignalGauge({
  mode,
  status,
  telemetry,
  network,
  unit,
  durationSec,
  onStartTest,
  onReset,
  onReportToMap,
}: HeroSignalGaugeProps) {
  const isIdle = status === 'idle'
  const isScanning = status === 'scanning'
  const isComplete = status === 'complete'

  // Live sweep progress while measuring (stage-aware for 'both'), settling to speed score on complete
  const liveStageProgress =
    mode === 'both'
      ? telemetry.progress < 0.52
        ? telemetry.progress / 0.52
        : (telemetry.progress - 0.52) / 0.48
      : telemetry.progress

  const spinnerProgress = isScanning
    ? 0.12 + Math.min(1, Math.max(0, liveStageProgress)) * 0.82
    : Math.max(0.28, Math.min(0.86, telemetry.gaugeFraction))

  const heroFormatted = formatSpeed(telemetry.heroMbps, unit)
  const ModeIcon =
    mode === 'upload' ? ArrowUp : mode === 'both' ? ArrowUpDown : ArrowDown

  const buttonTitle =
    mode === 'upload'
      ? 'TEST UPLOAD'
      : mode === 'both'
        ? 'TEST BOTH'
        : 'TEST SPEED'

  const buttonSub =
    mode === 'both'
      ? `${network.band} • DL + UL`
      : `${network.band} • ${durationSec}s`

  // Secondary measurement cleanly displayed at the bottom underneath the spinner
  const bottomCaption = isComplete
    ? `${telemetry.quality} · ${telemetry.dbm} dBm`
    : telemetry.activeStage === 'upload'
      ? `Uploading · ${telemetry.dbm} dBm`
      : `Downloading · ${telemetry.dbm} dBm`

  return (
    <LayoutGroup id="hero-gauge-morph">
      <div className="relative flex flex-col items-center justify-center">
        {/* Fixed-height stage so morphing never causes vertical layout shift */}
        <div className="relative flex h-[314px] w-full max-w-[320px] items-center justify-center">
          <AnimatePresence mode="popLayout" initial={false}>
            {isIdle ? (
              <motion.div
                key={`idle-${mode}`}
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.22 }}
                className="relative flex items-center justify-center"
              >
                {/* Clean single scalloped backdrop behind trigger */}
                <div className="pointer-events-none absolute flex items-center justify-center opacity-70">
                  <MorphingStarburst
                    signalStrength={0.3}
                    status="idle"
                    size={252}
                  />
                </div>

                {/* Tactile Squishy Pixel M3E Trigger */}
                <motion.button
                  id="test-signal-btn"
                  type="button"
                  layoutId="hero-morph-container"
                  onClick={onStartTest}
                  whileHover={{ scale: 1.04, borderRadius: '64px' }}
                  whileTap={{ scale: 0.89, borderRadius: '88px' }}
                  transition={{
                    layout: HERO_SPRING,
                    scale: { type: 'spring', stiffness: 520, damping: 18 },
                    borderRadius: { type: 'spring', stiffness: 420, damping: 22 },
                  }}
                  className="m3-tone-surface relative z-10 flex h-[204px] w-[204px] flex-col items-center justify-center gap-3 cursor-pointer select-none focus:outline-none"
                  style={{
                    borderRadius: '78px',
                    backgroundColor: 'var(--md-primary)',
                    color: 'var(--md-on-primary)',
                  }}
                >
                  <ModeIcon className="h-7 w-7 stroke-[2.5]" />
                  <div className="flex flex-col items-center">
                    <span className="font-display text-[19px] font-black tracking-[-0.02em] leading-none">
                      {buttonTitle}
                    </span>
                    <span className="mt-1.5 text-xs font-semibold opacity-80">
                      {buttonSub}
                    </span>
                  </div>
                </motion.button>
              </motion.div>
            ) : (
              /* Material 3 Expressive Circular Wavy Spinner Stage */
              <motion.div
                key="active-gauge"
                layoutId="hero-morph-container"
                transition={{ layout: HERO_SPRING }}
                className="relative flex flex-col items-center justify-center rounded-full"
                style={{ backgroundColor: 'transparent' }}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.84 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{
                    type: 'spring',
                    stiffness: 320,
                    damping: 24,
                    delay: 0.04,
                  }}
                >
                  <CircularWavySpinner
                    progress={spinnerProgress}
                    status={status}
                    stability={telemetry.stability}
                    size={264}
                    strokeWidth={22}
                    amplitude={7.6}
                    waves={9}
                    ariaLabel={`${heroFormatted.value} ${heroFormatted.unitLabel}, ${bottomCaption}`}
                  >
                    <motion.span
                      key={isComplete ? 'locked' : 'live'}
                      animate={isComplete ? { scale: [1, 1.06, 1] } : undefined}
                      transition={{ type: 'spring', stiffness: 420, damping: 18 }}
                      className="font-display text-[58px] font-black leading-none tracking-[-0.055em] tabular-nums"
                      style={{ color: 'var(--md-on-surface)' }}
                    >
                      {heroFormatted.value}
                    </motion.span>
                    <span
                      className="mt-1.5 font-display text-sm font-extrabold tracking-[0.02em]"
                      style={{ color: 'var(--md-on-surface-variant)' }}
                    >
                      {heroFormatted.unitLabel}
                    </span>
                  </CircularWavySpinner>
                </motion.div>

                {/* Other measurement cleanly positioned underneath the wavy spinner */}
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25, delay: 0.08 }}
                  className="mt-3 flex items-center justify-center"
                >
                  <span
                    className="font-display text-[17px] font-extrabold tracking-[-0.02em] tabular-nums"
                    style={{
                      color: isComplete
                        ? 'var(--md-primary)'
                        : 'var(--md-on-surface-variant)',
                    }}
                  >
                    {bottomCaption}
                  </span>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Clean Action Row once sweep completes */}
        <AnimatePresence>
          {isComplete && (
            <motion.div
              key="complete-actions"
              initial={{ opacity: 0, y: 8, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 4, scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 420, damping: 24 }}
              className="mt-4 flex flex-wrap items-center justify-center gap-2"
            >
              <motion.button
                id="test-again-btn"
                type="button"
                onClick={onStartTest}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.92 }}
                className="m3-tone-surface inline-flex items-center gap-2 rounded-full px-5 py-2.5 font-display text-sm font-extrabold cursor-pointer"
                style={{
                  backgroundColor: 'var(--md-primary)',
                  color: 'var(--md-on-primary)',
                }}
              >
                <span>Test again</span>
              </motion.button>

              <motion.button
                id="report-to-map-btn"
                type="button"
                onClick={onReportToMap}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.93 }}
                className="m3-tone-surface inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 font-display text-sm font-bold cursor-pointer"
                style={{
                  backgroundColor: 'var(--md-surface-container-high)',
                  color: 'var(--md-on-surface)',
                }}
              >
                <MapPin className="h-4 w-4 stroke-[2.3]" />
                <span>Report on map</span>
              </motion.button>

              <motion.button
                id="reset-gauge-btn"
                type="button"
                onClick={onReset}
                whileHover={{ scale: 1.06 }}
                whileTap={{ scale: 0.9, rotate: -20 }}
                aria-label="Reset dial"
                title="Reset"
                className="m3-tone-surface flex h-10 w-10 items-center justify-center rounded-full cursor-pointer"
                style={{
                  backgroundColor: 'var(--md-surface-container-high)',
                  color: 'var(--md-on-surface-variant)',
                }}
              >
                <RotateCcw className="h-4 w-4 stroke-[2.3]" />
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </LayoutGroup>
  )
}

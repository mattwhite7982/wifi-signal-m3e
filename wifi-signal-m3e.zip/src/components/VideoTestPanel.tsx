import { AnimatePresence, LayoutGroup, motion } from 'framer-motion'
import {
  CheckCircle2,
  Info,
  MapPin,
  MonitorPlay,
  Play,
  RotateCcw,
  Tv,
  X,
} from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import {
  computeVideoTelemetry,
  type AiWifiContext,
  type TelemetrySnapshot,
  type TestStatus,
  type VideoTestTelemetry,
  type WifiNetwork,
} from '../data/networks'
import { AiMagnifierIcon, AiWifiAssistant } from './AiWifiAssistant'
import { CircularWavySpinner } from './CircularWavySpinner'
import { MorphingStarburst } from './MorphingStarburst'
import { WavyProgressBar } from './WavyProgressBar'
import { triggerHaptic, type HapticConfig } from '../utils/haptics'

interface VideoTestPanelProps {
  network: WifiNetwork
  durationSec: 3 | 5
  onStatusChange?: (status: TestStatus) => void
  onReportToMap: () => void
  aiContext: AiWifiContext
  isPoorWifi: boolean
  aiChatOpen: boolean
  onToggleAiChat: (open: boolean) => void
  diagnoseTriggerCount: number
  onAskAi: () => void
  hapticConfig: HapticConfig
}

type VideoTechTab = 'load' | 'buffer' | 'quality'

const HERO_SPRING = {
  type: 'spring' as const,
  stiffness: 280,
  damping: 25,
  mass: 0.92,
}

function getResSegments(res: VideoTestTelemetry['currentRes']): number {
  if (res === '4K UHD') return 4
  if (res === '1440p') return 3
  if (res === '1080p') return 2
  return 1
}

function shortResLabel(res: VideoTestTelemetry['currentRes']): string {
  return res === '4K UHD' ? '4K' : res
}

export function VideoTestPanel({
  network,
  durationSec,
  onStatusChange,
  onReportToMap,
  aiContext,
  isPoorWifi,
  aiChatOpen,
  onToggleAiChat,
  diagnoseTriggerCount,
  onAskAi,
  hapticConfig,
}: VideoTestPanelProps) {
  const [status, setStatus] = useState<TestStatus>('idle')
  const [video, setVideo] = useState<VideoTestTelemetry | null>(null)
  const [inspectedTab, setInspectedTab] = useState<VideoTechTab | null>(null)
  const rafRef = useRef<number | null>(null)
  const startRef = useRef(0)
  const lastResRef = useRef<string>('')

  const stop = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
  }, [])

  useEffect(() => {
    return () => stop()
  }, [stop])

  const startVideoTest = useCallback(() => {
    stop()
    void triggerHaptic('start', hapticConfig)
    const seed = 0.7 + Math.random() * 4.8
    const durationMs = durationSec * 1000
    startRef.current = performance.now()
    lastResRef.current = '480p'
    setStatus('scanning')
    onStatusChange?.('scanning')

    const tick = (now: number) => {
      const elapsed = now - startRef.current
      const snap = computeVideoTelemetry(elapsed, durationMs, network, seed)
      if (snap.currentRes !== lastResRef.current) {
        lastResRef.current = snap.currentRes
        void triggerHaptic('tick', hapticConfig)
      }
      setVideo(snap)
      if (elapsed < durationMs) {
        rafRef.current = requestAnimationFrame(tick)
      } else {
        rafRef.current = null
        setStatus('complete')
        onStatusChange?.('complete')
        void triggerHaptic('complete', hapticConfig)
      }
    }

    rafRef.current = requestAnimationFrame(tick)
  }, [durationSec, hapticConfig, network, onStatusChange, stop])

  const resetVideoTest = useCallback(() => {
    stop()
    void triggerHaptic('tap', hapticConfig)
    setStatus('idle')
    setVideo(null)
    onStatusChange?.('idle')
  }, [hapticConfig, onStatusChange, stop])

  const isIdle = status === 'idle'
  const isScanning = status === 'scanning'
  const isComplete = status === 'complete'

  // Gauge fill fraction mapped from live adaptive bitrate (0..52 Mbps)
  const gaugeFraction = video
    ? Math.max(0.06, Math.min(0.96, Math.pow(video.bitrateMbps / 52, 0.78)))
    : 0.04
  const spinnerProgress = isScanning
    ? 0.12 + Math.min(1, Math.max(0, video?.progress ?? 0)) * 0.82
    : Math.max(0.28, Math.min(0.86, gaugeFraction))

  // Adapter snapshot for shared WavyProgressBar
  const wavyTelemetry: TelemetrySnapshot = {
    mode: 'download',
    activeStage: 'download',
    progress: video?.progress ?? 0,
    dbm: network.targetDbm,
    gaugeFraction,
    heroMbps: video?.bitrateMbps ?? 0,
    downloadMbps: 0,
    uploadMbps: 0,
    ping: network.targetPing,
    jitter: network.targetJitter,
    stability: video?.stability ?? 1,
    phaseLabel: video?.phaseLabel ?? 'Ready',
    quality: isComplete ? 'Excellent' : 'Downloading',
  }

  // Technical telemetry derivations for modal
  const supports4K = network.targetDownloadMbps >= 350
  const supports1440 = network.targetDownloadMbps >= 140
  const effRes =
    video?.currentRes ?? (supports4K ? '4K UHD' : supports1440 ? '1440p' : '1080p')
  const effFps = video?.fps ?? (network.targetDownloadMbps >= 200 ? 60 : 30)
  const effBitrate =
    video?.bitrateMbps ?? (supports4K ? 48.6 : supports1440 ? 24.4 : 11.8)
  const effLoadMs =
    video?.loadTimeMs ?? Math.round(210 + network.targetPing * 11)
  const effBufferPct = video?.bufferHealthPct ?? 100
  const effDrops = video?.droppedFrames ?? (supports4K ? 0 : 1)

  const pixelDims =
    effRes === '4K UHD'
      ? '3840 × 2160'
      : effRes === '1440p'
        ? '2560 × 1440'
        : effRes === '1080p'
          ? '1920 × 1080'
          : effRes === '720p'
            ? '1280 × 720'
            : '854 × 480'

  const quicMs = Math.max(12, Math.round(network.targetPing * 2.1))
  const manifestMs = Math.max(18, Math.round(network.targetPing * 2.6))
  const drmMs = Math.max(32, Math.round(effLoadMs * 0.22))
  const decodeMs = Math.max(24, effLoadMs - quicMs - manifestMs - drmMs)
  const bufferAheadSec = (effBufferPct * 0.184).toFixed(1)
  const headroom = Math.max(
    1.2,
    network.targetDownloadMbps / Math.max(4, effBitrate),
  ).toFixed(1)

  const loadBarPct = video
    ? Math.max(18, Math.min(100, Math.round(100 - (video.loadTimeMs - 200) / 6)))
    : 0
  const bufferBarPct = video ? Math.max(12, video.bufferHealthPct) : 0
  const qualitySegs = video ? getResSegments(video.currentRes) : 0

  const bottomCaption = isComplete
    ? `${effRes === '4K UHD' ? '4K HDR Ready' : `${effRes} Ready`} · ${effBitrate.toFixed(1)} Mbps`
    : `Streaming · ${effBitrate.toFixed(1)} Mbps`

  const techDataByTab: Record<
    VideoTechTab,
    {
      title: string
      headline: string
      unit: string
      sub: string
      bg: string
      fg: string
      rows: Array<{ label: string; value: string }>
    }
  > = {
    load: {
      title: 'Load Time Details',
      headline: String(effLoadMs),
      unit: 'ms',
      sub: video
        ? 'Measured time to first video frame (TTFF)'
        : 'Estimated startup pipeline (run Video Test for live capture)',
      bg: 'var(--md-tile-dl-bg)',
      fg: 'var(--md-tile-dl-fg)',
      rows: [
        { label: 'QUIC / TLS 1.3 Handshake', value: `${quicMs} ms (HTTP/3)` },
        { label: 'HLS / DASH Manifest Fetch', value: `${manifestMs} ms (.m3u8)` },
        { label: 'Widevine L1 DRM License', value: `${drmMs} ms · Hardware Secure` },
        { label: 'Init Segment & Keyframe', value: `${decodeMs} ms · IDR decode` },
        {
          label: 'Startup Rendition',
          value: supports4K ? '1080p → 4K UHD ramp' : '720p → 1440p ramp',
        },
        { label: 'CDN Transport', value: `QUIC 0-RTT · ${network.band}` },
      ],
    },
    buffer: {
      title: 'Buffer Health Details',
      headline: String(effBufferPct),
      unit: '%',
      sub: video
        ? 'Measured adaptive playhead stability'
        : 'Estimated buffer headroom for your link',
      bg: 'var(--md-tile-ul-bg)',
      fg: 'var(--md-tile-ul-fg)',
      rows: [
        { label: 'Forward Playhead Buffer', value: `${bufferAheadSec} s ahead` },
        {
          label: 'Rebuffer Ratio',
          value: effDrops === 0 ? '0.00% · 0 stalls' : '0.12% · 0 stalls',
        },
        { label: 'Dropped Frames', value: `${effDrops} / ${effFps * 5} frames` },
        {
          label: 'CMAF Chunk Fetch Avg',
          value: `${Math.max(42, Math.round(network.targetPing * 6.5))} ms (2.0s seg)`,
        },
        { label: 'ABR Controller', value: 'BOLA + Throughput Hybrid' },
        { label: 'Bandwidth Headroom', value: `${headroom}× stream bitrate` },
      ],
    },
    quality: {
      title: 'Max Quality Details',
      headline: effRes,
      unit: `${effFps}fps`,
      sub: `${pixelDims} · ${effBitrate.toFixed(1)} Mbps adaptive peak`,
      bg: 'var(--md-tile-ping-bg)',
      fg: 'var(--md-tile-ping-fg)',
      rows: [
        { label: 'Active Resolution', value: `${pixelDims} @ ${effFps} fps` },
        { label: 'Peak Video Bitrate', value: `${effBitrate.toFixed(1)} Mbps (VBR)` },
        {
          label: 'Video Codec & Profile',
          value: supports4K ? 'AV1 Main 10-bit · HEVC' : 'H.265 HEVC · H.264',
        },
        {
          label: 'Dynamic Range & Color',
          value: supports4K ? 'HDR10 / PQ · BT.2020' : 'SDR · Rec.709',
        },
        {
          label: 'Chroma & Bit Depth',
          value: supports4K ? '4:2:0 · 10-bit' : '4:2:0 · 8-bit',
        },
        { label: 'Audio Track', value: 'Dolby Atmos E-AC-3 · 768 kbps' },
      ],
    },
  }

  const activeTech = inspectedTab ? techDataByTab[inspectedTab] : null

  return (
    <div className="flex w-full flex-col items-center gap-4">
      {/* HERO DIAL STAGE — Exact 1:1 visual twin of Speed Test HeroSignalGauge */}
      <LayoutGroup id="video-gauge-morph">
        <section
          aria-label="Video streaming dial"
          className="flex w-full flex-col items-center"
        >
          <div className="relative flex h-[314px] w-full max-w-[320px] items-center justify-center">
            <AnimatePresence mode="popLayout" initial={false}>
              {isIdle ? (
                <motion.div
                  key="video-idle-trigger"
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.94 }}
                  transition={{ duration: 0.22 }}
                  className="relative flex items-center justify-center"
                >
                  <div className="pointer-events-none absolute flex items-center justify-center opacity-70">
                    <MorphingStarburst
                      signalStrength={0.3}
                      status="idle"
                      size={252}
                    />
                  </div>

                  <motion.button
                    id="start-video-test-btn"
                    type="button"
                    layoutId="video-morph-container"
                    onClick={startVideoTest}
                    whileHover={{ scale: 1.04, borderRadius: '64px' }}
                    whileTap={{ scale: 0.89, borderRadius: '88px' }}
                    transition={{
                      layout: HERO_SPRING,
                      scale: { type: 'spring', stiffness: 520, damping: 18 },
                      borderRadius: {
                        type: 'spring',
                        stiffness: 420,
                        damping: 22,
                      },
                    }}
                    className="m3-tone-surface relative z-10 flex h-[204px] w-[204px] flex-col items-center justify-center gap-3 cursor-pointer select-none focus:outline-none"
                    style={{
                      borderRadius: '78px',
                      backgroundColor: 'var(--md-primary)',
                      color: 'var(--md-on-primary)',
                    }}
                  >
                    <Play className="h-7 w-7 fill-current" />
                    <div className="flex flex-col items-center">
                      <span className="font-display text-[19px] font-black tracking-[-0.02em] leading-none">
                        TEST VIDEO
                      </span>
                      <span className="mt-1.5 text-xs font-semibold opacity-80">
                        {network.band} • {durationSec}s
                      </span>
                    </div>
                  </motion.button>
                </motion.div>
              ) : (
                <motion.div
                  key="video-active-dial"
                  layoutId="video-morph-container"
                  transition={{ layout: HERO_SPRING }}
                  className="relative flex flex-col items-center justify-center rounded-full"
                  style={{ backgroundColor: 'transparent' }}
                >
                  <motion.div
                    initial={{ opacity: 0, scale: 0.84 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{
                      type: 'spring',
                      stiffness: 320,
                      damping: 24,
                      delay: 0.04,
                    }}
                  >
                    <CircularWavySpinner
                      progress={spinnerProgress}
                      status={status}
                      stability={video?.stability ?? 0.9}
                      size={264}
                      strokeWidth={22}
                      amplitude={7.6}
                      waves={9}
                      ariaLabel={`${effRes} ${effFps}fps, ${bottomCaption}`}
                    >
                      <motion.span
                        key={video?.currentRes ?? '480p'}
                        animate={isComplete ? { scale: [1, 1.06, 1] } : undefined}
                        transition={{
                          type: 'spring',
                          stiffness: 420,
                          damping: 18,
                        }}
                        className="font-display text-[54px] font-black leading-none tracking-[-0.055em] tabular-nums"
                        style={{ color: 'var(--md-on-surface)' }}
                      >
                        {shortResLabel(video?.currentRes ?? '480p')}
                      </motion.span>
                      <span
                        className="mt-1.5 font-display text-sm font-extrabold tracking-[0.02em]"
                        style={{ color: 'var(--md-on-surface-variant)' }}
                      >
                        {video?.currentRes === '4K UHD'
                          ? `UHD · ${effFps}fps`
                          : `${effFps}fps`}
                      </span>
                    </CircularWavySpinner>
                  </motion.div>

                  {/* Other measurement cleanly positioned underneath the wavy spinner */}
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25, delay: 0.08 }}
                    className="mt-3 flex items-center justify-center"
                  >
                    <span
                      className="font-display text-[17px] font-extrabold tracking-[-0.02em] tabular-nums"
                      style={{
                        color: isComplete
                          ? 'var(--md-primary)'
                          : 'var(--md-on-surface-variant)',
                      }}
                    >
                      {bottomCaption}
                    </span>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Frameless Material 3 WavyProgressBar while scanning */}
          <WavyProgressBar status={status} telemetry={wavyTelemetry} />

          {/* Clean Post-Sweep Action Row (Exact match to Speed Test) */}
          <AnimatePresence>
            {isComplete && (
              <motion.div
                key="video-complete-actions"
                initial={{ opacity: 0, y: 8, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 4, scale: 0.95 }}
                transition={{ type: 'spring', stiffness: 420, damping: 24 }}
                className="mt-4 flex flex-wrap items-center justify-center gap-2"
              >
                <motion.button
                  type="button"
                  onClick={startVideoTest}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.92 }}
                  className="m3-tone-surface inline-flex items-center gap-2 rounded-full px-5 py-2.5 font-display text-sm font-extrabold cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-primary)',
                    color: 'var(--md-on-primary)',
                  }}
                >
                  <span>Test again</span>
                </motion.button>

                <motion.button
                  type="button"
                  onClick={onReportToMap}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.93 }}
                  className="m3-tone-surface inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 font-display text-sm font-bold cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-surface-container-high)',
                    color: 'var(--md-on-surface)',
                  }}
                >
                  <MapPin className="h-4 w-4 stroke-[2.3]" />
                  <span>Report on map</span>
                </motion.button>

                <motion.button
                  type="button"
                  onClick={resetVideoTest}
                  whileHover={{ scale: 1.06 }}
                  whileTap={{ scale: 0.9, rotate: -20 }}
                  aria-label="Reset video dial"
                  title="Reset"
                  className="m3-tone-surface flex h-10 w-10 items-center justify-center rounded-full cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-surface-container-high)',
                    color: 'var(--md-on-surface-variant)',
                  }}
                >
                  <RotateCcw className="h-4 w-4 stroke-[2.3]" />
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </LayoutGroup>

      {/* SAME 4-COLUMN PIXEL COLOR-BLOCKED BOTTOM ROW: Load Time, Buffer, Quality + AI Help */}
      <section
        aria-label="Video streaming metrics and AI Assistant"
        className="grid w-full grid-cols-2 gap-3 sm:grid-cols-[1fr_1fr_1fr_118px]"
      >
        {/* BOX 1: LOAD TIME */}
        <motion.button
          id="video-tile-load"
          type="button"
          onClick={() => setInspectedTab('load')}
          aria-label="Video load time. Tap for technical streaming information."
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.96 }}
          animate={isComplete ? { scale: [1, 1.03, 1] } : { scale: 1 }}
          transition={{
            scale: { duration: 0.44, delay: 0.02, ease: [0.2, 0, 0, 1] },
            y: { type: 'spring', stiffness: 420, damping: 22 },
          }}
          className="m3-tone-surface relative flex flex-col justify-between overflow-hidden rounded-[30px] p-4 sm:p-5 text-left cursor-pointer focus:outline-none"
          style={{
            backgroundColor: 'var(--md-tile-dl-bg)',
            color: 'var(--md-tile-dl-fg)',
          }}
        >
          <div className="flex w-full items-center justify-between gap-2">
            <span
              className="font-display text-xs sm:text-sm font-extrabold tracking-[-0.02em]"
              style={{ color: 'var(--md-tile-dl-sub)' }}
            >
              Load Time
            </span>
            <span
              className="m3-tone-surface flex h-8 w-8 items-center justify-center rounded-[12px]"
              style={{
                backgroundColor: 'var(--md-tile-dl-chip)',
                color: 'var(--md-tile-dl-fg)',
              }}
            >
              {isScanning ? (
                <CircularWavySpinner
                  progress={0.52}
                  indeterminate
                  size={18}
                  strokeWidth={34}
                  amplitude={10}
                  waves={6}
                />
              ) : (
                <Tv className="h-4 w-4 stroke-[2.5]" />
              )}
            </span>
          </div>

          <div className="mt-3.5 flex items-baseline gap-1">
            <span className="font-display text-[36px] sm:text-[42px] font-black leading-none tracking-[-0.055em] tabular-nums">
              {video ? video.loadTimeMs : '—'}
            </span>
            <span
              className="font-display text-xs sm:text-sm font-extrabold"
              style={{ color: 'var(--md-tile-dl-sub)' }}
            >
              ms
            </span>
          </div>

          <div className="mt-3.5 w-full space-y-1.5">
            <div
              className="h-2 w-full overflow-hidden rounded-full"
              style={{ backgroundColor: 'var(--md-tile-dl-chip)' }}
            >
              <motion.div
                className="m3-tone-surface h-full rounded-full"
                style={{ backgroundColor: 'var(--md-tile-dl-bar)' }}
                animate={{ width: `${loadBarPct}%` }}
                transition={{ type: 'spring', stiffness: 200, damping: 26 }}
              />
            </div>
            <div
              className="flex items-center justify-between text-[10px] sm:text-[11px] font-bold"
              style={{ color: 'var(--md-tile-dl-sub)' }}
            >
              <span className="truncate">
                {isScanning
                  ? 'Measuring…'
                  : video
                    ? 'Instant start'
                    : 'Tap to test'}
              </span>
              <span className="shrink-0 ml-1">TTFF</span>
            </div>
          </div>
        </motion.button>

        {/* BOX 2: BUFFER HEALTH */}
        <motion.button
          id="video-tile-buffer"
          type="button"
          onClick={() => setInspectedTab('buffer')}
          aria-label="Video buffer health. Tap for technical streaming information."
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.96 }}
          animate={isComplete ? { scale: [1, 1.03, 1] } : { scale: 1 }}
          transition={{
            scale: { duration: 0.44, delay: 0.09, ease: [0.2, 0, 0, 1] },
            y: { type: 'spring', stiffness: 420, damping: 22 },
          }}
          className="m3-tone-surface relative flex flex-col justify-between overflow-hidden rounded-[30px] p-4 sm:p-5 text-left cursor-pointer focus:outline-none"
          style={{
            backgroundColor: 'var(--md-tile-ul-bg)',
            color: 'var(--md-tile-ul-fg)',
          }}
        >
          <div className="flex w-full items-center justify-between gap-2">
            <span
              className="font-display text-xs sm:text-sm font-extrabold tracking-[-0.02em]"
              style={{ color: 'var(--md-tile-ul-sub)' }}
            >
              Buffer
            </span>
            <span
              className="m3-tone-surface flex h-8 w-8 items-center justify-center rounded-full"
              style={{
                backgroundColor: 'var(--md-tile-ul-chip)',
                color: 'var(--md-tile-ul-fg)',
              }}
            >
              {isScanning ? (
                <CircularWavySpinner
                  progress={0.52}
                  indeterminate
                  size={18}
                  strokeWidth={34}
                  amplitude={10}
                  waves={6}
                />
              ) : (
                <MonitorPlay className="h-4 w-4 stroke-[2.5]" />
              )}
            </span>
          </div>

          <div className="mt-3.5 flex items-baseline gap-1">
            <span className="font-display text-[36px] sm:text-[42px] font-black leading-none tracking-[-0.055em] tabular-nums">
              {video ? video.bufferHealthPct : '—'}
            </span>
            <span
              className="font-display text-xs sm:text-sm font-extrabold"
              style={{ color: 'var(--md-tile-ul-sub)' }}
            >
              %
            </span>
          </div>

          <div className="mt-3.5 w-full space-y-1.5">
            <div
              className="h-2 w-full overflow-hidden rounded-full"
              style={{ backgroundColor: 'var(--md-tile-ul-chip)' }}
            >
              <motion.div
                className="m3-tone-surface h-full rounded-full"
                style={{ backgroundColor: 'var(--md-tile-ul-bar)' }}
                animate={{ width: `${bufferBarPct}%` }}
                transition={{ type: 'spring', stiffness: 200, damping: 26 }}
              />
            </div>
            <div
              className="flex items-center justify-between text-[10px] sm:text-[11px] font-bold"
              style={{ color: 'var(--md-tile-ul-sub)' }}
            >
              <span className="truncate">
                {video ? `${video.droppedFrames} drops` : 'Zero-stall'}
              </span>
              <span className="shrink-0 ml-1">HLS</span>
            </div>
          </div>
        </motion.button>

        {/* BOX 3: MAX QUALITY */}
        <motion.button
          id="video-tile-quality"
          type="button"
          onClick={() => setInspectedTab('quality')}
          aria-label="Maximum video quality. Tap for technical streaming information."
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.96 }}
          animate={isComplete ? { scale: [1, 1.03, 1] } : { scale: 1 }}
          transition={{
            scale: { duration: 0.44, delay: 0.16, ease: [0.2, 0, 0, 1] },
            y: { type: 'spring', stiffness: 420, damping: 22 },
          }}
          className="m3-tone-surface relative flex flex-col justify-between overflow-hidden rounded-[30px] p-4 sm:p-5 text-left cursor-pointer focus:outline-none"
          style={{
            backgroundColor: 'var(--md-tile-ping-bg)',
            color: 'var(--md-tile-ping-fg)',
          }}
        >
          <div className="flex w-full items-center justify-between gap-2">
            <span
              className="font-display text-xs sm:text-sm font-extrabold tracking-[-0.02em]"
              style={{ color: 'var(--md-tile-ping-sub)' }}
            >
              Quality
            </span>
            <span
              className="m3-tone-surface flex h-8 w-8 items-center justify-center rounded-[11px]"
              style={{
                backgroundColor: 'var(--md-tile-ping-chip)',
                color: 'var(--md-tile-ping-fg)',
              }}
            >
              {isScanning ? (
                <CircularWavySpinner
                  progress={0.52}
                  indeterminate
                  size={18}
                  strokeWidth={34}
                  amplitude={10}
                  waves={6}
                />
              ) : (
                <CheckCircle2 className="h-4 w-4 stroke-[2.5]" />
              )}
            </span>
          </div>

          <div className="mt-3.5 flex w-full items-baseline gap-1 flex-wrap">
            <span className="font-display text-[34px] sm:text-[40px] font-black leading-none tracking-[-0.055em]">
              {video ? shortResLabel(video.currentRes) : '—'}
            </span>
            {video && (
              <span
                className="m3-tone-surface ml-auto rounded-full px-2 py-0.5 text-[10px] font-extrabold tabular-nums"
                style={{
                  backgroundColor: 'var(--md-tile-ping-chip)',
                  color: 'var(--md-tile-ping-fg)',
                }}
              >
                {video.fps}fps
              </span>
            )}
          </div>

          <div className="mt-3.5 w-full space-y-1.5">
            <div className="grid grid-cols-4 gap-1">
              {[1, 2, 3, 4].map((seg) => (
                <span
                  key={seg}
                  className="m3-tone-surface h-2 rounded-full"
                  style={{
                    backgroundColor:
                      seg <= qualitySegs
                        ? 'var(--md-tile-ping-bar)'
                        : 'var(--md-tile-ping-chip)',
                  }}
                />
              ))}
            </div>
            <div
              className="flex items-center justify-between text-[10px] sm:text-[11px] font-bold tabular-nums"
              style={{ color: 'var(--md-tile-ping-sub)' }}
            >
              <span>{video ? (video.currentRes === '4K UHD' ? 'HDR10' : 'Crisp') : 'Adaptive'}</span>
              <span>{video ? `${video.bitrateMbps.toFixed(0)} Mbps` : '4K ready'}</span>
            </div>
          </div>
        </motion.button>

        {/* BOX 4: AI ASSISTANT WITH MAGNIFYING GLASS NEXT TO RESULTS */}
        <motion.button
          type="button"
          onClick={onAskAi}
          whileHover={{ y: -4, scale: 1.03 }}
          whileTap={{ scale: 0.92 }}
          transition={{ type: 'spring', stiffness: 460, damping: 20 }}
          aria-label="Open AI Wi-Fi Assistant to improve streaming quality"
          className="m3-tone-surface relative flex flex-col items-center justify-between overflow-hidden rounded-[30px] p-4 text-center cursor-pointer focus:outline-none"
          style={{
            backgroundColor: isPoorWifi
              ? 'var(--md-primary)'
              : 'var(--md-primary-container)',
            color: isPoorWifi
              ? 'var(--md-on-primary)'
              : 'var(--md-on-primary-container)',
          }}
        >
          <span className="font-display text-[11px] font-extrabold uppercase tracking-[0.06em] opacity-85">
            {isPoorWifi ? 'Fix Stream' : 'AI Help'}
          </span>
          <span
            className="my-2 flex h-12 w-12 items-center justify-center rounded-[18px]"
            style={{
              backgroundColor: isPoorWifi
                ? 'rgba(255, 255, 255, 0.18)'
                : 'var(--md-surface-container-lowest)',
              color: isPoorWifi ? 'var(--md-on-primary)' : 'var(--md-primary)',
            }}
          >
            <AiMagnifierIcon className="h-6 w-6" />
          </span>
          <span className="font-display text-xs font-extrabold leading-tight">
            {isPoorWifi ? 'Boost video' : 'Analyze'}
          </span>
        </motion.button>
      </section>

      {/* AI WI-FI ASSISTANT CHATBOT AT THE BOTTOM (Identical to Speed Test) */}
      <AiWifiAssistant
        context={aiContext}
        isOpen={aiChatOpen}
        onToggleOpen={onToggleAiChat}
        diagnoseTriggerCount={diagnoseTriggerCount}
      />

      {/* Video Technical Details Modal */}
      <AnimatePresence>
        {inspectedTab && activeTech && (
          <motion.div
            id="video-tech-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setInspectedTab(null)}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 sm:p-6"
            style={{
              backgroundColor: 'rgba(11, 20, 15, 0.52)',
              backdropFilter: 'blur(10px)',
            }}
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label={activeTech.title}
              initial={{ opacity: 0, y: 28, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.96 }}
              transition={{ type: 'spring', stiffness: 420, damping: 28 }}
              onClick={(e) => e.stopPropagation()}
              className="m3-tone-surface relative w-full max-w-[490px] max-h-[88vh] overflow-y-auto rounded-[34px] p-5 sm:p-6 shadow-2xl"
              style={{
                backgroundColor: 'var(--md-surface)',
                color: 'var(--md-on-surface)',
                border: '1px solid var(--md-outline-variant)',
              }}
            >
              <div className="flex items-center justify-between gap-3">
                <div>
                  <span
                    className="text-[11px] font-extrabold uppercase tracking-[0.08em]"
                    style={{ color: 'var(--md-primary)' }}
                  >
                    Video Streaming Telemetry
                  </span>
                  <h2 className="font-display text-2xl font-black tracking-[-0.035em]">
                    {activeTech.title}
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => setInspectedTab(null)}
                  aria-label="Close video technical details"
                  className="m3-tone-surface flex h-10 w-10 items-center justify-center rounded-full cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-surface-container-high)',
                    color: 'var(--md-on-surface-variant)',
                  }}
                >
                  <X className="h-5 w-5 stroke-[2.4]" />
                </button>
              </div>

              <div
                className="mt-4 grid grid-cols-3 gap-1 rounded-full p-1"
                style={{ backgroundColor: 'var(--md-surface-container-high)' }}
              >
                {(
                  [
                    { id: 'load', label: 'Load Time', icon: Tv },
                    { id: 'buffer', label: 'Buffer', icon: MonitorPlay },
                    { id: 'quality', label: 'Quality', icon: CheckCircle2 },
                  ] as const
                ).map((tab) => {
                  const Icon = tab.icon
                  const selected = inspectedTab === tab.id
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setInspectedTab(tab.id)}
                      className="inline-flex items-center justify-center gap-1.5 rounded-full py-2 font-display text-xs font-extrabold cursor-pointer transition-colors"
                      style={{
                        backgroundColor: selected
                          ? 'var(--md-primary)'
                          : 'transparent',
                        color: selected
                          ? 'var(--md-on-primary)'
                          : 'var(--md-on-surface-variant)',
                      }}
                    >
                      <Icon className="h-3.5 w-3.5 stroke-[2.4]" />
                      <span>{tab.label}</span>
                    </button>
                  )
                })}
              </div>

              <div
                className="mt-4 flex items-center justify-between gap-3 rounded-[24px] px-5 py-4"
                style={{
                  backgroundColor: activeTech.bg,
                  color: activeTech.fg,
                }}
              >
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-display text-[40px] font-black leading-none tracking-[-0.05em] tabular-nums">
                      {activeTech.headline}
                    </span>
                    <span className="font-display text-sm font-extrabold opacity-80">
                      {activeTech.unit}
                    </span>
                  </div>
                  <p className="mt-1 text-xs font-semibold opacity-80">
                    {activeTech.sub}
                  </p>
                </div>
                <span
                  className="shrink-0 rounded-full px-3 py-1 font-display text-[11px] font-extrabold"
                  style={{ backgroundColor: 'rgba(255, 255, 255, 0.22)' }}
                >
                  {network.ssid}
                </span>
              </div>

              <div
                className="mt-4 divide-y rounded-[24px] px-4 py-1"
                style={{
                  backgroundColor: 'var(--md-surface-container)',
                  borderColor: 'var(--md-outline-variant)',
                }}
              >
                {activeTech.rows.map((row) => (
                  <div
                    key={row.label}
                    className="flex items-center justify-between gap-3 py-2.5 text-xs"
                    style={{ borderColor: 'var(--md-outline-variant)' }}
                  >
                    <span
                      className="font-semibold"
                      style={{ color: 'var(--md-on-surface-variant)' }}
                    >
                      {row.label}
                    </span>
                    <span className="text-right font-display font-bold tabular-nums">
                      {row.value}
                    </span>
                  </div>
                ))}
              </div>

              <div
                className="mt-4 flex items-start gap-2.5 rounded-[20px] px-4 py-3 text-xs leading-relaxed"
                style={{
                  backgroundColor: 'var(--md-surface-container-low)',
                  color: 'var(--md-on-surface-variant)',
                }}
              >
                <Info className="mt-0.5 h-4 w-4 shrink-0 opacity-80" />
                <p className="m-0">
                  <strong className="font-bold">Note:</strong> This is technical
                  streaming information and isn&apos;t meant for the average user.
                  You only need the main Video Test screen showing{' '}
                  <strong className="font-bold">Load Time</strong>,{' '}
                  <strong className="font-bold">Buffer</strong>, and{' '}
                  <strong className="font-bold">Quality</strong>.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

import { motion } from 'framer-motion'
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  MapPin,
  Settings,
} from 'lucide-react'
import type { NavTab } from '../data/networks'

interface FloatingNavBarProps {
  activeTab: NavTab
  onSelectTab: (tab: NavTab) => void
  reportCount: number
  disabled?: boolean
}

const NAV_ITEMS: Array<{
  id: NavTab
  label: string
  icon: typeof ArrowDown
}> = [
  { id: 'download', label: 'Download', icon: ArrowDown },
  { id: 'upload', label: 'Upload', icon: ArrowUp },
  { id: 'both', label: 'Both', icon: ArrowUpDown },
  { id: 'map', label: 'Map', icon: MapPin },
  { id: 'settings', label: 'Settings', icon: Settings },
]

export function FloatingNavBar({
  activeTab,
  onSelectTab,
  reportCount,
  disabled = false,
}: FloatingNavBarProps) {
  return (
    <nav
      aria-label="Primary navigation"
      className="fixed bottom-4 left-1/2 z-40 -translate-x-1/2 px-3 w-full max-w-[460px] flex justify-center pointer-events-none"
    >
      <div
        className="m3-tone-surface pointer-events-auto flex items-center gap-1 rounded-full p-1.5 shadow-2xl"
        style={{
          backgroundColor: 'var(--md-surface-container-highest)',
          border: '1px solid var(--md-outline-variant)',
          boxShadow:
            '0 14px 36px -10px rgba(0,0,0,0.22), 0 4px 12px -4px var(--md-ambient-glow)',
        }}
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id
          const Icon = item.icon

          return (
            <motion.button
              key={item.id}
              id={`nav-tab-${item.id}`}
              type="button"
              disabled={disabled && !isActive}
              onClick={() => onSelectTab(item.id)}
              whileTap={disabled ? undefined : { scale: 0.91 }}
              transition={{ type: 'spring', stiffness: 520, damping: 24 }}
              aria-current={isActive ? 'page' : undefined}
              className="relative flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1.5 rounded-full px-3 sm:px-3.5 py-2 text-[11px] sm:text-xs font-bold tracking-[-0.01em] cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed focus:outline-none"
              style={{
                color: isActive
                  ? 'var(--md-on-primary-container)'
                  : 'var(--md-on-surface-variant)',
              }}
            >
              {isActive && (
                <motion.span
                  layoutId="m3e-floating-nav-pill"
                  transition={{
                    type: 'spring',
                    stiffness: 420,
                    damping: 28,
                    mass: 0.85,
                  }}
                  className="m3-tone-surface absolute inset-0 rounded-full"
                  style={{
                    backgroundColor: 'var(--md-primary-container)',
                  }}
                />
              )}

              <span className="relative z-10 flex items-center">
                <Icon className="h-[17px] w-[17px] stroke-[2.4]" />
                {item.id === 'map' && reportCount > 0 && (
                  <span
                    className="m3-tone-surface absolute -top-1.5 -right-2 flex h-3.5 min-w-[14px] items-center justify-center rounded-full px-1 text-[9px] font-extrabold tabular-nums"
                    style={{
                      backgroundColor: 'var(--md-primary)',
                      color: 'var(--md-on-primary)',
                    }}
                  >
                    {reportCount}
                  </span>
                )}
              </span>

              <span className="relative z-10 font-display leading-none">
                {item.label}
              </span>
            </motion.button>
          )
        })}
      </div>
    </nav>
  )
}

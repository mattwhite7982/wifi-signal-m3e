import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowDown,
  ArrowUp,
  LocateFixed,
  LocateOff,
  MapPin,
  MapPinPlus,
  Send,
  SignalHigh,
  X,
} from 'lucide-react'
import { useCallback, useEffect, useMemo, useState, type MouseEvent } from 'react'
import {
  formatSpeed,
  type MapReport,
  type SpeedUnit,
  type WifiNetwork,
} from '../data/networks'
import { CircularWavySpinner } from './CircularWavySpinner'

interface SignalMapViewProps {
  reports: MapReport[]
  onAddReport: (report: Omit<MapReport, 'id' | 'reportedAt'>) => void
  latestMeasurement: {
    downloadMbps: number
    uploadMbps: number
    dbm: number
    ping: number
    ssid: string
    band: WifiNetwork['band']
  }
  unit: SpeedUnit
  startInReportMode?: boolean
  onClearStartReportMode?: () => void
}

type LocationPermissionState =
  | 'idle'
  | 'requesting'
  | 'granted'
  | 'denied'
  | 'unavailable'

interface UserCoords {
  lat: number
  lng: number
  accuracy: number
}

function getTierColor(downloadMbps: number): {
  bg: string
  fg: string
  ring: string
} {
  if (downloadMbps >= 500) {
    return { bg: '#00a862', fg: '#ffffff', ring: 'rgba(0, 185, 107, 0.28)' }
  }
  if (downloadMbps >= 200) {
    return { bg: '#00897b', fg: '#ffffff', ring: 'rgba(0, 152, 135, 0.26)' }
  }
  return { bg: '#c47c00', fg: '#ffffff', ring: 'rgba(212, 138, 0, 0.28)' }
}

function formatCoords(coords: UserCoords): string {
  const latDir = coords.lat >= 0 ? 'N' : 'S'
  const lngDir = coords.lng >= 0 ? 'E' : 'W'
  return `${Math.abs(coords.lat).toFixed(3)}°${latDir}, ${Math.abs(coords.lng).toFixed(3)}°${lngDir}`
}

export function SignalMapView({
  reports,
  onAddReport,
  latestMeasurement,
  unit,
  startInReportMode = false,
  onClearStartReportMode,
}: SignalMapViewProps) {
  const [bandFilter, setBandFilter] = useState<
    'ALL' | '6 GHz' | '5 GHz' | '2.4 GHz'
  >('ALL')
  const [selectedReportId, setSelectedReportId] = useState<string | null>(
    reports[0]?.id ?? null,
  )
  const [draftPin, setDraftPin] = useState<{ x: number; y: number } | null>(
    startInReportMode ? { x: 50, y: 48 } : null,
  )

  const [locationState, setLocationState] =
    useState<LocationPermissionState>('idle')
  const [locationMessage, setLocationMessage] = useState<string>('')
  const [userCoords, setUserCoords] = useState<UserCoords | null>(null)

  const [locationName, setLocationName] = useState('My Spot')
  const [downloadInput, setDownloadInput] = useState(
    String(latestMeasurement.downloadMbps),
  )
  const [uploadInput, setUploadInput] = useState(
    String(latestMeasurement.uploadMbps),
  )
  const [dbmInput, setDbmInput] = useState(String(latestMeasurement.dbm))
  const [noteInput, setNoteInput] = useState('')

  const requestLocation = useCallback(() => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setLocationState('unavailable')
      setLocationMessage(
        'Location services are unavailable in this browser. Tap anywhere on the map to report manually.',
      )
      return
    }

    setLocationState('requesting')
    setLocationMessage('Waiting for browser location permission…')

    try {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy),
          })
          setLocationState('granted')
          setLocationMessage('')
        },
        (err) => {
          if (err.code === err.PERMISSION_DENIED) {
            setLocationState('denied')
            setLocationMessage(
              'Location permission is not enabled. Enable location access in your browser to center on your spot, or tap anywhere on the map to drop a pin manually.',
            )
          } else if (err.code === err.TIMEOUT) {
            setLocationState('denied')
            setLocationMessage(
              'Location request timed out. Tap Try again or place a pin manually on the map.',
            )
          } else {
            setLocationState('unavailable')
            setLocationMessage(
              'Could not determine your current location. You can still tap anywhere on the map to report speeds.',
            )
          }
        },
        {
          enableHighAccuracy: false,
          timeout: 8000,
          maximumAge: 60000,
        },
      )
    } catch {
      setLocationState('unavailable')
      setLocationMessage(
        'Location permission could not be requested in this view. Tap anywhere on the map to drop a pin manually.',
      )
    }
  }, [])

  // Prompt for real browser location permission when the Map opens
  useEffect(() => {
    let active = true
    const initLocation = async () => {
      if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
        if (active) {
          setLocationState('unavailable')
          setLocationMessage(
            'Location services are unavailable in this browser. Tap anywhere on the map to drop a pin manually.',
          )
        }
        return
      }

      if (navigator.permissions?.query) {
        try {
          const perm = await navigator.permissions.query({
            name: 'geolocation',
          })
          if (!active) return
          if (perm.state === 'denied') {
            setLocationState('denied')
            setLocationMessage(
              'Location permission is not enabled. Enable location access in your browser to tag your area automatically, or tap anywhere on the map to drop a pin manually.',
            )
            return
          }
        } catch {
          // Permissions API may not support geolocation query in some browsers
        }
      }

      if (active) {
        requestLocation()
      }
    }

    initLocation()
    return () => {
      active = false
    }
  }, [requestLocation])

  const filteredReports = useMemo(
    () =>
      bandFilter === 'ALL'
        ? reports
        : reports.filter((r) => r.band === bandFilter),
    [reports, bandFilter],
  )

  const selectedReport = useMemo(
    () => reports.find((r) => r.id === selectedReportId) ?? null,
    [reports, selectedReportId],
  )

  const areaStats = useMemo(() => {
    if (filteredReports.length === 0) {
      return { avgDl: 0, avgUl: 0, count: 0 }
    }
    const dlSum = filteredReports.reduce((acc, r) => acc + r.downloadMbps, 0)
    const ulSum = filteredReports.reduce((acc, r) => acc + r.uploadMbps, 0)
    return {
      avgDl: Math.round(dlSum / filteredReports.length),
      avgUl: Math.round(ulSum / filteredReports.length),
      count: filteredReports.length,
    }
  }, [filteredReports])

  const openReportAt = (x: number, y: number) => {
    setDraftPin({ x, y })
    setSelectedReportId(null)
    setDownloadInput(String(latestMeasurement.downloadMbps))
    setUploadInput(String(latestMeasurement.uploadMbps))
    setDbmInput(String(latestMeasurement.dbm))
    if (userCoords && x === 50 && y === 48) {
      setLocationName(`Near ${formatCoords(userCoords)}`)
    }
    onClearStartReportMode?.()
  }

  const handleMapClick = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = Math.max(
      8,
      Math.min(92, ((e.clientX - rect.left) / rect.width) * 100),
    )
    const y = Math.max(
      10,
      Math.min(90, ((e.clientY - rect.top) / rect.height) * 100),
    )
    openReportAt(Math.round(x), Math.round(y))
  }

  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault()
    if (!draftPin) return

    const dl = Math.max(
      1,
      Math.min(10000, Number(downloadInput) || latestMeasurement.downloadMbps),
    )
    const ul = Math.max(
      1,
      Math.min(10000, Number(uploadInput) || latestMeasurement.uploadMbps),
    )
    const dbm = Math.max(
      -95,
      Math.min(-25, Number(dbmInput) || latestMeasurement.dbm),
    )

    onAddReport({
      x: draftPin.x,
      y: draftPin.y,
      locationName: locationName.trim() || 'Community Hotspot',
      ssid: latestMeasurement.ssid,
      band: latestMeasurement.band,
      downloadMbps: dl,
      uploadMbps: ul,
      dbm,
      ping: latestMeasurement.ping,
      note: noteInput.trim() || undefined,
      isUserReport: true,
    })

    setDraftPin(null)
    setNoteInput('')
    setLocationName('My Spot')
  }

  const avgDlFmt = formatSpeed(areaStats.avgDl, unit)
  const avgUlFmt = formatSpeed(areaStats.avgUl, unit)

  return (
    <div className="flex w-full flex-col gap-4">
      {/* In-App Location Permission Banner (Shown cleanly when not enabled or requesting) */}
      <AnimatePresence mode="wait">
        {locationState === 'granted' && userCoords ? (
          <motion.div
            key="loc-granted"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="m3-tone-surface flex flex-wrap items-center justify-between gap-2 rounded-[22px] px-4 py-2.5 text-xs"
            style={{
              backgroundColor: 'var(--md-primary-container)',
              color: 'var(--md-on-primary-container)',
            }}
          >
            <div className="flex items-center gap-2 font-bold">
              <LocateFixed className="h-4 w-4 shrink-0 stroke-[2.4]" />
              <span>Location enabled</span>
              <span className="opacity-75 font-semibold tabular-nums">
                · {formatCoords(userCoords)}
              </span>
            </div>
            <button
              type="button"
              onClick={() => openReportAt(50, 48)}
              className="rounded-full px-3 py-1 font-display text-[11px] font-extrabold cursor-pointer"
              style={{
                backgroundColor: 'var(--md-primary)',
                color: 'var(--md-on-primary)',
              }}
            >
              Report at my location
            </button>
          </motion.div>
        ) : locationState === 'requesting' ? (
          <motion.div
            key="loc-requesting"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="m3-tone-surface flex items-center gap-2.5 rounded-[22px] px-4 py-3 text-xs font-semibold"
            style={{
              backgroundColor: 'var(--md-surface-container-high)',
              color: 'var(--md-on-surface)',
            }}
          >
            <CircularWavySpinner
              progress={0.52}
              indeterminate
              size={22}
              strokeWidth={32}
              amplitude={10}
              waves={6}
            />
            <span>{locationMessage}</span>
          </motion.div>
        ) : (
          <motion.div
            key="loc-disabled"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            role="status"
            className="m3-tone-surface flex flex-wrap items-center justify-between gap-3 rounded-[24px] px-4 py-3.5"
            style={{
              backgroundColor: 'var(--md-surface-container-high)',
              color: 'var(--md-on-surface)',
            }}
          >
            <div className="flex items-start gap-2.5 min-w-0 flex-1">
              <span
                className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
                style={{
                  backgroundColor: 'var(--md-surface-container-lowest)',
                  color: 'var(--md-on-surface-variant)',
                }}
              >
                <LocateOff className="h-4 w-4 stroke-[2.3]" />
              </span>
              <div className="min-w-0">
                <div className="font-display text-xs font-extrabold">
                  Location permission not enabled
                </div>
                <p
                  className="mt-0.5 text-xs leading-snug"
                  style={{ color: 'var(--md-on-surface-variant)' }}
                >
                  {locationMessage ||
                    'Allow location access to center on your area, or tap anywhere on the map to report manually.'}
                </p>
              </div>
            </div>
            <button
              id="enable-location-btn"
              type="button"
              onClick={requestLocation}
              className="shrink-0 rounded-full px-4 py-2 font-display text-xs font-extrabold cursor-pointer transition-transform active:scale-95"
              style={{
                backgroundColor: 'var(--md-primary)',
                color: 'var(--md-on-primary)',
              }}
            >
              {locationState === 'denied' ? 'Try again' : 'Allow location'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Band Filters + Report CTA */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex flex-wrap items-center gap-1.5">
          {(['ALL', '6 GHz', '5 GHz', '2.4 GHz'] as const).map((band) => {
            const active = bandFilter === band
            return (
              <button
                key={band}
                type="button"
                onClick={() => setBandFilter(band)}
                className="m3-tone-surface rounded-full px-3 py-1.5 text-xs font-bold cursor-pointer transition-transform active:scale-95"
                style={{
                  backgroundColor: active
                    ? 'var(--md-primary)'
                    : 'var(--md-surface-container-high)',
                  color: active
                    ? 'var(--md-on-primary)'
                    : 'var(--md-on-surface-variant)',
                }}
              >
                {band === 'ALL' ? 'All Bands' : band}
              </button>
            )
          })}
        </div>

        <motion.button
          id="drop-map-pin-btn"
          type="button"
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.93 }}
          onClick={() => openReportAt(50, 48)}
          className="m3-tone-surface inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 font-display text-xs font-extrabold cursor-pointer"
          style={{
            backgroundColor: 'var(--md-primary-container)',
            color: 'var(--md-on-primary-container)',
          }}
        >
          <MapPinPlus className="h-3.5 w-3.5 stroke-[2.5]" />
          <span>Report Measurement</span>
        </motion.button>
      </div>

      {/* Interactive Stylized M3E Vector Map */}
      <div className="m3-tone-surface m3-tonal-card relative overflow-hidden rounded-[32px] p-3">
        <div
          id="signal-map-canvas"
          onClick={handleMapClick}
          role="region"
          aria-label="Crowd-reported Wi-Fi signal map. Click anywhere to report a measurement."
          className="relative h-[320px] sm:h-[345px] w-full overflow-hidden rounded-[24px] cursor-crosshair select-none"
          style={{
            backgroundColor: 'var(--md-surface-container-low)',
          }}
        >
          <svg
            viewBox="0 0 640 360"
            preserveAspectRatio="xMidYMid slice"
            className="pointer-events-none absolute inset-0 h-full w-full"
            aria-hidden="true"
          >
            <path
              d="M 40 20 Q 190 10 215 110 Q 170 155 60 140 Z"
              style={{ fill: 'var(--md-primary-container)', opacity: 0.25 }}
            />
            <path
              d="M 0 305 Q 190 270 360 315 T 640 285 L 640 360 L 0 360 Z"
              style={{ fill: 'var(--md-tertiary-container)', opacity: 0.42 }}
            />
            <rect x="245" y="42" width="118" height="72" rx="16" style={{ fill: 'var(--md-surface-container-high)', opacity: 0.7 }} />
            <rect x="392" y="42" width="160" height="82" rx="18" style={{ fill: 'var(--md-surface-container-high)', opacity: 0.7 }} />
            <rect x="85" y="168" width="136" height="84" rx="18" style={{ fill: 'var(--md-surface-container-high)', opacity: 0.65 }} />
            <rect x="255" y="148" width="142" height="104" rx="20" style={{ fill: 'var(--md-surface-container-high)', opacity: 0.72 }} />
            <rect x="428" y="156" width="150" height="96" rx="18" style={{ fill: 'var(--md-surface-container-high)', opacity: 0.65 }} />
            <g fill="none" strokeLinecap="round" style={{ stroke: 'var(--md-surface-container-lowest)', opacity: 0.85 }}>
              <path d="M 0 145 L 640 138" strokeWidth="10" />
              <path d="M 0 264 L 640 256" strokeWidth="8" />
              <path d="M 228 0 L 236 330" strokeWidth="10" />
              <path d="M 380 0 L 412 340" strokeWidth="8" />
              <path d="M 555 0 L 580 310" strokeWidth="6" />
            </g>
            <g className="font-display text-[11px] font-bold" style={{ fill: 'var(--md-on-surface-variant)', opacity: 0.55 }}>
              <text x="86" y="78">CIVIC PARK</text>
              <text x="414" y="88">TECH COMMONS</text>
              <text x="278" y="205">HARBOR LIBRARY</text>
              <text x="454" y="210">CEDAR DISTRICT</text>
              <text x="116" y="232">STATION HUB</text>
            </g>
          </svg>

          <div
            className="pointer-events-none absolute top-3 left-3 z-10 rounded-full px-3 py-1 text-[11px] font-semibold"
            style={{
              backgroundColor: 'var(--md-surface-container-lowest)',
              color: 'var(--md-on-surface-variant)',
              opacity: 0.92,
            }}
          >
            Tap anywhere on map to drop a pin
          </div>

          {/* Live User GPS Location Dot when permission is granted */}
          {locationState === 'granted' && userCoords && (
            <div
              style={{ left: '50%', top: '48%' }}
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 z-10 flex items-center justify-center"
              aria-label="Your current location"
            >
              <span className="absolute h-10 w-10 rounded-full bg-blue-500/20 animate-ping" />
              <span className="relative h-4 w-4 rounded-full bg-blue-500 border-[2.5px] border-white shadow-md" />
            </div>
          )}

          {/* Crowd-Reported Measurement Pins */}
          <AnimatePresence>
            {filteredReports.map((report) => {
              const tier = getTierColor(report.downloadMbps)
              const isSelected = selectedReport?.id === report.id && !draftPin
              const dlFmt = formatSpeed(report.downloadMbps, unit)

              return (
                <motion.button
                  key={report.id}
                  type="button"
                  initial={{ scale: 0, y: -16, opacity: 0 }}
                  animate={{ scale: isSelected ? 1.14 : 1, y: 0, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 460, damping: 20 }}
                  onClick={(e) => {
                    e.stopPropagation()
                    setDraftPin(null)
                    setSelectedReportId(report.id)
                  }}
                  style={{
                    left: `${report.x}%`,
                    top: `${report.y}%`,
                  }}
                  aria-label={`${report.locationName}: ${report.downloadMbps} Mbps download`}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer focus:outline-none"
                >
                  <span
                    className="pointer-events-none absolute h-11 w-11 rounded-full"
                    style={{
                      backgroundColor: tier.ring,
                      transform: isSelected ? 'scale(1.35)' : 'scale(1)',
                      transition: 'transform 220ms ease',
                    }}
                  />
                  <span
                    className="relative inline-flex items-center gap-1 rounded-full px-2.5 py-1 font-display text-[11px] font-extrabold tabular-nums shadow-md"
                    style={{
                      backgroundColor: tier.bg,
                      color: tier.fg,
                      boxShadow: isSelected
                        ? '0 0 0 3px var(--md-surface-container-lowest), 0 6px 16px rgba(0,0,0,0.22)'
                        : '0 4px 10px rgba(0,0,0,0.18)',
                    }}
                  >
                    {report.isUserReport && (
                      <span className="h-1.5 w-1.5 rounded-full bg-white" />
                    )}
                    {dlFmt.value}
                    <span className="text-[9px] font-semibold opacity-85">
                      {dlFmt.unitLabel}
                    </span>
                  </span>
                </motion.button>
              )
            })}
          </AnimatePresence>

          {/* Draft Pin Preview */}
          {draftPin && (
            <motion.div
              initial={{ scale: 0, y: -18 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ type: 'spring', stiffness: 500, damping: 18 }}
              style={{ left: `${draftPin.x}%`, top: `${draftPin.y}%` }}
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 z-30 flex flex-col items-center"
            >
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full shadow-lg"
                style={{
                  backgroundColor: 'var(--md-primary)',
                  color: 'var(--md-on-primary)',
                  boxShadow: '0 0 0 4px var(--md-surface-container-lowest)',
                }}
              >
                <MapPin className="h-4 w-4 stroke-[2.5]" />
              </span>
            </motion.div>
          )}
        </div>

        {/* Report Composer OR Selected Pin Inspector */}
        <AnimatePresence mode="wait">
          {draftPin ? (
            <motion.form
              key="report-composer"
              onSubmit={handleSubmitReport}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              transition={{ type: 'spring', stiffness: 420, damping: 26 }}
              className="mt-3 rounded-[24px] p-4 space-y-3"
              style={{ backgroundColor: 'var(--md-surface-container-high)' }}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <MapPinPlus className="h-4 w-4" style={{ color: 'var(--md-primary)' }} />
                  <h3 className="font-display text-sm font-extrabold">
                    Publish Measurement Report
                  </h3>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{
                      backgroundColor: 'var(--md-primary-container)',
                      color: 'var(--md-on-primary-container)',
                    }}
                  >
                    {latestMeasurement.ssid} • {latestMeasurement.band}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setDraftPin(null)}
                  aria-label="Cancel report"
                  className="flex h-7 w-7 items-center justify-center rounded-full cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-surface-container)',
                    color: 'var(--md-on-surface-variant)',
                  }}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                <label className="sm:col-span-2 flex flex-col gap-1 text-[11px] font-bold" style={{ color: 'var(--md-on-surface-variant)' }}>
                  Location Name
                  <input
                    type="text"
                    required
                    value={locationName}
                    onChange={(e) => setLocationName(e.target.value)}
                    placeholder="e.g. North Courtyard"
                    className="rounded-[14px] px-3 py-2 text-xs font-semibold outline-none"
                    style={{
                      backgroundColor: 'var(--md-surface-container-lowest)',
                      color: 'var(--md-on-surface)',
                    }}
                  />
                </label>

                <label className="flex flex-col gap-1 text-[11px] font-bold" style={{ color: 'var(--md-on-surface-variant)' }}>
                  Down (Mbps)
                  <input
                    type="number"
                    min={1}
                    max={10000}
                    value={downloadInput}
                    onChange={(e) => setDownloadInput(e.target.value)}
                    className="rounded-[14px] px-3 py-2 text-xs font-bold tabular-nums outline-none"
                    style={{
                      backgroundColor: 'var(--md-surface-container-lowest)',
                      color: 'var(--md-on-surface)',
                    }}
                  />
                </label>

                <label className="flex flex-col gap-1 text-[11px] font-bold" style={{ color: 'var(--md-on-surface-variant)' }}>
                  Up (Mbps)
                  <input
                    type="number"
                    min={1}
                    max={10000}
                    value={uploadInput}
                    onChange={(e) => setUploadInput(e.target.value)}
                    className="rounded-[14px] px-3 py-2 text-xs font-bold tabular-nums outline-none"
                    style={{
                      backgroundColor: 'var(--md-surface-container-lowest)',
                      color: 'var(--md-on-surface)',
                    }}
                  />
                </label>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <input
                  type="text"
                  value={noteInput}
                  onChange={(e) => setNoteInput(e.target.value)}
                  placeholder="Optional note (e.g. Fast near window, 4K ready)…"
                  className="flex-1 min-w-[180px] rounded-[14px] px-3 py-2 text-xs font-medium outline-none"
                  style={{
                    backgroundColor: 'var(--md-surface-container-lowest)',
                    color: 'var(--md-on-surface)',
                  }}
                />
                <input
                  type="number"
                  min={-95}
                  max={-25}
                  value={dbmInput}
                  onChange={(e) => setDbmInput(e.target.value)}
                  aria-label="Signal dBm"
                  className="w-20 rounded-[14px] px-2.5 py-2 text-xs font-bold tabular-nums outline-none"
                  style={{
                    backgroundColor: 'var(--md-surface-container-lowest)',
                    color: 'var(--md-on-surface)',
                  }}
                />
                <motion.button
                  id="submit-map-report-btn"
                  type="submit"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.94 }}
                  className="inline-flex items-center gap-1.5 rounded-full px-5 py-2 font-display text-xs font-extrabold cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-primary)',
                    color: 'var(--md-on-primary)',
                  }}
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Post to Map</span>
                </motion.button>
              </div>
            </motion.form>
          ) : selectedReport ? (
            <motion.div
              key={selectedReport.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-[24px] p-4"
              style={{ backgroundColor: 'var(--md-surface-container-high)' }}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-display text-sm font-extrabold">
                    {selectedReport.locationName}
                  </h3>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{
                      backgroundColor: 'var(--md-primary-container)',
                      color: 'var(--md-on-primary-container)',
                    }}
                  >
                    {selectedReport.ssid} • {selectedReport.band}
                  </span>
                  {selectedReport.isUserReport && (
                    <span
                      className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                      style={{
                        backgroundColor: 'var(--md-primary)',
                        color: 'var(--md-on-primary)',
                      }}
                    >
                      Your Report
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs" style={{ color: 'var(--md-on-surface-variant)' }}>
                  {selectedReport.note ?? 'Verified community measurement'} • {selectedReport.reportedAt}
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-bold tabular-nums">
                <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1" style={{ backgroundColor: 'var(--md-surface-container-lowest)' }}>
                  <ArrowDown className="h-3.5 w-3.5" style={{ color: 'var(--md-primary)' }} />
                  {formatSpeed(selectedReport.downloadMbps, unit).value}{' '}
                  {formatSpeed(selectedReport.downloadMbps, unit).unitLabel}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1" style={{ backgroundColor: 'var(--md-surface-container-lowest)' }}>
                  <ArrowUp className="h-3.5 w-3.5" style={{ color: 'var(--md-primary)' }} />
                  {formatSpeed(selectedReport.uploadMbps, unit).value}{' '}
                  {formatSpeed(selectedReport.uploadMbps, unit).unitLabel}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1" style={{ backgroundColor: 'var(--md-surface-container-lowest)' }}>
                  <SignalHigh className="h-3.5 w-3.5" style={{ color: 'var(--md-primary)' }} />
                  {selectedReport.dbm} dBm
                </span>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>

      {/* Pixel Color-Blocked Area Summary Tiles */}
      <div className="grid grid-cols-3 gap-3">
        <div
          className="m3-tone-surface rounded-[28px] p-4"
          style={{
            backgroundColor: 'var(--md-tile-ping-bg)',
            color: 'var(--md-tile-ping-fg)',
          }}
        >
          <div className="font-display text-xs font-extrabold" style={{ color: 'var(--md-tile-ping-sub)' }}>
            Reports
          </div>
          <div className="mt-2 font-display text-3xl font-black tabular-nums">
            {areaStats.count}
          </div>
        </div>
        <div
          className="m3-tone-surface rounded-[28px] p-4"
          style={{
            backgroundColor: 'var(--md-tile-dl-bg)',
            color: 'var(--md-tile-dl-fg)',
          }}
        >
          <div className="font-display text-xs font-extrabold" style={{ color: 'var(--md-tile-dl-sub)' }}>
            Area Down
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-3xl font-black tabular-nums">
              {avgDlFmt.value}
            </span>
            <span className="text-xs font-bold" style={{ color: 'var(--md-tile-dl-sub)' }}>
              {avgDlFmt.unitLabel}
            </span>
          </div>
        </div>
        <div
          className="m3-tone-surface rounded-[28px] p-4"
          style={{
            backgroundColor: 'var(--md-tile-ul-bg)',
            color: 'var(--md-tile-ul-fg)',
          }}
        >
          <div className="font-display text-xs font-extrabold" style={{ color: 'var(--md-tile-ul-sub)' }}>
            Area Up
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-display text-3xl font-black tabular-nums">
              {avgUlFmt.value}
            </span>
            <span className="text-xs font-bold" style={{ color: 'var(--md-tile-ul-sub)' }}>
              {avgUlFmt.unitLabel}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

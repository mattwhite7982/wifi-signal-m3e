import { AnimatePresence, motion } from 'framer-motion'
import { Check, ChevronDown, Moon, Signal, Sun, Wifi, WifiOff } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import type { TestStatus, WifiNetwork } from '../data/networks'
import type { LiveConnectionInfo } from '../utils/networkStatus'

interface TopBarProps {
  pageTitle: string
  pageSubtitle: string
  networks: WifiNetwork[]
  selectedNetwork: WifiNetwork
  onSelectNetwork: (network: WifiNetwork) => void
  status: TestStatus
  liveDbm?: number | null
  connectionInfo: LiveConnectionInfo
  theme: 'light' | 'dark'
  onToggleTheme: () => void
}

export function TopBar({
  pageTitle,
  pageSubtitle,
  networks,
  selectedNetwork,
  onSelectNetwork,
  status,
  liveDbm,
  connectionInfo,
  theme,
  onToggleTheme,
}: TopBarProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false)
      }
    }
    if (menuOpen) {
      document.addEventListener('mousedown', handleOutside)
    }
    return () => document.removeEventListener('mousedown', handleOutside)
  }, [menuOpen])

  const isScanning = status === 'scanning'
  const isCellular = connectionInfo.transport === 'cellular'
  const isOffline = connectionInfo.transport === 'offline'

  return (
    <header className="relative z-30 flex w-full flex-col gap-3.5 pt-1">
      {/* Top Row: Connected Wi-Fi / Mobile Data Tonal Pill Badge + Theme Toggle */}
      <div className="flex w-full items-center justify-between gap-2.5">
        <div ref={menuRef} className="relative min-w-0">
          <motion.button
            id="ssid-selector-pill"
            type="button"
            disabled={isScanning}
            onClick={() => setMenuOpen((prev) => !prev)}
            whileHover={isScanning ? undefined : { scale: 1.02 }}
            whileTap={isScanning ? undefined : { scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 500, damping: 24 }}
            aria-expanded={menuOpen}
            aria-haspopup="listbox"
            aria-label={
              isOffline
                ? 'Offline — no connection'
                : isCellular
                  ? `Connected to ${connectionInfo.label}`
                  : `Connected to Wi-Fi ${selectedNetwork.ssid} on ${selectedNetwork.band}`
            }
            className="m3-tone-surface flex items-center gap-2 rounded-full py-2 pl-2.5 pr-2.5 cursor-pointer disabled:cursor-default focus:outline-none max-w-full"
            style={{
              backgroundColor: 'var(--md-surface-container-high)',
              color: 'var(--md-on-surface)',
            }}
          >
            <span
              className="m3-tone-surface flex h-6 w-6 shrink-0 items-center justify-center rounded-full"
              style={{
                backgroundColor: isCellular
                  ? 'var(--md-tertiary-container)'
                  : isOffline
                    ? 'var(--md-surface-container-highest)'
                    : 'var(--md-primary-container)',
                color: isCellular
                  ? 'var(--md-on-tertiary-container)'
                  : isOffline
                    ? 'var(--md-on-surface-variant)'
                    : 'var(--md-on-primary-container)',
              }}
            >
              {isOffline ? (
                <WifiOff className="h-3.5 w-3.5 stroke-[2.5]" />
              ) : isCellular ? (
                <Signal className="h-3.5 w-3.5 stroke-[2.6]" />
              ) : (
                <Wifi className="h-3.5 w-3.5 stroke-[2.6]" />
              )}
            </span>

            <span className="font-display text-sm font-bold tracking-[-0.02em] truncate max-w-[130px] sm:max-w-[180px]">
              {isOffline
                ? 'Offline'
                : isCellular
                  ? 'Mobile Data'
                  : selectedNetwork.ssid}
            </span>

            <span
              className="m3-tone-surface inline-flex shrink-0 items-center rounded-full px-2.5 py-0.5 font-display text-[11px] font-extrabold tracking-[0.01em]"
              style={{
                backgroundColor: isCellular
                  ? 'var(--md-tertiary-container)'
                  : 'var(--md-primary-container)',
                color: isCellular
                  ? 'var(--md-on-tertiary-container)'
                  : 'var(--md-on-primary-container)',
              }}
            >
              {isOffline
                ? 'No Signal'
                : isCellular
                  ? connectionInfo.cellularGen ?? 'Cellular'
                  : `Wi-Fi · ${selectedNetwork.band}`}
            </span>

            {liveDbm !== null && liveDbm !== undefined && !isOffline && (
              <span
                className="m3-tone-surface hidden sm:inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-[11px] font-bold tabular-nums"
                style={{
                  backgroundColor: 'var(--md-surface-container-lowest)',
                  color: 'var(--md-primary)',
                }}
              >
                {liveDbm} dBm
              </span>
            )}

            <ChevronDown
              className={`h-4 w-4 shrink-0 transition-transform duration-200 ${
                menuOpen ? 'rotate-180' : ''
              } ${isScanning ? 'opacity-35' : 'opacity-70'}`}
              style={{ color: 'var(--md-on-surface-variant)' }}
            />
          </motion.button>

          {/* M3E Tonal Network Switcher Popover */}
          <AnimatePresence>
            {menuOpen && !isScanning && (
              <motion.div
                role="listbox"
                initial={{ opacity: 0, y: -8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.96 }}
                transition={{ type: 'spring', stiffness: 460, damping: 28 }}
                className="m3-tone-surface absolute top-[calc(100%+10px)] left-0 w-[276px] rounded-[26px] p-2 shadow-xl"
                style={{
                  backgroundColor: 'var(--md-surface-container-highest)',
                  border: '1px solid var(--md-outline-variant)',
                }}
              >
                <div
                  className="px-3 pt-1.5 pb-2 text-[11px] font-bold uppercase tracking-[0.08em]"
                  style={{ color: 'var(--md-on-surface-variant)' }}
                >
                  Connected Network
                </div>
                <div className="space-y-1">
                  {networks.map((net) => {
                    const active = net.id === selectedNetwork.id
                    return (
                      <button
                        key={net.id}
                        type="button"
                        role="option"
                        aria-selected={active}
                        onClick={() => {
                          onSelectNetwork(net)
                          setMenuOpen(false)
                        }}
                        className="flex w-full items-center justify-between rounded-[18px] px-3 py-2.5 text-left transition-colors cursor-pointer"
                        style={{
                          backgroundColor: active
                            ? 'var(--md-primary-container)'
                            : 'transparent',
                          color: active
                            ? 'var(--md-on-primary-container)'
                            : 'var(--md-on-surface)',
                        }}
                      >
                        <div className="min-w-0">
                          <div className="font-display text-sm font-bold tracking-[-0.01em] truncate">
                            {net.ssid}
                          </div>
                          <div className="text-[11px] opacity-75">
                            {net.standard} • Ch {net.channel} ({net.channelWidth})
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0 ml-2">
                          <span
                            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                            style={{
                              backgroundColor: active
                                ? 'var(--md-primary)'
                                : 'var(--md-surface-container)',
                              color: active
                                ? 'var(--md-on-primary)'
                                : 'var(--md-on-surface-variant)',
                            }}
                          >
                            {net.band}
                          </span>
                          {active && <Check className="h-3.5 w-3.5 stroke-[2.6]" />}
                        </div>
                      </button>
                    )
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Expressive Pixel Theme Toggle */}
        <motion.button
          id="theme-toggle-btn"
          type="button"
          onClick={onToggleTheme}
          whileHover={{ scale: 1.07 }}
          whileTap={{ scale: 0.9, rotate: 18 }}
          transition={{ type: 'spring', stiffness: 480, damping: 20 }}
          aria-label={
            theme === 'light'
              ? 'Switch to dark Pixel theme'
              : 'Switch to light Pixel theme'
          }
          className="m3-tone-surface flex h-10 w-10 items-center justify-center rounded-full cursor-pointer"
          style={{
            backgroundColor: 'var(--md-surface-container-high)',
            color: 'var(--md-on-surface-variant)',
          }}
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={theme}
              initial={{ rotate: -45, scale: 0.6, opacity: 0 }}
              animate={{ rotate: 0, scale: 1, opacity: 1 }}
              exit={{ rotate: 45, scale: 0.6, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {theme === 'light' ? (
                <Moon className="h-[18px] w-[18px] stroke-[2.2]" />
              ) : (
                <Sun className="h-[18px] w-[18px] stroke-[2.2]" />
              )}
            </motion.span>
          </AnimatePresence>
        </motion.button>
      </div>

      {/* Large Left-Aligned Google Pixel Expressive Page Title */}
      <div className="flex flex-col items-start px-0.5">
        <AnimatePresence mode="wait">
          <motion.div
            key={pageTitle}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ type: 'spring', stiffness: 420, damping: 28 }}
          >
            <h1
              className="font-display text-[40px] sm:text-[48px] font-black leading-[1.02] tracking-[-0.045em]"
              style={{ color: 'var(--md-on-surface)' }}
            >
              {pageTitle}
            </h1>
            <p
              className="mt-1.5 text-sm font-medium tracking-[-0.01em]"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              {pageSubtitle}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Live Mobile Data / Offline Notice */}
      <AnimatePresence>
        {(isCellular || isOffline) && (
          <motion.div
            key={connectionInfo.transport}
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            role="status"
            className="m3-tone-surface flex items-center gap-2.5 rounded-[20px] px-4 py-2.5 text-xs font-semibold"
            style={{
              backgroundColor: isCellular
                ? 'var(--md-tertiary-container)'
                : 'var(--md-surface-container-highest)',
              color: isCellular
                ? 'var(--md-on-tertiary-container)'
                : 'var(--md-on-surface)',
            }}
          >
            {isOffline ? (
              <WifiOff className="h-4 w-4 shrink-0 stroke-[2.3]" />
            ) : (
              <Signal className="h-4 w-4 shrink-0 stroke-[2.4]" />
            )}
            <span className="leading-snug">
              {isOffline
                ? 'Offline — reconnect to Wi-Fi or mobile data to run live tests.'
                : `On ${connectionInfo.label} — tests will use mobile data instead of Wi-Fi.`}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

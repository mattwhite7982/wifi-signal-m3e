import { motion } from 'framer-motion'
import {
  Check,
  Gauge,
  MapPin,
  Palette,
  RotateCcw,
  Server,
  Signal,
  Smartphone,
  Sparkles,
  Trash2,
  Vibrate,
  Wifi,
  WifiOff,
} from 'lucide-react'
import { useMemo } from 'react'
import {
  checkDeviceColorCompatibility,
  COLOR_PALETTES,
  TEST_SERVERS,
  type AppSettings,
  type SpeedUnit,
} from '../data/networks'
import {
  getHapticsStrengthLabel,
  isHapticsSupported,
  triggerHaptic,
} from '../utils/haptics'
import type { LiveConnectionInfo } from '../utils/networkStatus'

interface SettingsViewProps {
  settings: AppSettings
  onUpdateSettings: (patch: Partial<AppSettings>) => void
  theme: 'light' | 'dark'
  onSetTheme: (theme: 'light' | 'dark') => void
  connectionInfo: LiveConnectionInfo
  userReportCount: number
  onClearUserReports: () => void
  onReplayOnboarding: () => void
}

function M3Switch({
  checked,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean
  onChange: (next: boolean) => void
  label: string
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      role="switch"
      disabled={disabled}
      aria-checked={checked}
      aria-label={label}
      onClick={() => !disabled && onChange(!checked)}
      className="m3-tone-surface relative flex h-8 w-14 shrink-0 items-center rounded-full p-1 cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed focus:outline-none"
      style={{
        backgroundColor: checked
          ? 'var(--md-primary)'
          : 'var(--md-surface-container-highest)',
        border: checked ? 'none' : '1.5px solid var(--md-outline-variant)',
      }}
    >
      <motion.span
        layout
        transition={{ type: 'spring', stiffness: 520, damping: 26 }}
        className="block rounded-full"
        style={{
          width: checked ? 22 : 16,
          height: checked ? 22 : 16,
          marginLeft: checked ? 'auto' : 2,
          backgroundColor: checked
            ? 'var(--md-on-primary)'
            : 'var(--md-on-surface-variant)',
        }}
      />
    </button>
  )
}

export function SettingsView({
  settings,
  onUpdateSettings,
  theme,
  onSetTheme,
  connectionInfo,
  userReportCount,
  onClearUserReports,
  onReplayOnboarding,
}: SettingsViewProps) {
  const deviceColorSupport = useMemo(() => checkDeviceColorCompatibility(), [])
  const hapticsSupported = useMemo(() => isHapticsSupported(), [])
  const strengthLabel = getHapticsStrengthLabel(settings.hapticsStrength)

  return (
    <div className="flex w-full flex-col gap-4">
      {/* Group 1: Appearance, App Color & Device Dynamic Color */}
      <section className="m3-tone-surface m3-tonal-card rounded-[28px] p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-full"
            style={{
              backgroundColor: 'var(--md-primary-container)',
              color: 'var(--md-on-primary-container)',
            }}
          >
            <Palette className="h-4 w-4 stroke-[2.3]" />
          </span>
          <div>
            <h2 className="font-display text-base font-extrabold tracking-[-0.02em]">
              Appearance &amp; Pixel Colors
            </h2>
            <p
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              App color palette, device Material You sync, and typography
            </p>
          </div>
        </div>

        {/* Light / Dark Segmented Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div>
            <div className="text-sm font-bold">Surface Mode</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Switch between Daylight and Nocturne M3E
            </div>
          </div>
          <div
            className="flex items-center gap-1 rounded-full p-1"
            style={{ backgroundColor: 'var(--md-surface-container-high)' }}
          >
            {(['light', 'dark'] as const).map((t) => {
              const active = theme === t
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => onSetTheme(t)}
                  className="rounded-full px-4 py-1.5 font-display text-xs font-bold capitalize cursor-pointer transition-colors"
                  style={{
                    backgroundColor: active ? 'var(--md-primary)' : 'transparent',
                    color: active
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {t}
                </button>
              )
            })}
          </div>
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        {/* Match Device Colors (Material You / System AccentColor) */}
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-sm font-bold">
              <Smartphone className="h-3.5 w-3.5 opacity-80" />
              <span>Use Device Colors</span>
              <span
                className="rounded-full px-2 py-0.5 text-[10px] font-extrabold"
                style={{
                  backgroundColor: deviceColorSupport.supported
                    ? 'var(--md-primary-container)'
                    : 'var(--md-surface-container-high)',
                  color: deviceColorSupport.supported
                    ? 'var(--md-on-primary-container)'
                    : 'var(--md-on-surface-variant)',
                }}
              >
                {deviceColorSupport.supported ? 'Compatible' : 'Unsupported'}
              </span>
            </div>
            <div
              className="mt-0.5 text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              {deviceColorSupport.detail}
            </div>
          </div>
          <M3Switch
            checked={deviceColorSupport.supported && settings.matchDeviceColors}
            disabled={!deviceColorSupport.supported}
            onChange={(val) => onUpdateSettings({ matchDeviceColors: val })}
            label="Use Device Colors"
          />
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        {/* Custom App Color Swatch Picker */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <div className="text-sm font-bold">App Color</div>
              <div
                className="text-xs"
                style={{ color: 'var(--md-on-surface-variant)' }}
              >
                {settings.matchDeviceColors && deviceColorSupport.supported
                  ? 'Following your phone/device color theme'
                  : 'Choose a Material 3 Expressive color palette'}
              </div>
            </div>
          </div>

          <div
            className={`grid grid-cols-3 sm:grid-cols-6 gap-2 transition-opacity ${
              settings.matchDeviceColors && deviceColorSupport.supported
                ? 'opacity-45 pointer-events-none'
                : 'opacity-100'
            }`}
          >
            {COLOR_PALETTES.map((pal) => {
              const active =
                !settings.matchDeviceColors && settings.colorPalette === pal.id
              return (
                <motion.button
                  key={pal.id}
                  id={`palette-${pal.id}`}
                  type="button"
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.93 }}
                  onClick={() =>
                    onUpdateSettings({
                      colorPalette: pal.id,
                      matchDeviceColors: false,
                    })
                  }
                  className="m3-tone-surface flex flex-col items-center gap-1.5 rounded-[20px] px-2 py-2.5 cursor-pointer"
                  style={{
                    backgroundColor: active
                      ? 'var(--md-primary-container)'
                      : 'var(--md-surface-container-high)',
                    color: active
                      ? 'var(--md-on-primary-container)'
                      : 'var(--md-on-surface)',
                  }}
                >
                  <span
                    className="relative flex h-8 w-8 items-center justify-center rounded-full shadow-sm"
                    style={{
                      background: `linear-gradient(135deg, ${pal.swatch} 55%, ${pal.containerSwatch} 55%)`,
                    }}
                  >
                    {active && (
                      <Check className="h-4 w-4 text-white drop-shadow stroke-[3]" />
                    )}
                  </span>
                  <span className="font-display text-[11px] font-bold">
                    {pal.label}
                  </span>
                </motion.button>
              )
            })}
          </div>
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        {/* Dynamic Emerald Tonal Shift Toggle */}
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold">Dynamic Tonal Shift</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Shift surface tones dynamically during and after speed tests
            </div>
          </div>
          <M3Switch
            checked={settings.dynamicTone}
            onChange={(val) => onUpdateSettings({ dynamicTone: val })}
            label="Dynamic Tonal Shift"
          />
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        {/* Pixel Typography Style Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-bold">Pixel Typography</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Switch between Pixel Display (M3E) and Retro Pixel font
            </div>
          </div>
          <div
            className="flex items-center gap-1 rounded-full p-1"
            style={{ backgroundColor: 'var(--md-surface-container-high)' }}
          >
            {(
              [
                { id: 'pixel-display', label: 'Pixel M3E' },
                { id: 'pixel-retro', label: 'Pixel Retro' },
              ] as const
            ).map((opt) => {
              const active = settings.fontStyle === opt.id
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onUpdateSettings({ fontStyle: opt.id })}
                  className="rounded-full px-3.5 py-1.5 font-display text-xs font-bold cursor-pointer transition-colors"
                  style={{
                    backgroundColor: active ? 'var(--md-primary)' : 'transparent',
                    color: active
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {opt.label}
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* Group 2: Haptics & Soft-to-Firm Vibrations */}
      <section className="m3-tone-surface m3-tonal-card rounded-[28px] p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-full"
            style={{
              backgroundColor: 'var(--md-primary-container)',
              color: 'var(--md-on-primary-container)',
            }}
          >
            <Vibrate className="h-4 w-4 stroke-[2.3]" />
          </span>
          <div>
            <h2 className="font-display text-base font-extrabold tracking-[-0.02em]">
              Haptics &amp; Vibrations
            </h2>
            <p
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Tactile pulses on taps, test sweeps &amp; results
            </p>
          </div>
        </div>

        {/* Enable / Disable Soft Vibrations */}
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-sm font-bold">
              <span>Soft Vibrations</span>
              <span
                className="rounded-full px-2 py-0.5 text-[10px] font-extrabold"
                style={{
                  backgroundColor: hapticsSupported
                    ? 'var(--md-primary-container)'
                    : 'var(--md-surface-container-high)',
                  color: hapticsSupported
                    ? 'var(--md-on-primary-container)'
                    : 'var(--md-on-surface-variant)',
                }}
              >
                {hapticsSupported ? 'Ready' : 'Android / Mobile'}
              </span>
            </div>
            <div
              className="mt-0.5 text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Uses Capacitor Haptics on Android &amp; Vibration API on mobile web
            </div>
          </div>
          <M3Switch
            checked={settings.hapticsEnabled}
            onChange={(val) => {
              onUpdateSettings({ hapticsEnabled: val })
              if (val) {
                void triggerHaptic('tap', {
                  enabled: true,
                  strength: settings.hapticsStrength,
                })
              }
            }}
            label="Soft Vibrations"
          />
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        {/* Soft-to-Firm Strength Slider + Presets + Test Feel */}
        <div
          className={`space-y-3 transition-opacity ${
            settings.hapticsEnabled
              ? 'opacity-100'
              : 'opacity-45 pointer-events-none'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2 text-sm font-bold">
                <span>Vibration Feel</span>
                <span
                  className="rounded-full px-2.5 py-0.5 font-display text-[11px] font-extrabold tabular-nums"
                  style={{
                    backgroundColor: 'var(--md-primary-container)',
                    color: 'var(--md-on-primary-container)',
                  }}
                >
                  {strengthLabel} · {settings.hapticsStrength}%
                </span>
              </div>
              <div
                className="text-xs"
                style={{ color: 'var(--md-on-surface-variant)' }}
              >
                Slide from whisper-soft taps to firm confirmation pulses
              </div>
            </div>

            <motion.button
              id="test-haptics-btn"
              type="button"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.92 }}
              onClick={() =>
                void triggerHaptic('start', {
                  enabled: true,
                  strength: settings.hapticsStrength,
                })
              }
              className="m3-tone-surface shrink-0 rounded-full px-3.5 py-1.5 font-display text-xs font-extrabold cursor-pointer"
              style={{
                backgroundColor: 'var(--md-primary)',
                color: 'var(--md-on-primary)',
              }}
            >
              Test feel
            </motion.button>
          </div>

          <div className="space-y-1.5">
            <input
              id="haptics-strength-slider"
              type="range"
              min={10}
              max={100}
              step={5}
              value={settings.hapticsStrength}
              aria-label="Vibration strength from soft to firm"
              onChange={(e) => {
                const next = Number(e.target.value)
                onUpdateSettings({ hapticsStrength: next })
                void triggerHaptic('tap', { enabled: true, strength: next })
              }}
              className="w-full cursor-pointer accent-[var(--md-primary)]"
              style={{ accentColor: 'var(--md-primary)' }}
            />
            <div
              className="flex items-center justify-between text-[11px] font-bold"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              <span>Soft</span>
              <span>Balanced</span>
              <span>Firm</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { label: 'Soft', val: 25 },
                { label: 'Balanced', val: 55 },
                { label: 'Firm', val: 90 },
              ] as const
            ).map((preset) => {
              const active = strengthLabel === preset.label
              return (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => {
                    onUpdateSettings({ hapticsStrength: preset.val })
                    void triggerHaptic('tap', {
                      enabled: true,
                      strength: preset.val,
                    })
                  }}
                  className="m3-tone-surface rounded-full py-1.5 font-display text-xs font-bold cursor-pointer"
                  style={{
                    backgroundColor: active
                      ? 'var(--md-primary)'
                      : 'var(--md-surface-container-high)',
                    color: active
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {preset.label}
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* Group 3: Live Connection Detection (Wi-Fi vs Mobile Data) */}
      <section className="m3-tone-surface m3-tonal-card rounded-[28px] p-5 space-y-4">
        <div className="flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <span
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full"
              style={{
                backgroundColor:
                  connectionInfo.transport === 'cellular'
                    ? 'var(--md-tertiary-container)'
                    : 'var(--md-primary-container)',
                color:
                  connectionInfo.transport === 'cellular'
                    ? 'var(--md-on-tertiary-container)'
                    : 'var(--md-on-primary-container)',
              }}
            >
              {connectionInfo.transport === 'offline' ? (
                <WifiOff className="h-4 w-4 stroke-[2.3]" />
              ) : connectionInfo.transport === 'cellular' ? (
                <Signal className="h-4 w-4 stroke-[2.4]" />
              ) : (
                <Wifi className="h-4 w-4 stroke-[2.4]" />
              )}
            </span>
            <div className="min-w-0">
              <h2 className="font-display text-base font-extrabold tracking-[-0.02em]">
                Connection Detection
              </h2>
              <p
                className="text-xs truncate"
                style={{ color: 'var(--md-on-surface-variant)' }}
              >
                Live Wi-Fi vs. Mobile Data status ({connectionInfo.source})
              </p>
            </div>
          </div>

          <span
            className="shrink-0 rounded-full px-3 py-1 font-display text-xs font-extrabold"
            style={{
              backgroundColor:
                connectionInfo.transport === 'cellular'
                  ? 'var(--md-tertiary-container)'
                  : connectionInfo.transport === 'offline'
                    ? 'var(--md-surface-container-highest)'
                    : 'var(--md-primary-container)',
              color:
                connectionInfo.transport === 'cellular'
                  ? 'var(--md-on-tertiary-container)'
                  : connectionInfo.transport === 'offline'
                    ? 'var(--md-on-surface-variant)'
                    : 'var(--md-on-primary-container)',
            }}
          >
            {connectionInfo.label}
          </span>
        </div>

        <p
          className="text-xs leading-relaxed"
          style={{ color: 'var(--md-on-surface-variant)' }}
        >
          {connectionInfo.detail}
        </p>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-bold">Network Mode</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Keep Auto on Android for real Wi-Fi / Cellular detection
            </div>
          </div>
          <div
            className="flex items-center gap-1 rounded-full p-1"
            style={{ backgroundColor: 'var(--md-surface-container-high)' }}
          >
            {(
              [
                { id: 'auto', label: 'Auto' },
                { id: 'wifi', label: 'Wi-Fi' },
                { id: 'cellular', label: 'Data' },
              ] as const
            ).map((opt) => {
              const active = settings.connectionOverride === opt.id
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    onUpdateSettings({ connectionOverride: opt.id })
                    void triggerHaptic('tap', {
                      enabled: settings.hapticsEnabled,
                      strength: settings.hapticsStrength,
                    })
                  }}
                  className="rounded-full px-3.5 py-1.5 font-display text-xs font-bold cursor-pointer transition-colors"
                  style={{
                    backgroundColor: active ? 'var(--md-primary)' : 'transparent',
                    color: active
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {opt.label}
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* Group 4: Speed Test & Server Preferences */}
      <section className="m3-tone-surface m3-tonal-card rounded-[28px] p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-full"
            style={{
              backgroundColor: 'var(--md-secondary-container)',
              color: 'var(--md-on-secondary-container)',
            }}
          >
            <Gauge className="h-4 w-4 stroke-[2.3]" />
          </span>
          <div>
            <h2 className="font-display text-base font-extrabold tracking-[-0.02em]">
              Speed Test Engine
            </h2>
            <p
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Units, sweep duration, and edge server routing
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-bold">Display Unit</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Applies to hero dial, metric tiles &amp; map pins
            </div>
          </div>
          <div
            className="flex items-center gap-1 rounded-full p-1"
            style={{ backgroundColor: 'var(--md-surface-container-high)' }}
          >
            {(['Mbps', 'MB/s', 'Gbps'] as SpeedUnit[]).map((u) => {
              const active = settings.unit === u
              return (
                <button
                  key={u}
                  type="button"
                  onClick={() => onUpdateSettings({ unit: u })}
                  className="rounded-full px-3.5 py-1.5 font-display text-xs font-bold cursor-pointer transition-colors"
                  style={{
                    backgroundColor: active ? 'var(--md-primary)' : 'transparent',
                    color: active
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {u}
                </button>
              )
            })}
          </div>
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-bold">Sweep Duration</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Standard 5s sweep or quick 3s check
            </div>
          </div>
          <div
            className="flex items-center gap-1 rounded-full p-1"
            style={{ backgroundColor: 'var(--md-surface-container-high)' }}
          >
            {([3, 5] as const).map((sec) => {
              const active = settings.durationSec === sec
              return (
                <button
                  key={sec}
                  type="button"
                  onClick={() => onUpdateSettings({ durationSec: sec })}
                  className="rounded-full px-4 py-1.5 font-display text-xs font-bold cursor-pointer transition-colors"
                  style={{
                    backgroundColor: active ? 'var(--md-primary)' : 'transparent',
                    color: active
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {sec}s
                </button>
              )
            })}
          </div>
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        <div className="space-y-2.5">
          <div className="flex items-center gap-1.5 text-sm font-bold">
            <Server className="h-3.5 w-3.5 opacity-75" />
            <span>Test Edge Server</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {TEST_SERVERS.map((srv) => {
              const active = settings.server === srv.id
              return (
                <button
                  key={srv.id}
                  type="button"
                  onClick={() => onUpdateSettings({ server: srv.id })}
                  className="m3-tone-surface flex items-center justify-between rounded-[16px] px-3.5 py-2.5 text-left text-xs font-bold cursor-pointer"
                  style={{
                    backgroundColor: active
                      ? 'var(--md-primary-container)'
                      : 'var(--md-surface-container-high)',
                    color: active
                      ? 'var(--md-on-primary-container)'
                      : 'var(--md-on-surface)',
                  }}
                >
                  <span className="truncate">{srv.name}</span>
                  <span className="ml-2 shrink-0 text-[10px] opacity-75 tabular-nums">
                    +{srv.latencyBase}ms
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* Group 3: Crowd Map & Onboarding */}
      <section className="m3-tone-surface m3-tonal-card rounded-[28px] p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-full"
            style={{
              backgroundColor: 'var(--md-tertiary-container)',
              color: 'var(--md-on-tertiary-container)',
            }}
          >
            <MapPin className="h-4 w-4 stroke-[2.3]" />
          </span>
          <div>
            <h2 className="font-display text-base font-extrabold tracking-[-0.02em]">
              Crowd Map &amp; Onboarding
            </h2>
            <p
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Community reporting and walkthrough controls
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold">Auto-Report Completed Tests</div>
            <div
              className="text-xs"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              Automatically plot finished speed sweeps on the Crowd Map
            </div>
          </div>
          <M3Switch
            checked={settings.autoReportToMap}
            onChange={(val) => onUpdateSettings({ autoReportToMap: val })}
            label="Auto-Report Completed Tests"
          />
        </div>

        <div
          className="h-px w-full opacity-50"
          style={{ backgroundColor: 'var(--md-outline-variant)' }}
        />

        <div className="flex flex-wrap items-center justify-between gap-2.5">
          <motion.button
            id="replay-onboarding-btn"
            type="button"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.94 }}
            onClick={onReplayOnboarding}
            className="m3-tone-surface inline-flex items-center gap-2 rounded-full px-4 py-2 font-display text-xs font-extrabold cursor-pointer"
            style={{
              backgroundColor: 'var(--md-primary-container)',
              color: 'var(--md-on-primary-container)',
            }}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Replay Onboarding</span>
          </motion.button>

          <motion.button
            type="button"
            disabled={userReportCount === 0}
            whileHover={userReportCount > 0 ? { scale: 1.03 } : undefined}
            whileTap={userReportCount > 0 ? { scale: 0.94 } : undefined}
            onClick={onClearUserReports}
            className="m3-tone-surface inline-flex items-center gap-1.5 rounded-full px-4 py-2 font-display text-xs font-extrabold cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed"
            style={{
              backgroundColor: 'var(--md-surface-container-high)',
              color: 'var(--md-on-surface-variant)',
            }}
          >
            {userReportCount > 0 ? (
              <Trash2 className="h-3.5 w-3.5" />
            ) : (
              <RotateCcw className="h-3.5 w-3.5" />
            )}
            <span>Clear My Reports ({userReportCount})</span>
          </motion.button>
        </div>
      </section>
    </div>
  )
}

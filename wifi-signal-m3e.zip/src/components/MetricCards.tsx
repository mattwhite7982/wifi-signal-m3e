import { motion } from 'framer-motion'
import { Activity, ArrowDown, ArrowUp } from 'lucide-react'
import {
  formatSpeed,
  getSignalBarsFromDbm,
  type SpeedTestMode,
  type SpeedUnit,
  type TelemetrySnapshot,
  type TestStatus,
  type WifiNetwork,
} from '../data/networks'
import { AiMagnifierIcon } from './AiWifiAssistant'
import { CircularWavySpinner } from './CircularWavySpinner'
import type { TechnicalMetricTab } from './MetricTechnicalModal'

interface MetricCardsProps {
  mode: SpeedTestMode
  status: TestStatus
  telemetry: TelemetrySnapshot
  lastKnownDownload: number
  lastKnownUpload: number
  network: WifiNetwork
  unit: SpeedUnit
  isPoorWifi: boolean
  onAskAi: () => void
  onInspectMetric: (metric: TechnicalMetricTab) => void
}

export function MetricCards({
  mode,
  status,
  telemetry,
  lastKnownDownload,
  lastKnownUpload,
  network,
  unit,
  isPoorWifi,
  onAskAi,
  onInspectMetric,
}: MetricCardsProps) {
  const isIdle = status === 'idle'
  const isScanning = status === 'scanning'
  const isComplete = status === 'complete'

  const displayDlMbps =
    telemetry.downloadMbps > 0 ? telemetry.downloadMbps : lastKnownDownload
  const displayUlMbps =
    telemetry.uploadMbps > 0 ? telemetry.uploadMbps : lastKnownUpload

  const dl = formatSpeed(displayDlMbps, unit)
  const ul = formatSpeed(displayUlMbps, unit)

  const dlFillPct = Math.min(100, Math.round((displayDlMbps / 1000) * 100))
  const ulFillPct = Math.min(100, Math.round((displayUlMbps / 600) * 100))
  const activeBars = isIdle ? 0 : getSignalBarsFromDbm(telemetry.dbm)

  const dlActive = isScanning && telemetry.activeStage === 'download'
  const ulActive = isScanning && telemetry.activeStage === 'upload'

  return (
    <section
      aria-label="Download, Upload, Ping, and AI Assistant"
      className="grid w-full grid-cols-2 gap-3 sm:grid-cols-[1fr_1fr_1fr_118px]"
    >
      {/* BOX 1: PIXEL DOWNLOAD TILE (Tap for technical details) */}
      <motion.button
        id="metric-card-download"
        type="button"
        onClick={() => onInspectMetric('download')}
        aria-label="Download speed. Tap for technical information."
        whileHover={{ y: -4, scale: 1.015 }}
        whileTap={{ scale: 0.96 }}
        animate={
          isComplete
            ? { scale: [1, 1.03, 1] }
            : dlActive
              ? { scale: 1.015 }
              : { scale: 1 }
        }
        transition={{
          scale: { duration: 0.44, delay: 0.02, ease: [0.2, 0, 0, 1] },
          y: { type: 'spring', stiffness: 420, damping: 22 },
        }}
        className="m3-tone-surface relative flex flex-col justify-between overflow-hidden rounded-[30px] p-4 sm:p-5 text-left cursor-pointer focus:outline-none"
        style={{
          backgroundColor: 'var(--md-tile-dl-bg)',
          color: 'var(--md-tile-dl-fg)',
        }}
      >
        <div className="flex items-center justify-between gap-2">
          <span
            className="font-display text-xs sm:text-sm font-extrabold tracking-[-0.02em]"
            style={{ color: 'var(--md-tile-dl-sub)' }}
          >
            Download
          </span>
          <span
            className="m3-tone-surface flex h-8 w-8 items-center justify-center rounded-[12px]"
            style={{
              backgroundColor: 'var(--md-tile-dl-chip)',
              color: 'var(--md-tile-dl-fg)',
            }}
          >
            {dlActive ? (
              <CircularWavySpinner
                progress={0.52}
                indeterminate
                size={18}
                strokeWidth={34}
                amplitude={10}
                waves={6}
              />
            ) : (
              <ArrowDown className="h-4 w-4 stroke-[2.7]" />
            )}
          </span>
        </div>

        <div className="mt-3.5 flex items-baseline gap-1">
          <span className="font-display text-[36px] sm:text-[42px] font-black leading-none tracking-[-0.055em] tabular-nums">
            {displayDlMbps > 0 ? dl.value : '—'}
          </span>
          <span
            className="font-display text-xs sm:text-sm font-extrabold"
            style={{ color: 'var(--md-tile-dl-sub)' }}
          >
            {dl.unitLabel}
          </span>
        </div>

        <div className="mt-3.5 space-y-1.5">
          <div
            className="h-2 w-full overflow-hidden rounded-full"
            style={{ backgroundColor: 'var(--md-tile-dl-chip)' }}
          >
            <motion.div
              className="m3-tone-surface h-full rounded-full"
              style={{ backgroundColor: 'var(--md-tile-dl-bar)' }}
              animate={{
                width: `${displayDlMbps > 0 ? Math.max(10, dlFillPct) : 0}%`,
              }}
              transition={{ type: 'spring', stiffness: 200, damping: 26 }}
            />
          </div>
          <div
            className="flex items-center justify-between text-[10px] sm:text-[11px] font-bold"
            style={{ color: 'var(--md-tile-dl-sub)' }}
          >
            <span className="truncate">
              {dlActive
                ? 'Measuring…'
                : displayDlMbps > 0
                  ? `${network.band} peak`
                  : 'Tap to test'}
            </span>
            <span className="shrink-0 ml-1">{network.channelWidth}</span>
          </div>
        </div>
      </motion.button>

      {/* BOX 2: PIXEL UPLOAD TILE (Tap for technical details) */}
      <motion.button
        id="metric-card-upload"
        type="button"
        onClick={() => onInspectMetric('upload')}
        aria-label="Upload speed. Tap for technical information."
        whileHover={{ y: -4, scale: 1.015 }}
        whileTap={{ scale: 0.96 }}
        animate={
          isComplete
            ? { scale: [1, 1.03, 1] }
            : ulActive
              ? { scale: 1.015 }
              : { scale: 1 }
        }
        transition={{
          scale: { duration: 0.44, delay: 0.09, ease: [0.2, 0, 0, 1] },
          y: { type: 'spring', stiffness: 420, damping: 22 },
        }}
        className="m3-tone-surface relative flex flex-col justify-between overflow-hidden rounded-[30px] p-4 sm:p-5 text-left cursor-pointer focus:outline-none"
        style={{
          backgroundColor: 'var(--md-tile-ul-bg)',
          color: 'var(--md-tile-ul-fg)',
        }}
      >
        <div className="flex items-center justify-between gap-2">
          <span
            className="font-display text-xs sm:text-sm font-extrabold tracking-[-0.02em]"
            style={{ color: 'var(--md-tile-ul-sub)' }}
          >
            Upload
          </span>
          <span
            className="m3-tone-surface flex h-8 w-8 items-center justify-center rounded-full"
            style={{
              backgroundColor: 'var(--md-tile-ul-chip)',
              color: 'var(--md-tile-ul-fg)',
            }}
          >
            {ulActive ? (
              <CircularWavySpinner
                progress={0.52}
                indeterminate
                size={18}
                strokeWidth={34}
                amplitude={10}
                waves={6}
              />
            ) : (
              <ArrowUp className="h-4 w-4 stroke-[2.7]" />
            )}
          </span>
        </div>

        <div className="mt-3.5 flex items-baseline gap-1">
          <span className="font-display text-[36px] sm:text-[42px] font-black leading-none tracking-[-0.055em] tabular-nums">
            {displayUlMbps > 0 ? ul.value : '—'}
          </span>
          <span
            className="font-display text-xs sm:text-sm font-extrabold"
            style={{ color: 'var(--md-tile-ul-sub)' }}
          >
            {ul.unitLabel}
          </span>
        </div>

        <div className="mt-3.5 space-y-1.5">
          <div
            className="h-2 w-full overflow-hidden rounded-full"
            style={{ backgroundColor: 'var(--md-tile-ul-chip)' }}
          >
            <motion.div
              className="m3-tone-surface h-full rounded-full"
              style={{ backgroundColor: 'var(--md-tile-ul-bar)' }}
              animate={{
                width: `${displayUlMbps > 0 ? Math.max(10, ulFillPct) : 0}%`,
              }}
              transition={{ type: 'spring', stiffness: 200, damping: 26 }}
            />
          </div>
          <div
            className="flex items-center justify-between text-[10px] sm:text-[11px] font-bold"
            style={{ color: 'var(--md-tile-ul-sub)' }}
          >
            <span className="truncate">
              {ulActive
                ? 'Uploading…'
                : mode === 'both' && isScanning && displayUlMbps === 0
                  ? 'Queued'
                  : displayUlMbps > 0
                    ? 'Upstream'
                    : 'Upload / Both'}
            </span>
            <span className="shrink-0 ml-1">{network.standard}</span>
          </div>
        </div>
      </motion.button>

      {/* BOX 3: PIXEL PING TILE (Tap for technical details) */}
      <motion.button
        id="metric-card-ping"
        type="button"
        onClick={() => onInspectMetric('ping')}
        aria-label="Ping latency. Tap for technical information."
        whileHover={{ y: -4, scale: 1.015 }}
        whileTap={{ scale: 0.96 }}
        animate={isComplete ? { scale: [1, 1.03, 1] } : { scale: 1 }}
        transition={{
          scale: { duration: 0.44, delay: 0.16, ease: [0.2, 0, 0, 1] },
          y: { type: 'spring', stiffness: 420, damping: 22 },
        }}
        className="m3-tone-surface relative flex flex-col justify-between overflow-hidden rounded-[30px] p-4 sm:p-5 text-left cursor-pointer focus:outline-none"
        style={{
          backgroundColor: 'var(--md-tile-ping-bg)',
          color: 'var(--md-tile-ping-fg)',
        }}
      >
        <div className="flex items-center justify-between gap-2">
          <span
            className="font-display text-xs sm:text-sm font-extrabold tracking-[-0.02em]"
            style={{ color: 'var(--md-tile-ping-sub)' }}
          >
            Ping
          </span>
          <span
            className="m3-tone-surface flex h-8 w-8 items-center justify-center rounded-[11px]"
            style={{
              backgroundColor: 'var(--md-tile-ping-chip)',
              color: 'var(--md-tile-ping-fg)',
            }}
          >
            {isScanning ? (
              <CircularWavySpinner
                progress={0.52}
                indeterminate
                size={18}
                strokeWidth={34}
                amplitude={10}
                waves={6}
              />
            ) : (
              <Activity className="h-4 w-4 stroke-[2.6]" />
            )}
          </span>
        </div>

        <div className="mt-3.5 flex items-baseline gap-1 flex-wrap">
          <span className="font-display text-[36px] sm:text-[42px] font-black leading-none tracking-[-0.055em] tabular-nums">
            {isIdle ? '—' : telemetry.ping}
          </span>
          <span
            className="font-display text-xs sm:text-sm font-extrabold"
            style={{ color: 'var(--md-tile-ping-sub)' }}
          >
            ms
          </span>
          {!isIdle && (
            <span
              className="m3-tone-surface ml-auto rounded-full px-2 py-0.5 text-[10px] font-extrabold tabular-nums"
              style={{
                backgroundColor: 'var(--md-tile-ping-chip)',
                color: 'var(--md-tile-ping-fg)',
              }}
            >
              ±{telemetry.jitter.toFixed(1)}
            </span>
          )}
        </div>

        <div className="mt-3.5 space-y-1.5">
          <div className="grid grid-cols-4 gap-1">
            {[1, 2, 3, 4].map((seg) => (
              <span
                key={seg}
                className="m3-tone-surface h-2 rounded-full"
                style={{
                  backgroundColor:
                    seg <= activeBars
                      ? 'var(--md-tile-ping-bar)'
                      : 'var(--md-tile-ping-chip)',
                }}
              />
            ))}
          </div>
          <div
            className="flex items-center justify-between text-[10px] sm:text-[11px] font-bold tabular-nums"
            style={{ color: 'var(--md-tile-ping-sub)' }}
          >
            <span>
              {isIdle
                ? 'Latency'
                : isScanning
                  ? 'Probing…'
                  : telemetry.ping <= 15
                    ? 'Ultra-low'
                    : 'Steady'}
            </span>
            <span>{isIdle ? '— dBm' : `${telemetry.dbm} dBm`}</span>
          </div>
        </div>
      </motion.button>

      {/* BOX 4: AI ASSISTANT WITH MAGNIFYING GLASS ICON RIGHT NEXT TO RESULTS */}
      <motion.button
        id="ai-diagnose-tile-btn"
        type="button"
        onClick={onAskAi}
        whileHover={{ y: -4, scale: 1.03 }}
        whileTap={{ scale: 0.92 }}
        transition={{ type: 'spring', stiffness: 460, damping: 20 }}
        aria-label="Open AI Wi-Fi Assistant to diagnose and improve poor Wi-Fi"
        className="m3-tone-surface relative flex flex-col items-center justify-between overflow-hidden rounded-[30px] p-4 text-center cursor-pointer focus:outline-none"
        style={{
          backgroundColor: isPoorWifi
            ? 'var(--md-primary)'
            : 'var(--md-primary-container)',
          color: isPoorWifi
            ? 'var(--md-on-primary)'
            : 'var(--md-on-primary-container)',
        }}
      >
        <span className="font-display text-[11px] font-extrabold uppercase tracking-[0.06em] opacity-85">
          {isPoorWifi ? 'Fix Wi-Fi' : 'AI Help'}
        </span>

        <span
          className="my-2 flex h-12 w-12 items-center justify-center rounded-[18px]"
          style={{
            backgroundColor: isPoorWifi
              ? 'rgba(255, 255, 255, 0.18)'
              : 'var(--md-surface-container-lowest)',
            color: isPoorWifi ? 'var(--md-on-primary)' : 'var(--md-primary)',
          }}
        >
          <AiMagnifierIcon className="h-6 w-6" />
        </span>

        <span className="font-display text-xs font-extrabold leading-tight">
          {isPoorWifi ? 'Boost speed' : 'Analyze'}
        </span>
      </motion.button>
    </section>
  )
}

import { AnimatePresence, motion } from 'framer-motion'
import { ChevronDown, Send } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import {
  generateAiWifiReply,
  isWifiPoor,
  type AiWifiContext,
} from '../data/networks'
import { CircularWavySpinner } from './CircularWavySpinner'

interface AiWifiAssistantProps {
  context: AiWifiContext
  isOpen: boolean
  onToggleOpen: (open: boolean) => void
  diagnoseTriggerCount: number
}

interface ChatMessage {
  id: string
  role: 'assistant' | 'user'
  text: string
}

/** Custom Pixel M3E AI Sparkle inside a Magnifying Glass icon */
export function AiMagnifierIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.1"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="10.5" cy="10.5" r="7" />
      <path d="m20.5 20.5-4.8-4.8" strokeWidth="2.4" />
      {/* 4-point AI Sparkle nested cleanly inside the magnifying glass lens */}
      <path
        d="M10.5 6.8 L11.45 9.55 L14.2 10.5 L11.45 11.45 L10.5 14.2 L9.55 11.45 L6.8 10.5 L9.55 9.55 Z"
        fill="currentColor"
        stroke="none"
      />
    </svg>
  )
}

const QUICK_PROMPTS = [
  'Diagnose my Wi-Fi',
  'Boost upload speed',
  'Lower gaming ping',
  '5 GHz vs 6 GHz',
  'Router placement',
]

function renderFormattedText(text: string) {
  // Light markdown-style bold **...** rendering without unsafe HTML
  const lines = text.split('\n')
  return lines.map((line, lineIdx) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g)
    return (
      <span key={lineIdx} className={lineIdx > 0 ? 'block mt-1.5' : 'block'}>
        {parts.map((part, idx) =>
          part.startsWith('**') && part.endsWith('**') ? (
            <strong key={idx} className="font-extrabold">
              {part.slice(2, -2)}
            </strong>
          ) : (
            <span key={idx}>{part}</span>
          ),
        )}
      </span>
    )
  })
}

export function AiWifiAssistant({
  context,
  isOpen,
  onToggleOpen,
  diagnoseTriggerCount,
}: AiWifiAssistantProps) {
  const poor = isWifiPoor(context)
  const [input, setInput] = useState('')
  const [thinking, setThinking] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome',
      role: 'assistant',
      text: `Hi! I can inspect your **${context.network.ssid}** (${context.network.band}) test results and suggest ways to improve download, upload, or ping. Ask me anything below.`,
    },
  ])

  const scrollRef = useRef<HTMLDivElement>(null)
  const lastTriggerRef = useRef(diagnoseTriggerCount)

  const sendPrompt = (promptText: string) => {
    const trimmed = promptText.trim()
    if (!trimmed) return

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: trimmed,
    }
    setMessages((prev) => [...prev, userMsg])
    setInput('')
    setThinking(true)

    window.setTimeout(() => {
      const reply = generateAiWifiReply(trimmed, context)
      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: 'assistant',
          text: reply,
        },
      ])
      setThinking(false)
    }, 360)
  }

  // Trigger an automatic live diagnosis whenever the user taps the AI Magnifying Glass button next to results
  useEffect(() => {
    if (diagnoseTriggerCount > lastTriggerRef.current) {
      lastTriggerRef.current = diagnoseTriggerCount
      const reply = generateAiWifiReply('diagnose poor wifi better result', context)
      setMessages((prev) => [
        ...prev,
        {
          id: `diag-${Date.now()}`,
          role: 'assistant',
          text: reply,
        },
      ])
    }
  }, [context, diagnoseTriggerCount])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, thinking, isOpen])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || thinking) return
    sendPrompt(input)
  }

  return (
    <section
      id="ai-wifi-chatbot-section"
      aria-label="AI Wi-Fi Speed Assistant"
      className="w-full"
    >
      <div
        className="m3-tone-surface m3-tonal-card overflow-hidden rounded-[32px]"
        style={{
          border: '1px solid var(--md-outline-variant)',
        }}
      >
        {/* Chatbot Header Bar (always accessible at the bottom of the screen) */}
        <button
          id="ai-chatbot-header-btn"
          type="button"
          onClick={() => onToggleOpen(!isOpen)}
          aria-expanded={isOpen}
          className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left cursor-pointer"
        >
          <div className="flex items-center gap-3 min-w-0">
            <span
              className="m3-tone-surface flex h-10 w-10 shrink-0 items-center justify-center rounded-[16px]"
              style={{
                backgroundColor: 'var(--md-primary-container)',
                color: 'var(--md-on-primary-container)',
              }}
            >
              <AiMagnifierIcon className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-display text-sm sm:text-base font-extrabold tracking-[-0.02em]">
                  AI Wi-Fi Assistant
                </h2>
                <span
                  className="rounded-full px-2.5 py-0.5 text-[10px] font-extrabold"
                  style={{
                    backgroundColor: poor
                      ? 'var(--md-primary)'
                      : 'var(--md-surface-container-high)',
                    color: poor
                      ? 'var(--md-on-primary)'
                      : 'var(--md-on-surface-variant)',
                  }}
                >
                  {poor ? 'Tips available' : `${context.network.band}`}
                </span>
              </div>
              <p
                className="text-xs truncate"
                style={{ color: 'var(--md-on-surface-variant)' }}
              >
                {poor
                  ? 'Weak signal detected — chat to boost your speed'
                  : 'Chat to optimize download, upload, or ping'}
              </p>
            </div>
          </div>

          <ChevronDown
            className={`h-5 w-5 shrink-0 transition-transform duration-250 ${
              isOpen ? 'rotate-180' : ''
            }`}
            style={{ color: 'var(--md-on-surface-variant)' }}
          />
        </button>

        {/* Expandable Interactive Chat Body */}
        <AnimatePresence initial={false}>
          {isOpen && (
            <motion.div
              key="ai-chat-body"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.28, ease: [0.2, 0, 0, 1] }}
              className="overflow-hidden"
            >
              <div
                className="border-t px-4 sm:px-5 pb-4 pt-3.5 space-y-3"
                style={{ borderColor: 'var(--md-outline-variant)' }}
              >
                {/* Quick-ask Pixel Suggestion Pills */}
                <div className="flex flex-wrap items-center gap-1.5">
                  {QUICK_PROMPTS.map((q) => (
                    <button
                      key={q}
                      type="button"
                      disabled={thinking}
                      onClick={() => sendPrompt(q)}
                      className="m3-tone-surface rounded-full px-3 py-1.5 text-[11px] font-bold cursor-pointer transition-transform active:scale-95 disabled:opacity-50"
                      style={{
                        backgroundColor: 'var(--md-surface-container-high)',
                        color: 'var(--md-on-surface)',
                      }}
                    >
                      {q}
                    </button>
                  ))}
                </div>

                {/* Chat Messages Stream */}
                <div
                  ref={scrollRef}
                  className="max-h-[230px] overflow-y-auto space-y-2.5 pr-1"
                >
                  {messages.map((msg) => {
                    const isUser = msg.role === 'user'
                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2 }}
                        className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[88%] rounded-[22px] px-4 py-2.5 text-xs sm:text-[13px] leading-relaxed ${
                            isUser ? 'rounded-br-[8px]' : 'rounded-bl-[8px]'
                          }`}
                          style={{
                            backgroundColor: isUser
                              ? 'var(--md-primary)'
                              : 'var(--md-surface-container-high)',
                            color: isUser
                              ? 'var(--md-on-primary)'
                              : 'var(--md-on-surface)',
                          }}
                        >
                          {renderFormattedText(msg.text)}
                        </div>
                      </motion.div>
                    )
                  })}

                  {thinking && (
                    <div className="flex justify-start">
                      <div
                        className="inline-flex items-center gap-2.5 rounded-[22px] rounded-bl-[8px] px-4 py-2.5 text-xs font-semibold"
                        style={{
                          backgroundColor: 'var(--md-surface-container-high)',
                          color: 'var(--md-on-surface-variant)',
                        }}
                      >
                        <CircularWavySpinner
                          progress={0.52}
                          indeterminate
                          size={18}
                          strokeWidth={34}
                          amplitude={10}
                          waves={6}
                        />
                        <span>Analyzing your Wi-Fi telemetry…</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Message Composer */}
                <form
                  onSubmit={handleSubmit}
                  className="flex items-center gap-2 pt-1"
                >
                  <input
                    id="ai-chat-input"
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask how to boost your Wi-Fi speed…"
                    className="flex-1 rounded-full px-4 py-2.5 text-xs sm:text-sm font-medium outline-none"
                    style={{
                      backgroundColor: 'var(--md-surface-container-lowest)',
                      color: 'var(--md-on-surface)',
                    }}
                  />
                  <motion.button
                    id="ai-chat-send-btn"
                    type="submit"
                    disabled={!input.trim() || thinking}
                    whileTap={{ scale: 0.9 }}
                    aria-label="Send message to AI Wi-Fi Assistant"
                    className="m3-tone-surface flex h-10 w-10 shrink-0 items-center justify-center rounded-full cursor-pointer disabled:opacity-45"
                    style={{
                      backgroundColor: 'var(--md-primary)',
                      color: 'var(--md-on-primary)',
                    }}
                  >
                    <Send className="h-4 w-4 stroke-[2.3]" />
                  </motion.button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

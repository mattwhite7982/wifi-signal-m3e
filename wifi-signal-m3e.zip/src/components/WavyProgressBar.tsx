import { AnimatePresence, motion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'
import type { TelemetrySnapshot, TestStatus } from '../data/networks'

interface WavyProgressBarProps {
  status: TestStatus
  telemetry: TelemetrySnapshot
}

const SVG_WIDTH = 360
const SVG_HEIGHT = 24
const MID_Y = SVG_HEIGHT / 2
const PAD_X = 6
const GAP_PX = 10

function buildWavyPath(
  startX: number,
  endX: number,
  amplitude: number,
  wavelength: number,
  phase: number,
): string {
  const length = endX - startX
  if (length <= 1) return ''

  const step = 3
  const steps = Math.max(2, Math.ceil(length / step))
  let d = ''

  for (let i = 0; i <= steps; i++) {
    const t = i / steps
    const x = startX + t * length
    const edgeDist = Math.min(x - startX, endX - x)
    const taper = Math.min(1, edgeDist / 10)
    const y =
      MID_Y +
      amplitude * taper * Math.sin(((x - startX) / wavelength) * Math.PI * 2 - phase)
    d += i === 0 ? `M ${x.toFixed(2)} ${y.toFixed(2)}` : ` L ${x.toFixed(2)} ${y.toFixed(2)}`
  }

  return d
}

export function WavyProgressBar({ status, telemetry }: WavyProgressBarProps) {
  const [phase, setPhase] = useState(0)
  const [smoothedAmp, setSmoothedAmp] = useState(0)
  const rafRef = useRef<number | null>(null)
  const lastRef = useRef<number>(0)
  const stabilityRef = useRef(telemetry.stability)
  const statusRef = useRef(status)

  useEffect(() => {
    stabilityRef.current = telemetry.stability
    statusRef.current = status
  }, [telemetry.stability, status])

  useEffect(() => {
    const tick = (now: number) => {
      if (!lastRef.current) lastRef.current = now
      const dt = Math.min(0.05, (now - lastRef.current) / 1000)
      lastRef.current = now

      const st = statusRef.current
      const stability = stabilityRef.current
      const instability = 1 - stability

      const targetAmp = st === 'scanning' ? 2.6 + instability * 4.8 : 0
      const speed = st === 'scanning' ? 6.0 + instability * 7.0 : 1.5

      setPhase((prev) => (prev + speed * dt) % (Math.PI * 200))
      setSmoothedAmp((prev) => prev + (targetAmp - prev) * Math.min(1, dt * 8))

      rafRef.current = requestAnimationFrame(tick)
    }

    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [])

  const isScanning = status === 'scanning'
  const usableWidth = SVG_WIDTH - PAD_X * 2
  const activeEnd = PAD_X + usableWidth * Math.max(0.03, telemetry.progress)
  const trackStart = Math.min(SVG_WIDTH - PAD_X, activeEnd + GAP_PX)
  const hasRemainingTrack = trackStart < SVG_WIDTH - PAD_X - 4

  const wavelength = 24 + telemetry.stability * 10
  const wavyPath = buildWavyPath(PAD_X, activeEnd, smoothedAmp, wavelength, phase)
  const pct = Math.round(telemetry.progress * 100)

  return (
    <div className="mx-auto w-full max-w-[340px] px-2">
      <AnimatePresence mode="wait">
        {isScanning && (
          <motion.div
            key="wavy-scanning"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.22 }}
            className="flex flex-col gap-1.5 pt-2"
          >
            <svg
              viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}
              className="h-6 w-full overflow-visible"
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={pct}
              aria-label="Wi-Fi scan progress"
            >
              {hasRemainingTrack && (
                <line
                  x1={trackStart}
                  y1={MID_Y}
                  x2={SVG_WIDTH - PAD_X}
                  y2={MID_Y}
                  strokeWidth={5}
                  strokeLinecap="round"
                  className="m3-tone-surface"
                  style={{ stroke: 'var(--md-wave-track)' }}
                />
              )}

              {wavyPath && (
                <path
                  d={wavyPath}
                  fill="none"
                  strokeWidth={5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="m3-tone-surface"
                  style={{ stroke: 'var(--md-wave-active)' }}
                />
              )}
            </svg>

            <div className="flex items-center justify-between text-xs font-semibold">
              <span
                className="truncate"
                style={{ color: 'var(--md-on-surface-variant)' }}
              >
                {telemetry.phaseLabel}
              </span>
              <span
                className="ml-2 shrink-0 font-display font-extrabold tabular-nums"
                style={{ color: 'var(--md-primary)' }}
              >
                {pct}%
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

import { motion } from 'framer-motion'
import { useEffect, useMemo, useRef, useState } from 'react'
import type { TestStatus } from '../data/networks'

interface MorphingStarburstProps {
  /** Normalized 0..1 strength for subtle morph & scale */
  signalStrength: number
  /** Current test status */
  status: TestStatus
  /** Diameter in px */
  size?: number
}

/**
 * Generates a single crisp 12-lobe Material 3 Expressive scalloped polygon
 * ("Cookie / Soft Burst" shape) using smooth closed Catmull-Rom splines.
 */
function buildScallopedBadgePath(
  cx: number,
  cy: number,
  baseRadius: number,
  lobeDepth: number,
  lobes = 12,
): string {
  const sampleCount = lobes * 6
  const points: Array<{ x: number; y: number }> = []

  for (let i = 0; i < sampleCount; i++) {
    const theta = (i / sampleCount) * Math.PI * 2
    const wave =
      Math.cos(lobes * theta) * 0.88 + Math.cos(lobes * 2 * theta) * 0.12
    const r = baseRadius + lobeDepth * wave
    points.push({
      x: cx + r * Math.cos(theta),
      y: cy + r * Math.sin(theta),
    })
  }

  const tension = 1 / 6
  const n = points.length
  let d = `M ${points[0].x.toFixed(2)} ${points[0].y.toFixed(2)}`

  for (let i = 0; i < n; i++) {
    const p0 = points[(i - 1 + n) % n]
    const p1 = points[i]
    const p2 = points[(i + 1) % n]
    const p3 = points[(i + 2) % n]

    const cp1x = p1.x + (p2.x - p0.x) * tension
    const cp1y = p1.y + (p2.y - p0.y) * tension
    const cp2x = p2.x - (p3.x - p1.x) * tension
    const cp2y = p2.y - (p3.y - p1.y) * tension

    d += ` C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(2)} ${cp2y.toFixed(2)}, ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`
  }

  return `${d} Z`
}

export function MorphingStarburst({
  signalStrength,
  status,
  size = 186,
}: MorphingStarburstProps) {
  const [angle, setAngle] = useState(0)
  const [morphTick, setMorphTick] = useState(0)
  const rafRef = useRef<number | null>(null)
  const lastTimeRef = useRef<number>(0)
  const strengthRef = useRef(signalStrength)
  const statusRef = useRef(status)

  useEffect(() => {
    strengthRef.current = signalStrength
    statusRef.current = status
  }, [signalStrength, status])

  useEffect(() => {
    const animate = (now: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = now
      const dt = Math.min(0.05, (now - lastTimeRef.current) / 1000)
      lastTimeRef.current = now

      const s = strengthRef.current
      const st = statusRef.current

      const degPerSec =
        st === 'scanning' ? 16 + s * 22 : st === 'complete' ? 5 : 4

      setAngle((prev) => (prev + degPerSec * dt) % 360)
      setMorphTick((prev) => prev + dt * (st === 'scanning' ? 2.6 : 0.9))

      rafRef.current = requestAnimationFrame(animate)
    }

    rafRef.current = requestAnimationFrame(animate)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [])

  const breath = Math.sin(morphTick) * (status === 'scanning' ? 1.6 : 0.6)
  const lobeDepth = 5.4 + signalStrength * 4.8 + breath

  const badgePath = useMemo(
    () => buildScallopedBadgePath(110, 110, 86, lobeDepth, 12),
    [lobeDepth],
  )

  const targetScale =
    status === 'scanning'
      ? 0.9 + signalStrength * 0.12
      : status === 'complete'
        ? 0.95 + signalStrength * 0.08
        : 0.96

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none select-none flex items-center justify-center"
      style={{ width: size, height: size }}
      animate={{ scale: targetScale }}
      transition={{ type: 'spring', stiffness: 220, damping: 20, mass: 0.9 }}
    >
      <svg
        viewBox="0 0 220 220"
        className="h-full w-full overflow-visible"
        role="presentation"
      >
        <g transform={`rotate(${angle.toFixed(2)} 110 110)`}>
          <path
            d={badgePath}
            className="m3-tone-surface"
            style={{ fill: 'var(--md-starburst-fill)' }}
          />
        </g>
      </svg>
    </motion.div>
  )
}

import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  ArrowUpDown,
  MapPin,
  Play,
  Sparkles,
} from 'lucide-react'
import { useState } from 'react'
import { CircularWavySpinner } from './CircularWavySpinner'

interface OnboardingModalProps {
  open: boolean
  onComplete: () => void
}

const SLIDES = [
  {
    id: 'speed',
    badge: '01 • EXPRESSIVE SPEED',
    title: 'Download, Upload, or Both in one sweep',
    body: 'Track real-time Mbps with our spring-physics Material 3 Expressive gauge, live stability waves, and dynamic tonal shifts as your link locks.',
    icon: ArrowUpDown,
    highlights: ['Mbps Hero Gauge', 'Upload & Dual Sweep', 'Wavy Stability'],
  },
  {
    id: 'video',
    badge: '02 • STREAMING CHECK',
    title: 'Verify 4K UHD & 60fps video readiness',
    body: 'Launch an adaptive bitrate video test right alongside speed sweeps to inspect startup load time, buffering health, and maximum crisp playback resolution.',
    icon: Play,
    highlights: ['4K UHD 60fps', 'Startup Load Time', 'Buffer Stability'],
  },
  {
    id: 'map',
    badge: '03 • CROWD SIGNAL MAP',
    title: 'Drop a pin and map real Wi-Fi speeds',
    body: 'Publish your measured Mbps and dBm reports onto the interactive neighborhood map so everyone can discover the fastest 6 GHz and 5 GHz zones.',
    icon: MapPin,
    highlights: ['Live User Reports', 'Tap to Drop Pin', 'Band Filters'],
  },
]

export function OnboardingModal({ open, onComplete }: OnboardingModalProps) {
  const [step, setStep] = useState(0)

  if (!open) return null

  const slide = SLIDES[step]
  const Icon = slide.icon
  const isLast = step === SLIDES.length - 1

  const handleNext = () => {
    if (isLast) {
      setStep(0)
      onComplete()
    } else {
      setStep((prev) => prev + 1)
    }
  }

  return (
    <motion.div
      id="onboarding-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
      style={{
        backgroundColor: 'rgba(11, 22, 16, 0.52)',
        backdropFilter: 'blur(12px)',
      }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 12 }}
        transition={{ type: 'spring', stiffness: 360, damping: 26 }}
        className="m3-tone-surface relative w-full max-w-[460px] overflow-hidden rounded-[36px] p-6 sm:p-8 shadow-2xl"
        style={{
          backgroundColor: 'var(--md-surface)',
          color: 'var(--md-on-surface)',
          border: '1px solid var(--md-outline-variant)',
        }}
      >
        {/* Top row: Brand & Skip */}
        <div className="flex items-center justify-between">
          <span
            className="rounded-full px-3 py-1 text-[11px] font-bold tracking-[0.06em]"
            style={{
              backgroundColor: 'var(--md-surface-container-high)',
              color: 'var(--md-on-surface-variant)',
            }}
          >
            {slide.badge}
          </span>
          <button
            id="onboarding-skip-btn"
            type="button"
            onClick={() => {
              setStep(0)
              onComplete()
            }}
            className="rounded-full px-3 py-1 text-xs font-bold cursor-pointer transition-opacity hover:opacity-100 opacity-75"
            style={{ color: 'var(--md-on-surface-variant)' }}
          >
            Skip
          </button>
        </div>

        {/* Animated M3E Circular Wavy Spinner Visual Stage */}
        <div className="relative my-6 flex h-[184px] items-center justify-center">
          <CircularWavySpinner
            progress={0.44 + step * 0.18}
            status={isLast ? 'complete' : 'scanning'}
            size={172}
            strokeWidth={22}
            amplitude={7.6}
            waves={9}
          />
          <AnimatePresence mode="wait">
            <motion.div
              key={slide.id}
              initial={{ opacity: 0, scale: 0.72, rotate: -14 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.72, rotate: 14 }}
              transition={{ type: 'spring', stiffness: 420, damping: 22 }}
              className="absolute flex h-16 w-16 items-center justify-center rounded-[24px] shadow-md"
              style={{
                backgroundColor: 'var(--md-primary)',
                color: 'var(--md-on-primary)',
              }}
            >
              <Icon className="h-8 w-8 stroke-[2.3]" />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Slide Copy */}
        <AnimatePresence mode="wait">
          <motion.div
            key={slide.id}
            initial={{ opacity: 0, x: 18 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -18 }}
            transition={{ type: 'spring', stiffness: 420, damping: 28 }}
            className="text-center"
          >
            <h2 className="font-display text-2xl sm:text-[26px] font-extrabold tracking-[-0.035em] leading-tight">
              {slide.title}
            </h2>
            <p
              className="mt-3 text-sm leading-relaxed"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              {slide.body}
            </p>

            {/* Feature tonal chips */}
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
              {slide.highlights.map((item) => (
                <span
                  key={item}
                  className="rounded-full px-3 py-1 text-xs font-semibold"
                  style={{
                    backgroundColor: 'var(--md-surface-container-high)',
                    color: 'var(--md-on-surface)',
                  }}
                >
                  {item}
                </span>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Footer: M3E Expressive Progress Pills + Next/Start CTA */}
        <div className="mt-7 flex items-center justify-between gap-4">
          <div className="flex items-center gap-1.5" role="tablist">
            {SLIDES.map((s, idx) => (
              <button
                key={s.id}
                type="button"
                aria-label={`Go to onboarding slide ${idx + 1}`}
                onClick={() => setStep(idx)}
                className="h-2.5 rounded-full transition-all duration-300 cursor-pointer"
                style={{
                  width: idx === step ? 28 : 10,
                  backgroundColor:
                    idx === step
                      ? 'var(--md-primary)'
                      : 'var(--md-surface-container-highest)',
                }}
              />
            ))}
          </div>

          <motion.button
            id="onboarding-next-btn"
            type="button"
            onClick={handleNext}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.92 }}
            transition={{ type: 'spring', stiffness: 480, damping: 20 }}
            className="inline-flex items-center gap-2 rounded-full px-6 py-3 font-display text-sm font-bold cursor-pointer"
            style={{
              backgroundColor: 'var(--md-primary)',
              color: 'var(--md-on-primary)',
            }}
          >
            {isLast ? (
              <>
                <Sparkles className="h-4 w-4 stroke-[2.3]" />
                <span>GET STARTED</span>
              </>
            ) : (
              <>
                <span>Next</span>
                <ArrowRight className="h-4 w-4 stroke-[2.5]" />
              </>
            )}
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  )
}

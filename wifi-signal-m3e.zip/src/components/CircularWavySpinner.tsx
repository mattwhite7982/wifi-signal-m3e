import type { ReactNode } from 'react'
import { useEffect, useMemo, useRef, useState } from 'react'
import type { TestStatus } from '../data/networks'

interface CircularWavySpinnerProps {
  /** Normalized 0..1 progress or strength along the 360° ring */
  progress: number
  /** Current measurement status */
  status?: TestStatus
  /** Indeterminate spinning mode for compact in-progress indicators */
  indeterminate?: boolean
  /** 0..1 connection stability (modulates wave energy slightly while scanning) */
  stability?: number
  /** Rendered pixel diameter */
  size?: number
  /** Number of sinusoidal wave cycles around a full 360° circle */
  waves?: number
  /** Stroke thickness in normalized 280px viewBox units */
  strokeWidth?: number
  /** Wave radial amplitude in normalized 280px viewBox units */
  amplitude?: number
  /** Optional accessibility label */
  ariaLabel?: string
  /** Optional centered content (e.g. live Mbps or Resolution readout) */
  children?: ReactNode
}

const VIEWBOX = 280
const CENTER = VIEWBOX / 2
const RADIUS = 108

function polar(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = (angleDeg * Math.PI) / 180
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  }
}

function buildSmoothArcPath(
  cx: number,
  cy: number,
  r: number,
  startDeg: number,
  endDeg: number,
): string {
  const span = endDeg - startDeg
  if (span < 2) return ''
  const start = polar(cx, cy, r, startDeg)
  const end = polar(cx, cy, r, endDeg)
  const largeArc = span > 180 ? 1 : 0
  return `M ${start.x.toFixed(2)} ${start.y.toFixed(2)} A ${r} ${r} 0 ${largeArc} 1 ${end.x.toFixed(2)} ${end.y.toFixed(2)}`
}

function buildWavyArcPath(
  cx: number,
  cy: number,
  baseR: number,
  startDeg: number,
  endDeg: number,
  amplitude: number,
  wavesPerCircle: number,
  phase: number,
  closed = false,
): string {
  const span = endDeg - startDeg
  if (span < 2) return ''

  const stepDeg = 1.6
  const steps = Math.max(18, Math.ceil(span / stepDeg))
  const taperDeg = closed ? 0 : Math.min(13, span * 0.24)
  let d = ''

  for (let i = 0; i <= steps; i++) {
    const t = i / steps
    const angleDeg = startDeg + t * span
    const angleRad = (angleDeg * Math.PI) / 180

    let taper = 1
    if (!closed && taperDeg > 0) {
      const edgeDist = Math.min(angleDeg - startDeg, endDeg - angleDeg)
      taper = Math.sin((Math.min(1, edgeDist / taperDeg) * Math.PI) / 2)
    }

    const r =
      baseR + amplitude * taper * Math.sin(wavesPerCircle * angleRad - phase)
    const x = cx + r * Math.cos(angleRad)
    const y = cy + r * Math.sin(angleRad)
    d +=
      i === 0
        ? `M ${x.toFixed(2)} ${y.toFixed(2)}`
        : ` L ${x.toFixed(2)} ${y.toFixed(2)}`
  }

  return closed ? `${d} Z` : d
}

/**
 * Material 3 Expressive CircularWavyProgressIndicator
 * Matches the split two-tone M3E circular spinner: a bold rounded-cap
 * sinusoidal wavy active arc separated by crisp gaps from a smooth tonal track.
 */
export function CircularWavySpinner({
  progress,
  status = 'scanning',
  indeterminate = false,
  stability = 0.85,
  size = 268,
  waves = 9,
  strokeWidth = 21,
  amplitude = 7.4,
  ariaLabel,
  children,
}: CircularWavySpinnerProps) {
  const [phase, setPhase] = useState(0)
  const [rotation, setRotation] = useState(0)
  const [liveAmp, setLiveAmp] = useState(amplitude)

  const rafRef = useRef<number | null>(null)
  const lastRef = useRef(0)
  const statusRef = useRef(status)
  const stabilityRef = useRef(stability)
  const indeterminateRef = useRef(indeterminate)
  const ampRef = useRef(amplitude)

  useEffect(() => {
    statusRef.current = status
    stabilityRef.current = stability
    indeterminateRef.current = indeterminate
    ampRef.current = amplitude
  }, [status, stability, indeterminate, amplitude])

  useEffect(() => {
    const tick = (now: number) => {
      if (!lastRef.current) lastRef.current = now
      const dt = Math.min(0.05, (now - lastRef.current) / 1000)
      lastRef.current = now

      const st = statusRef.current
      const ind = indeterminateRef.current
      const instability = 1 - stabilityRef.current
      const baseAmp = ampRef.current

      const phaseSpeed = ind
        ? 5.2
        : st === 'scanning'
          ? 4.4 + instability * 2.8
          : st === 'complete'
            ? 0.9
            : 1.4

      const targetAmp = ind
        ? baseAmp
        : st === 'scanning'
          ? baseAmp * (0.94 + instability * 0.22)
          : st === 'complete'
            ? baseAmp * 0.86
            : baseAmp * 0.72

      setPhase((prev) => (prev + phaseSpeed * dt) % (Math.PI * 200))
      setLiveAmp((prev) => prev + (targetAmp - prev) * Math.min(1, dt * 8))

      if (ind) {
        setRotation((prev) => (prev + 148 * dt) % 360)
      } else if (st === 'scanning') {
        // Subtle organic forward drift while scanning
        setRotation((prev) => (prev + 14 * dt) % 360)
      } else {
        // Smoothly glide back toward 12 o'clock alignment when complete/idle
        setRotation((prev) => {
          if (prev < 0.25 || prev > 359.75) return 0
          const shortest = prev > 180 ? 360 - prev : -prev
          return (prev + shortest * Math.min(1, dt * 5) + 360) % 360
        })
      }

      rafRef.current = requestAnimationFrame(tick)
    }

    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [])

  // Effective progress fraction along the 360° ring
  const effFraction = indeterminate
    ? 0.52
    : Math.max(0.06, Math.min(1, progress))

  // Calculate crisp gap between rounded caps matching Material 3 Expressive spec
  const capHalfAngleDeg = ((strokeWidth * 0.5) / RADIUS) * (180 / Math.PI)
  const gapDeg = capHalfAngleDeg * 2 + (size < 40 ? 18 : 11)

  const { wavyPath, trackPath } = useMemo(() => {
    if (effFraction >= 0.995 && !indeterminate) {
      return {
        wavyPath: buildWavyArcPath(
          CENTER,
          CENTER,
          RADIUS,
          -90,
          270,
          liveAmp,
          waves,
          phase,
          true,
        ),
        trackPath: '',
      }
    }

    const wavyStart = -90 + gapDeg / 2
    const wavySpan = Math.max(10, effFraction * 360 - gapDeg)
    const wavyEnd = wavyStart + wavySpan
    const trackStart = wavyEnd + gapDeg
    const trackEnd = 270 - gapDeg / 2

    return {
      wavyPath: buildWavyArcPath(
        CENTER,
        CENTER,
        RADIUS,
        wavyStart,
        wavyEnd,
        liveAmp,
        waves,
        phase,
        false,
      ),
      trackPath:
        trackEnd - trackStart >= 5
          ? buildSmoothArcPath(CENTER, CENTER, RADIUS, trackStart, trackEnd)
          : '',
    }
  }, [effFraction, gapDeg, indeterminate, liveAmp, phase, waves])

  return (
    <div
      className="relative flex items-center justify-center shrink-0 select-none"
      style={{ width: size, height: size }}
    >
      <svg
        viewBox={`0 0 ${VIEWBOX} ${VIEWBOX}`}
        className="h-full w-full overflow-visible"
        role={ariaLabel ? 'img' : 'presentation'}
        aria-label={ariaLabel}
      >
        <g transform={`rotate(${rotation.toFixed(2)} ${CENTER} ${CENTER})`}>
          {/* Smooth tonal remaining track arc (left side in M3E reference) */}
          {trackPath && (
            <path
              d={trackPath}
              fill="none"
              strokeWidth={strokeWidth}
              strokeLinecap="round"
              className="m3-tone-surface"
              style={{ stroke: 'var(--md-primary-container)' }}
            />
          )}

          {/* Expressive sinusoidal wavy active arc (right side in M3E reference) */}
          {wavyPath && (
            <path
              d={wavyPath}
              fill="none"
              strokeWidth={strokeWidth}
              strokeLinecap="round"
              strokeLinejoin="round"
              className="m3-tone-surface"
              style={{ stroke: 'var(--md-primary-bright)' }}
            />
          )}
        </g>
      </svg>

      {children && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          {children}
        </div>
      )}
    </div>
  )
}

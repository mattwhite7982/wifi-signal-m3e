import { AnimatePresence, motion } from 'framer-motion'
import { Film, Gauge } from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AiWifiAssistant } from './components/AiWifiAssistant'
import { FloatingNavBar } from './components/FloatingNavBar'
import { HeroSignalGauge } from './components/HeroSignalGauge'
import { MetricCards } from './components/MetricCards'
import {
  MetricTechnicalModal,
  type TechnicalMetricTab,
} from './components/MetricTechnicalModal'
import { OnboardingModal } from './components/OnboardingModal'
import { SettingsView } from './components/SettingsView'
import { SignalMapView } from './components/SignalMapView'
import { TopBar } from './components/TopBar'
import { VideoTestPanel } from './components/VideoTestPanel'
import { WavyProgressBar } from './components/WavyProgressBar'
import {
  checkDeviceColorCompatibility,
  computeSweepTelemetry,
  getIdleTelemetry,
  INITIAL_MAP_REPORTS,
  isWifiPoor,
  TEST_SERVERS,
  WIFI_NETWORKS,
  type AiWifiContext,
  type AppSettings,
  type MapReport,
  type NavTab,
  type SpeedTestMode,
  type TelemetrySnapshot,
  type TestStatus,
  type ToneMode,
  type WifiNetwork,
} from './data/networks'
import { triggerHaptic, type HapticConfig } from './utils/haptics'
import { useConnectionStatus } from './utils/networkStatus'

const ONBOARDING_STORAGE_KEY = 'signal-m3e-onboarded-v2'

function readOnboarded(): boolean {
  try {
    return window.localStorage.getItem(ONBOARDING_STORAGE_KEY) === 'true'
  } catch {
    return false
  }
}

function saveOnboarded() {
  try {
    window.localStorage.setItem(ONBOARDING_STORAGE_KEY, 'true')
  } catch {
    // Ignore storage errors in sandboxed iframes
  }
}

export function App() {
  const [showOnboarding, setShowOnboarding] = useState<boolean>(
    () => !readOnboarded(),
  )
  const [activeTab, setActiveTab] = useState<NavTab>('download')
  const [speedSubView, setSpeedSubView] = useState<'speed' | 'video'>('speed')
  const [videoStatus, setVideoStatus] = useState<TestStatus>('idle')

  const [selectedNetwork, setSelectedNetwork] = useState<WifiNetwork>(
    WIFI_NETWORKS[0],
  )
  const [status, setStatus] = useState<TestStatus>('idle')
  const [telemetry, setTelemetry] = useState<TelemetrySnapshot>(() =>
    getIdleTelemetry('download'),
  )
  const [lastKnownDownload, setLastKnownDownload] = useState<number>(0)
  const [lastKnownUpload, setLastKnownUpload] = useState<number>(0)

  const [aiChatOpen, setAiChatOpen] = useState<boolean>(false)
  const [diagnoseTriggerCount, setDiagnoseTriggerCount] = useState<number>(0)
  const [inspectedMetric, setInspectedMetric] =
    useState<TechnicalMetricTab | null>(null)

  const [settings, setSettings] = useState<AppSettings>({
    unit: 'Mbps',
    durationSec: 5,
    server: 'sf-auto',
    dynamicTone: true,
    autoReportToMap: false,
    fontStyle: 'pixel-display',
    colorPalette: 'emerald',
    matchDeviceColors: false,
    hapticsEnabled: true,
    hapticsStrength: 30,
    connectionOverride: 'auto',
  })

  const connectionInfo = useConnectionStatus(settings.connectionOverride)

  const hapticConfig: HapticConfig = useMemo(
    () => ({
      enabled: settings.hapticsEnabled,
      strength: settings.hapticsStrength,
    }),
    [settings.hapticsEnabled, settings.hapticsStrength],
  )

  const [reports, setReports] = useState<MapReport[]>(INITIAL_MAP_REPORTS)
  const [openMapInReportMode, setOpenMapInReportMode] = useState(false)

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof document !== 'undefined') {
      if (document.documentElement.classList.contains('dark')) return 'dark'
    }
    return 'light'
  })

  const rafRef = useRef<number | null>(null)
  const startTimeRef = useRef<number>(0)
  const runSeedRef = useRef<number>(1.37)
  const lastStageRef = useRef<'download' | 'upload'>('download')

  const deviceColorCompatible = useMemo(
    () => checkDeviceColorCompatibility().supported,
    [],
  )

  const speedMode: SpeedTestMode =
    activeTab === 'upload'
      ? 'upload'
      : activeTab === 'both'
        ? 'both'
        : 'download'

  const activeServer = useMemo(
    () => TEST_SERVERS.find((s) => s.id === settings.server) ?? TEST_SERVERS[0],
    [settings.server],
  )
  const serverOffset = activeServer.latencyBase

  useEffect(() => {
    const onThemeChange = () => {
      if (document.documentElement.classList.contains('dark')) {
        setTheme('dark')
      } else if (document.documentElement.classList.contains('light')) {
        setTheme('light')
      }
    }
    window.addEventListener('themechange', onThemeChange)
    return () => window.removeEventListener('themechange', onThemeChange)
  }, [])

  const stopAnimation = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
  }, [])

  useEffect(() => {
    return () => stopAnimation()
  }, [stopAnimation])

  const addReport = useCallback(
    (entry: Omit<MapReport, 'id' | 'reportedAt'>) => {
      const next: MapReport = {
        ...entry,
        id: `user-${Date.now()}`,
        reportedAt: 'Just now',
      }
      setReports((prev) => [next, ...prev])
      void triggerHaptic('complete', hapticConfig)
    },
    [hapticConfig],
  )

  const startTest = useCallback(() => {
    stopAnimation()
    void triggerHaptic('start', hapticConfig)
    runSeedRef.current = 0.6 + Math.random() * 5.2
    startTimeRef.current = performance.now()
    lastStageRef.current = speedMode === 'upload' ? 'upload' : 'download'
    const durationMs = settings.durationSec * 1000
    const totalDuration = speedMode === 'both' ? durationMs * 1.45 : durationMs
    setStatus('scanning')

    const step = (now: number) => {
      const elapsed = now - startTimeRef.current
      const snapshot = computeSweepTelemetry(
        elapsed,
        durationMs,
        speedMode,
        selectedNetwork,
        runSeedRef.current,
        serverOffset,
      )
      if (snapshot.activeStage !== lastStageRef.current) {
        lastStageRef.current = snapshot.activeStage
        void triggerHaptic('tick', hapticConfig)
      }
      setTelemetry(snapshot)

      if (elapsed < totalDuration) {
        rafRef.current = requestAnimationFrame(step)
      } else {
        rafRef.current = null
        setStatus('complete')
        void triggerHaptic('complete', hapticConfig)
        if (snapshot.downloadMbps > 0) setLastKnownDownload(snapshot.downloadMbps)
        if (snapshot.uploadMbps > 0) setLastKnownUpload(snapshot.uploadMbps)

        if (settings.autoReportToMap) {
          addReport({
            x: Math.round(20 + Math.random() * 60),
            y: Math.round(22 + Math.random() * 54),
            locationName: `${selectedNetwork.ssid} Spot`,
            ssid: selectedNetwork.ssid,
            band: selectedNetwork.band,
            downloadMbps:
              snapshot.downloadMbps || selectedNetwork.targetDownloadMbps,
            uploadMbps: snapshot.uploadMbps || selectedNetwork.targetUploadMbps,
            dbm: snapshot.dbm,
            ping: snapshot.ping,
            note: 'Auto-reported after sweep',
            isUserReport: true,
          })
        }
      }
    }

    rafRef.current = requestAnimationFrame(step)
  }, [
    addReport,
    hapticConfig,
    selectedNetwork,
    serverOffset,
    settings.autoReportToMap,
    settings.durationSec,
    speedMode,
    stopAnimation,
  ])

  const resetTest = useCallback(() => {
    stopAnimation()
    void triggerHaptic('tap', hapticConfig)
    setStatus('idle')
    setTelemetry(getIdleTelemetry(speedMode))
  }, [hapticConfig, speedMode, stopAnimation])

  const handleSelectNetwork = useCallback(
    (network: WifiNetwork) => {
      stopAnimation()
      void triggerHaptic('tap', hapticConfig)
      setSelectedNetwork(network)
      setStatus('idle')
      setLastKnownDownload(0)
      setLastKnownUpload(0)
      setTelemetry(getIdleTelemetry(speedMode))
    },
    [hapticConfig, speedMode, stopAnimation],
  )

  const handleSelectTab = useCallback(
    (tab: NavTab) => {
      if (status === 'scanning' || videoStatus === 'scanning') return
      void triggerHaptic('tap', hapticConfig)
      setActiveTab(tab)
      if (tab === 'download' || tab === 'upload' || tab === 'both') {
        setSpeedSubView('speed')
        setStatus('idle')
        setTelemetry(getIdleTelemetry(tab))
      }
      if (tab !== 'map') {
        setOpenMapInReportMode(false)
      }
    },
    [hapticConfig, status, videoStatus],
  )

  const handleJumpToReport = useCallback(() => {
    void triggerHaptic('tap', hapticConfig)
    setOpenMapInReportMode(true)
    setActiveTab('map')
  }, [hapticConfig])

  const handleAskAiFromResults = useCallback(() => {
    void triggerHaptic('tap', hapticConfig)
    setAiChatOpen(true)
    setDiagnoseTriggerCount((c) => c + 1)
    window.setTimeout(() => {
      document
        .getElementById('ai-wifi-chatbot-section')
        ?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    }, 80)
  }, [hapticConfig])

  const aiContext: AiWifiContext = useMemo(
    () => ({
      network: selectedNetwork,
      downloadMbps:
        telemetry.downloadMbps > 0 ? telemetry.downloadMbps : lastKnownDownload,
      uploadMbps:
        telemetry.uploadMbps > 0 ? telemetry.uploadMbps : lastKnownUpload,
      dbm: status === 'idle' ? selectedNetwork.targetDbm : telemetry.dbm,
      ping:
        status === 'idle'
          ? selectedNetwork.targetPing + serverOffset
          : telemetry.ping,
      jitter:
        status === 'idle' ? selectedNetwork.targetJitter : telemetry.jitter,
      hasTested:
        status !== 'idle' || lastKnownDownload > 0 || lastKnownUpload > 0,
      connectionTransport: connectionInfo.transport,
    }),
    [
      connectionInfo.transport,
      lastKnownDownload,
      lastKnownUpload,
      selectedNetwork,
      serverOffset,
      status,
      telemetry,
    ],
  )

  const poorWifi = useMemo(() => isWifiPoor(aiContext), [aiContext])

  const latestMeasurement = useMemo(
    () => ({
      downloadMbps:
        aiContext.downloadMbps > 0
          ? aiContext.downloadMbps
          : selectedNetwork.targetDownloadMbps,
      uploadMbps:
        aiContext.uploadMbps > 0
          ? aiContext.uploadMbps
          : selectedNetwork.targetUploadMbps,
      dbm: aiContext.dbm,
      ping: aiContext.ping,
      ssid: selectedNetwork.ssid,
      band: selectedNetwork.band,
    }),
    [aiContext, selectedNetwork],
  )

  const userReportCount = useMemo(
    () => reports.filter((r) => r.isUserReport).length,
    [reports],
  )

  const isSpeedTab =
    activeTab === 'download' || activeTab === 'upload' || activeTab === 'both'

  const { pageTitle, pageSubtitle } = useMemo(() => {
    const connPrefix =
      connectionInfo.transport === 'cellular'
        ? `${connectionInfo.label} • `
        : connectionInfo.transport === 'offline'
          ? 'Offline • '
          : ''

    if (activeTab === 'map') {
      return {
        pageTitle: 'Signal Map',
        pageSubtitle: `${reports.length} live community speed reports near you`,
      }
    }
    if (activeTab === 'settings') {
      return {
        pageTitle: 'Settings',
        pageSubtitle: 'Pixel M3E colors, haptics & connection preferences',
      }
    }
    if (speedSubView === 'video') {
      return {
        pageTitle: 'Video Test',
        pageSubtitle: `${connPrefix}Adaptive 4K UHD HDR streaming check on ${selectedNetwork.band}`,
      }
    }
    if (activeTab === 'upload') {
      return {
        pageTitle: 'Upload',
        pageSubtitle: `${connPrefix}${selectedNetwork.standard} • ${selectedNetwork.channelWidth} upstream throughput`,
      }
    }
    if (activeTab === 'both') {
      return {
        pageTitle: 'Full Sweep',
        pageSubtitle: `${connPrefix}Dual Download & Upload test on ${selectedNetwork.band}`,
      }
    }
    return {
      pageTitle: 'Speed',
      pageSubtitle: `${connPrefix}${selectedNetwork.standard} • ${selectedNetwork.channelWidth} • Ch ${selectedNetwork.channel}`,
    }
  }, [activeTab, connectionInfo, reports.length, selectedNetwork, speedSubView])

  const tone: ToneMode = useMemo(() => {
    if (!settings.dynamicTone) return 'neutral'
    if (isSpeedTab && speedSubView === 'video') {
      if (videoStatus === 'scanning') return 'scanning'
      if (videoStatus === 'complete') return 'emerald'
      return 'neutral'
    }
    if (status === 'idle') return 'neutral'
    if (status === 'scanning') {
      return telemetry.activeStage === 'upload' ? 'uploading' : 'scanning'
    }
    return telemetry.dbm >= -60 ? 'emerald' : 'amber'
  }, [
    isSpeedTab,
    settings.dynamicTone,
    speedSubView,
    status,
    telemetry.activeStage,
    telemetry.dbm,
    videoStatus,
  ])

  const effectivePalette =
    settings.matchDeviceColors && deviceColorCompatible
      ? 'device'
      : settings.colorPalette

  return (
    <div
      data-theme={theme}
      data-tone={tone}
      data-palette={effectivePalette}
      data-font={settings.fontStyle}
      className="m3-tone-surface relative min-h-screen w-full overflow-x-hidden flex flex-col items-center px-4 pt-4 pb-28 sm:px-6 sm:pt-6"
      style={{
        backgroundColor: 'var(--md-surface)',
        color: 'var(--md-on-surface)',
      }}
    >
      <main className="relative z-10 flex w-full max-w-[680px] flex-col items-center gap-5 sm:gap-6">
        <TopBar
          pageTitle={pageTitle}
          pageSubtitle={pageSubtitle}
          networks={WIFI_NETWORKS}
          selectedNetwork={selectedNetwork}
          onSelectNetwork={handleSelectNetwork}
          status={status}
          liveDbm={status === 'idle' ? null : telemetry.dbm}
          connectionInfo={connectionInfo}
          theme={theme}
          onToggleTheme={() => {
            void triggerHaptic('tap', hapticConfig)
            setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))
          }}
        />

        {isSpeedTab && (
          <div className="flex w-full flex-col items-center gap-4">
            <div className="flex w-full items-center justify-start">
              <div
                className="m3-tone-surface inline-flex items-center gap-1 rounded-full p-1"
                style={{
                  backgroundColor: 'var(--md-surface-container-high)',
                }}
              >
                <button
                  id="subtab-speed"
                  type="button"
                  disabled={status === 'scanning' || videoStatus === 'scanning'}
                  onClick={() => {
                    void triggerHaptic('tap', hapticConfig)
                    setSpeedSubView('speed')
                  }}
                  className="relative inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 font-display text-xs font-extrabold cursor-pointer disabled:opacity-50"
                  style={{
                    color:
                      speedSubView === 'speed'
                        ? 'var(--md-on-primary)'
                        : 'var(--md-on-surface-variant)',
                  }}
                >
                  {speedSubView === 'speed' && (
                    <motion.span
                      layoutId="speed-video-pill"
                      transition={{ type: 'spring', stiffness: 460, damping: 28 }}
                      className="m3-tone-surface absolute inset-0 rounded-full"
                      style={{ backgroundColor: 'var(--md-primary)' }}
                    />
                  )}
                  <Gauge className="relative z-10 h-3.5 w-3.5 stroke-[2.4]" />
                  <span className="relative z-10">
                    {speedMode === 'download'
                      ? 'Download'
                      : speedMode === 'upload'
                        ? 'Upload'
                        : 'Download + Upload'}
                  </span>
                </button>

                <button
                  id="subtab-video"
                  type="button"
                  disabled={status === 'scanning' || videoStatus === 'scanning'}
                  onClick={() => {
                    void triggerHaptic('tap', hapticConfig)
                    setSpeedSubView('video')
                  }}
                  className="relative inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 font-display text-xs font-extrabold cursor-pointer disabled:opacity-50"
                  style={{
                    color:
                      speedSubView === 'video'
                        ? 'var(--md-on-primary)'
                        : 'var(--md-on-surface-variant)',
                  }}
                >
                  {speedSubView === 'video' && (
                    <motion.span
                      layoutId="speed-video-pill"
                      transition={{ type: 'spring', stiffness: 460, damping: 28 }}
                      className="m3-tone-surface absolute inset-0 rounded-full"
                      style={{ backgroundColor: 'var(--md-primary)' }}
                    />
                  )}
                  <Film className="relative z-10 h-3.5 w-3.5 stroke-[2.4]" />
                  <span className="relative z-10">Video Test</span>
                </button>
              </div>
            </div>

            <AnimatePresence mode="wait">
              {speedSubView === 'speed' ? (
                <motion.div
                  key="speed-stage"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="flex w-full flex-col items-center gap-4"
                >
                  <section
                    aria-label="Wi-Fi speed dial"
                    className="flex w-full flex-col items-center"
                  >
                    <HeroSignalGauge
                      mode={speedMode}
                      status={status}
                      telemetry={telemetry}
                      network={selectedNetwork}
                      unit={settings.unit}
                      durationSec={settings.durationSec}
                      onStartTest={startTest}
                      onReset={resetTest}
                      onReportToMap={handleJumpToReport}
                    />
                    <WavyProgressBar status={status} telemetry={telemetry} />
                  </section>

                  {/* Pixel Bottom Boxes (Download, Upload, Ping) + AI Magnifying Glass Button right next to them */}
                  <MetricCards
                    mode={speedMode}
                    status={status}
                    telemetry={telemetry}
                    lastKnownDownload={lastKnownDownload}
                    lastKnownUpload={lastKnownUpload}
                    network={selectedNetwork}
                    unit={settings.unit}
                    isPoorWifi={poorWifi}
                    onAskAi={handleAskAiFromResults}
                    onInspectMetric={(tab) => {
                      void triggerHaptic('tap', hapticConfig)
                      setInspectedMetric(tab)
                    }}
                  />

                  {/* AI Wi-Fi Speed Chatbot at the bottom of the screen */}
                  <AiWifiAssistant
                    context={aiContext}
                    isOpen={aiChatOpen}
                    onToggleOpen={setAiChatOpen}
                    diagnoseTriggerCount={diagnoseTriggerCount}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="video-stage"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="w-full"
                >
                  <VideoTestPanel
                    network={selectedNetwork}
                    durationSec={settings.durationSec}
                    onStatusChange={setVideoStatus}
                    onReportToMap={handleJumpToReport}
                    aiContext={aiContext}
                    isPoorWifi={poorWifi}
                    aiChatOpen={aiChatOpen}
                    onToggleAiChat={setAiChatOpen}
                    diagnoseTriggerCount={diagnoseTriggerCount}
                    onAskAi={handleAskAiFromResults}
                    hapticConfig={hapticConfig}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {activeTab === 'map' && (
          <motion.div
            key="map-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.22 }}
            className="w-full"
          >
            <SignalMapView
              reports={reports}
              onAddReport={addReport}
              latestMeasurement={latestMeasurement}
              unit={settings.unit}
              startInReportMode={openMapInReportMode}
              onClearStartReportMode={() => setOpenMapInReportMode(false)}
            />
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div
            key="settings-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.22 }}
            className="w-full"
          >
            <SettingsView
              settings={settings}
              onUpdateSettings={(patch) =>
                setSettings((prev) => ({ ...prev, ...patch }))
              }
              theme={theme}
              onSetTheme={(nextTheme) => {
                void triggerHaptic('tap', hapticConfig)
                setTheme(nextTheme)
              }}
              connectionInfo={connectionInfo}
              userReportCount={userReportCount}
              onClearUserReports={() => {
                void triggerHaptic('tap', hapticConfig)
                setReports((prev) => prev.filter((r) => !r.isUserReport))
              }}
              onReplayOnboarding={() => {
                void triggerHaptic('tap', hapticConfig)
                setShowOnboarding(true)
              }}
            />
          </motion.div>
        )}
      </main>

      <FloatingNavBar
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        reportCount={reports.length}
        disabled={status === 'scanning' || videoStatus === 'scanning'}
      />

      <AnimatePresence>
        {showOnboarding && (
          <OnboardingModal
            open={showOnboarding}
            onComplete={() => {
              saveOnboarded()
              setShowOnboarding(false)
            }}
          />
        )}
      </AnimatePresence>

      <MetricTechnicalModal
        openTab={inspectedMetric}
        onSelectTab={setInspectedMetric}
        onClose={() => setInspectedMetric(null)}
        network={selectedNetwork}
        downloadMbps={aiContext.downloadMbps}
        uploadMbps={aiContext.uploadMbps}
        dbm={aiContext.dbm}
        ping={aiContext.ping}
        jitter={aiContext.jitter}
        unit={settings.unit}
        serverName={activeServer.name}
        hasTested={aiContext.hasTested}
      />
    </div>
  )
}

export default App
